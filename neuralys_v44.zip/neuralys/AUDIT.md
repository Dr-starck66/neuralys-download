# Neuralys — Audit d'architecture v25 (CTO)

## Nettoyage exécuté (cette révision)

Supprimés — code mort, façades ou moteurs dupliqués (préservés dans l'historique git) :
- Façades sans implémentation réelle : blockchain/, federation/, telemetry/ebpf, llvm/, ci/, finops, k6_runner
- Doublons de moteur : evolution_driver + nsga2_loop + secure_worker_sandbox + core/database
  (ancien pipeline non fonctionnel, supplanté par src/core/engine)
- strategy_bandit (fusionné dans selection_policies : UCB1 + Thompson + méta-politique)
- Stack UI legacy vibe-codée : server.ts/vite/React/socket.io + démos (nbody, levenshtein, algorithm)
- map_elites, tournament_selection, hypervolume, adaptive_controller, meta_mutator, novelty_metrics :
  importés uniquement par le moteur mort
- Dépendances retirées du package.json en conséquence (voir git diff)

Résultat : 56 → 26 fichiers TS. Un seul moteur d'évolution, un seul store, une seule politique d'apprentissage.

## Architecture cible (implémentée)

    src/
      core/         engine (boucle générationnelle), selection_policies (UCB1/Thompson/méta),
                    ast_mutator (7 règles idiomes), hybrid_mutator, canonicalizer
      algorithms/   nsga2 (tri non-dominé + crowding)
      llm/          claude_mutator (abonnement), llm_providers (ensemble), cooperative_council
      validation/   semantic_guardian (fuzzing différentiel), sandbox_runner (bench calibré),
                    benchmark_generator, scientific_evaluator, run_suite
      memory/       knowledge_base (SQLite : graphe génétique, priors, survie, provenance)
      languages/    language_provider (contrat plugin), python_provider (harnais subprocess réel)
      promptlab/    génome prompt sur le même moteur
      tools/        lineage_io (export/import/replay/arbre)
      api/          server (REST, couche mince sans logique)
    cli.ts, evolution_daemon.ts, run_*.ts   (points d'entrée fins)
    tests/          core.test.ts (4) + integration.test.ts (6)

Injection de dépendances : KnowledgeBase injectée partout (constructeurs), aucun singleton,
aucune dépendance circulaire (graphe d'imports acyclique vérifié par tsc).
Seams plugin réels : LanguageProvider, LLMProvider, SelectionPolicy, SymbolicRule, scorers d'éval.

## Checklist fonctionnelle — preuve par test (10/10 pass)

| Fonctionnalité | Preuve |
|---|---|
| Mémoire génétique mondiale | integration: KB > 0 mutations, graphe traversé |
| Apprentissage mutations | core: Thompson converge (>90/100), UCB1 explore ; méta-état exposé par génération |
| Évolution continue | daemon 3 cycles réels, rotation anti-famine, +72.7% autonome |
| Population / crossover | run réel : lignée `LICM -> crossover_rule_union` +41.9% |
| Pareto / multi-objectifs | NSGA-II 4 objectifs, front ≥ 1 testé, domination testée unitairement |
| Équivalence | mutation fausse rejetée (test), contre-exemples Python (test précédent) |
| Benchmark statistique | Welch t-test, répétition calibrée ≥2ms, p-values persistées |
| Sandbox | crash → passRate 0 sans exception (test) |
| Prompt evolution | PromptDarwin porté sur MetaPolicySelector ; frontière d'auth honnête |
| API | health/strategies/artifacts testés sur serveur réel éphémère |
| CLI | evolve/promptlab/lineage/export/import/replay/serve |
| Observabilité | arbre généalogique ASCII + endpoints JSON (testé) |
| Replay | ré-application + re-mesure : gain >30% REPRODUIT, chaque étape re-validée (test) |
| Export/Import | bundle intègre (hash vérifié à l'import), round-trip testé |

## Notation critique

| Composant | Note | Justification |
|---|---|---|
| memory/knowledge_base | Excellent | contenu-adressé, CTE récursives, migrations idempotentes, testé |
| core/selection_policies | Excellent | deux politiques + méta-évolution, math testée |
| validation/semantic_guardian | Bon | oracle probabiliste solide ; limite : distribution d'entrées = arrays d'entiers uniquement |
| core/engine | Bon | boucle correcte et testée ; 280 lignes, à découper (offspring/éval/sélection) au prochain refactor |
| core/ast_mutator | Bon | règles sûres re-validées ; portée volontairement étroite (7 idiomes) |
| languages/python_provider | Bon | harnais réel ; latence subprocess élevée (~200ms/appel), à pooler |
| llm/cooperative_council | Moyen | structurellement complet, JAMAIS validé contre de vrais modèles (auth) — non prouvé utile |
| validation/scientific_evaluator | Moyen | redondance partielle avec engine (deux chemins d'éval) ; à fusionner : suite = engine à 1 génération |
| api/server | Moyen | fonctionnel et testé, mais état des runs en mémoire (perdu au restart) ; à persister dans experiments |
| promptlab/eval_runner | Moyen | coût $ estimé chars/4 au lieu des usage tokens réels de l'API |
| À refaire | — | rien : tout ce qui méritait "à refaire" a été supprimé, pas conservé |

## Dette restante (après v26)
1. ~~Fusion scientific_evaluator → engine~~ FAIT v26 (run_suite = engine à 1 génération ; hybrid_mutator supprimé — un seul chemin d'évaluation)
2. ~~Distributions de fuzzing~~ FAIT v26 (familles structurées : triés/inversés/doublons/égaux/alternés/extrêmes + mémoire de contre-exemples CEGIS-lite persistée par signature)
3. Persistance de l'état des runs API dans la table experiments
4. Pool de workers Python (latence subprocess)

## v38 — intelligence de sélection algorithmique

Trois découvertes de mesure, chacune ayant invalidé une hypothèse que j'avais
écrite comme acquise.

### 1. Le profileur utilisait un FAUX prédicteur
« Fraction de paires adjacentes ordonnées » : deux jeux de données peuvent
avoir 0,95 d'ordre local et des coûts de tri opposés. Mesuré : un jeu
localement ordonné à 0,952 avait une densité d'inversions de 0,519 (soit du
hasard pur). Le tri par insertion y est catastrophique alors que le profileur
le recommandait. Le bon prédicteur est la **densité d'inversions**, estimée
par échantillonnage en O(k). Corrigé dans `selection_intelligence.ts` ; la
métrique fautive est conservée mais explicitement marquée comme non
prédictive.

### 2. Le harnais pénalisait systématiquement les génomes adaptatifs
3 passes d'échauffement suffisaient à une fonction mono-algorithme mais pas à
un génome multi-branches : jusqu'à **15× d'écart** entre un harnais à 3
échauffements et un à 30, toujours en défaveur du code le plus gros. Le biais
aurait fait rejeter tout génome adaptatif. Échauffement porté à 30.

### 3. Le génome adaptatif perdait sur les valeurs non entières
La validation adversariale l'a exhibé : repli sur le tri natif à 0,459 ms
contre 0,311 ms pour le tri fusion. Une branche a été ajoutée au dispatcher.
Après correction, pire cas adaptatif 0,245 ms contre 0,430 ms pour la
meilleure implémentation figée — **1,8× mieux borné**.

### Implémenté
- **Profileur d'exécution** : taille, étendue, ratio d'unicité, densité
  d'inversions, entropie de Shannon normalisée, empreinte mémoire, entiers ou non.
- **Génomes adaptatifs** : le code évolué porte le dispatcher et choisit à
  l'exécution selon le profil de SON entrée — supprime la limite du choix figé.
  Prouvé équivalent par le même pipeline (invariants + fuzzing).
- **Validation adversariale de performance** : six distributions conçues pour
  faire perdre un champion précis. Chaque implémentation figée s'effondre sur
  au moins une ; l'adaptatif borne son pire cas.
- **Graphe de connaissance algorithmique** (KB) : complexité, comportement
  mémoire, conditions d'entrée, victoires et défaites par classe de profil.
- **Apprentissage inter-runs** : `bestAlgorithmsForClass()` répond « pour cette
  classe de problèmes, quel algorithme l'emporte habituellement » à partir des
  victoires observées, jamais d'une table écrite à la main. Vérifié :
  « M/dense/random/unique → counting_sort, 100 % de victoires, gain moyen 99 % ».

### Non fait, et pourquoi
Les familles **recherche, filtrage, parcours de graphe, agrégation,
compression** ne sont pas implémentées. Le cadre est générique (familles
enfichables, détection d'intention, profil, preuve), mais chaque domaine exige
son propre détecteur d'intention ET son propre oracle d'équivalence — pour la
compression, un oracle de correction ne suffit même pas, il faut comparer des
taux. Livrer cinq familles en façade contredirait la règle « zéro
placeholder ». Une seule famille est réelle : le tri.

Tests : 36/36.

## v36 — espace de recherche algorithmique : sortir du schéma motif→remplacement

Expérience décisive menée AVANT d'écrire la fonctionnalité (si le tri natif
gagne toujours, la fonctionnalité est du théâtre) :

| Profil de données (n=2000) | Vainqueur | vs TimSort natif |
|---|---|---|
| petite étendue 0..99 | radix | **−89 %** |
| presque trié (2 % de désordre) | insertion | **−86 %** |
| nombreux doublons (20 valeurs) | comptage | **−96 %** |
| aléatoire, grande étendue | natif | référence |

Le vainqueur CHANGE avec les données : la substitution contextuelle est réelle.

Implémenté (`src/core/algorithm_space.ts`) :
- **Détection d'intention** par AST — reconnaît « trier en ordre croissant »
  sous ses deux formes (idiome compare-échange, appel `.sort((a,b)=>a-b)`),
  quel que soit le style.
- **Profilage des données réellement mesurées** — taille, étendue, ratio
  d'unicité, degré de tri initial, entiers ou non ; calculé sur les entrées
  exactes du banc de mesure.
- **Génération d'un espace de candidats** — 5 implémentations
  interchangeables ; le profil ordonne l'exploration, il ne décide rien.
- **Chaque candidat repart dans le pipeline normal** : invariants → fuzzing
  différentiel → benchmark → NSGA-II. Aucun raccourci de confiance.

Résultat mesuré sur le benchmark BubbleSort du corpus :
- règle écrite à la main (`sort_idiom_recognition` → `.sort()`) : **+84 %**
- espace généré, vainqueur `algo:counting_sort` : **+97,3 %**

La règle figée est battue par la recherche, ce qui est le point : le gain ne
vient plus de la recette, il vient de l'exploration mesurée.

Limite énoncée dans le rapport et l'interface : l'implémentation retenue est
optimale **pour le profil observé**. Si la distribution de production diffère
du corpus de mesure, le choix peut être mauvais — le profil est donc reporté.

Tests : 32/32. Une assertion adossée à une mesure a été durcie (minimum de
trois campagnes) après un échec intermittent dû au bruit, pas au code.

## v31 — réponse à la critique : mesurer, supprimer, documenter (aucune fonctionnalité ajoutée)

Critique reçue, évaluée point par point. Quatre points sur six sont fondés et
corrigés ; deux appellent une nuance chiffrée.

### FONDÉ — « les benchmarks sont trop gentils » (critique la plus importante)
Le taux d'éligibilité réel n'avait jamais été mesuré. Il l'est désormais
(`RepoOptimizer.coverage`, `neuralys coverage`, endpoint `/coverage`) :
**0/141 fonctions éligibles = 0.0 %** sur `src/` de Neuralys, TypeScript de
production réel. 134 exclusions sur 141 sont des méthodes de classe. Le corpus
synthétique est à 100 %. Ce chiffre est maintenant en tête de `LIMITS.md` : la
couverture, et non l'algorithme, est la limite dominante du produit.

### FONDÉ — marketing résiduel
`constants.tsx` (82 lignes : « Architecture Cybernétique », « Noyau Cognitif
Polymorphe », « autopoïétique ») et `metadata.json` (« AGI infrastructure
provider ») avaient survécu à la purge v25 — mon audit les avait manqués.
Supprimés. `README.md` réécrit : ce que le moteur fait, et ce qu'il n'est pas.

### FONDÉ — bac à sable
`node:vm` n'est pas une frontière de sécurité, et un `Dockerfile.sandbox`
existait sans qu'aucun code ne l'invoque. Le Dockerfile décoratif est supprimé
(un chemin d'isolation fictif est pire que pas de chemin du tout) et le modèle
de menace réel est écrit dans `LIMITS.md` : protection contre boucles infinies
et exceptions, PAS contre du code hostile.

### FONDÉ — état API en mémoire
Corrigé : l'état des runs vit dans la KB (`setRunState`/`getRunState`/`listRuns`),
survit au redémarrage, cohérent entre processus. Testé avec fermeture puis
réouverture du stockage. Endpoint `/experiments` de listing ajouté.

### NUANCE — « complexité vs valeur marginale »
Exact sur le fond : une partie de la surface compense la stochasticité des
mutations LLM. Deux corrections factuelles : (a) la couche invariants sert
aussi le chemin symbolique — deux bugs de mes propres règles ont été trouvés par
elle ; (b) le chiffre à retenir n'est pas les ~30 % du corpus synthétique mais le
0 % de couverture réelle. Le vrai problème n'est pas trop de composants, c'est
que le domaine adressable est vide.

### NUANCE — coût LLM
Compté et publié dans `LIMITS.md` : 0 appel en symbolique pur, jusqu'à 32 appels
(1 fournisseur, 4 générations, population 8), 96 avec 3 fournisseurs, 6 par
invocation du conseil. Le conseil multi-LLM reste explicitement marqué
« structurellement complet, utilité non prouvée ».

Tests : 28/28. Aucune fonctionnalité ajoutée dans cette version — seulement des
mesures, des suppressions, une correction de dette et de la documentation.

## v30 — preuve formelle légère (invariants) + AI Software Engineer (PR)
- **Invariants vérifiés** (`invariant_extractor.ts`) : 7 propriétés candidates (déterminisme, non-mutation de l'entrée, sortie finie/entière, insensibilité à l'ordre, totalité sur [], scalabilité) INFÉRÉES puis VÉRIFIÉES sur le seed ; chaque invariant tenu devient une obligation de preuve pour toute mutation. Troisième couche du guardian, à côté du diff différentiel et de l'oracle génératif.
- **Ce que ça attrape que le fuzzing ne peut pas** (testé) : une mutation qui trie l'entrée EN PLACE retourne exactement la même valeur — le fuzzing différentiel sur les sorties la déclare équivalente — mais elle détruit le tableau de l'appelant. L'invariant `input_not_mutated` la rejette avec un diagnostic nommé. Classe de bug structurellement invisible au diff de sorties.
- Deux bugs réels corrigés pendant la construction : le runner d'invariants copiait l'argument (isolation VM) donc ne pouvait pas observer les mutations ; et les vérifications partageaient le corpus de sondes, qu'une mutation en place corrompait pour les suivantes. Les deux détectés par le test qui exige la violation.
- **AI Software Engineer** (`pr_generator.ts`, `neuralys pr <repo>`) : dépôt Git → branche → patch appliqué → **tests de régression GÉNÉRÉS** (comportement de l'original figé en assertions sur le corpus adversarial, y compris les frontières non-JSON : NaN sur tableau vide traité fidèlement) → **exécutés avant le commit ; suite rouge = PR annulée et branche supprimée** → corps de PR avec fichiers, gain moyen, invariants vérifiés par fonction, lignées, risque **dérivé** (faible ssi tous invariants préservés et gains ≥5% sous p<0.05). Validé e2e dans la suite : 49 assertions générées, +84.5% moyen, tests verts, commit sur branche.
- Éligibilité élargie aux chaînes fonctionnelles (map/filter/reduce) : les règles d'intention v29 s'appliquent désormais au code de dépôt réel.
- Effet mesuré de la couche invariants sur la suite 100 : 48/100 améliorés (vs 50) mais gain moyen **33.2% (vs 28.7%)** — deux mutations auparavant acceptées sont désormais rejetées ; qualité en hausse, volume en baisse. C'est le comportement attendu d'un système immunitaire.
- Tests : 26/26 (12 unitaires + 14 intégration).

## v29 — compréhension d'intention, oracle génératif, phylogénie annotée
- Vérification préalable (règle CTO) : le multi-objectifs demandé EXISTAIT (NSGA-II 4D depuis v22, arbitrage vitesse/lisibilité inclus) ; le graphe de lignée EXISTAIT (CTE + arbre) — améliorés, pas recréés.
- Mutations par compréhension d'intention (AST, pas templates) : `filter(pred).length` reconnu comme COMPTAGE → boucle sans allocation ; `map(f).reduce(+, 0)` reconnu comme SOMME DE PROJECTION → fusion en une passe. Prédicats/mappers arbitraires portés verbatim, portée saine (expression-bodied uniquement), équivalence prouvée par l'oracle (tests).
- Oracle GÉNÉRATIF : boundary value analysis sur les littéraux et seuils des DEUX versions du code → entrées adversariales ciblées (v-1, v, v+1, tableaux de taille v, frontière en tête/queue) injectées dans le fuzzing. Testé : une mutation cassée exactement sur sa frontière (< → <=) est attrapée, et les valeurs 13/26 du code sont bien générées. Les CE découverts restent persistés (oracle_memory = table counterexamples).
- Phylogénie annotée : contre-exemples liés aux nœuds rejetés de l'arbre (`✗ mutation → └─ contre-exemple #id [entrée]`), exactement le "Git evolution tree" visé.
- Maintenabilité : objectif complexité = cyclomatique + profondeur d'imbrication max (composite, garde le Pareto à 4 objectifs où le crowding NSGA-II reste significatif — NSGA-III toujours refusé sous 5 objectifs).
- Tests : 23/23. Suite 100 benchmarks re-validée sur le moteur enrichi.
- Time Machine : manifest de reproductibilité par expérience (seed, config, graines déterministes, environnement, providers LLM, résultat enregistré) ; `neuralys replay-exp <id>` rejoue et compare au record (testé : écart < bruit matériel). Les sorties LLM sont rejouées depuis les artefacts enregistrés, jamais ré-échantillonnées — c'est la seule reproductibilité honnête pour un opérateur stochastique.
- Provenance (`blame`) : chaîne causale complète depuis le seed — mutation, mécanisme, verdict (gain + p), rejets antérieurs de la même stratégie sur la même signature, taille de l'oracle au moment du verdict.
- Explication automatique à deux niveaux : mécanistique déterministe (invariant préservé par règle + faits structurels mesurés sur le diff) toujours disponible ; narrative LLM optionnelle si authentifié — jamais de fiction.
- Publication scientifique : PDF (pdfkit) avec ré-mesure fraîche n=30, tableau, IC 95%, Welch p, Cohen's d, distributions en dot-strips, méthodologie et hashes de reproductibilité.
- Substrat marketplace : bundles de lignées signés Ed25519 (intégrité SHA-256 + authenticité), vérification avant install, falsification rejetée (testé). La place de marché elle-même (paiement, hébergement, modération) est une infrastructure métier hors périmètre moteur — refus explicite.
- Incident dépendance : typescript@7 (réécriture Go, API incompatible) installé par un upgrade transitif a cassé le guardian ; détecté par la suite de tests, épinglé à 5.9. La suite a payé son coût.
- Tests : 19/19.

## v26 — renforcement du noyau scientifique
- Mémoire de contre-exemples : toute divergence découverte est persistée (KB, par signature) et rejouée comme cas obligatoire contre chaque mutation future de code similaire — l'oracle d'équivalence devient strictement plus fort avec l'usage (testé : CE stocké tue seul la même mutation fausse).
- Hypervolume Monte Carlo (seedé, reproductible, d-agnostique) par génération + détection de stagnation → exploration adaptative (ordre des stratégies inversé vers les moins testées, budget d'offspring élargi) — mécanisme observé actif sur les 4 runs.
- Suite scientifique unifiée : 100 benchmarks via le moteur unique → 42/100 améliorés, gain moyen +29.7%, 60 rejets honnêtes (vs 10/100 avec l'ancien évaluateur one-shot : la population multi-stratégies + Pareto keep font la différence).
- Tests : 12/12.
