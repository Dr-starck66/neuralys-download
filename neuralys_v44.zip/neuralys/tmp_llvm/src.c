
#include <stdio.h>

int compute() {
    int sum = 0;
    for (int i = 0; i < 50000000; i++) {
        // Multiply by 2 which can be optimized to shift left by 1
        sum += i * 2;
    }
    return sum;
}

int main() {
    int res = compute();
    printf("Result: %d\n", res);
    return 0;
}
