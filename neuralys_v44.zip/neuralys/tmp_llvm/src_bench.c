#include <stdio.h>
#include <stdlib.h>

#define N 256
#define BS 32 
#define UNROLL_FACTOR 4 

void compute(int A[N][N], int B[N][N], int C[N][N]) {
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            C[i][j] = 0;
        }
    }

    for (int ii = 0; ii < N; ii += BS) {
        for (int jj = 0; jj < N; jj += BS) {
            for (int kk = 0; kk < N; kk += BS) {
                for (int i = ii; i < ii + BS; i++) {
                    for (int k = kk; k < kk + BS; k++) {
                        int r_ik = A[i][k];
                        for (int j = jj; j < jj + BS; j += UNROLL_FACTOR) {
                            C[i][j]     += r_ik * B[k][j];
                            C[i][j+1]   += r_ik * B[k][j+1];
                            C[i][j+2]   += r_ik * B[k][j+2];
                            C[i][j+3]   += r_ik * B[k][j+3];
                        }
                    }
                }
            }
        }
    }
}

int main() {
    int (*A)[N] = malloc(sizeof(int[N][N]));
    int (*B)[N] = malloc(sizeof(int[N][N]));
    int (*C)[N] = malloc(sizeof(int[N][N]));
    
    if (!A || !B || !C) {
        fprintf(stderr, "Memory allocation failed\n");
        free(A); free(B); free(C);
        return 1;
    }

    for (int i=0; i<N; i++) {
        for (int j=0; j<N; j++) {
            A[i][j] = i+j;
            B[i][j] = i-j;
        }
    }

    compute(A, B, C);
    
    int sum = 0;
    for (int i=0; i<N; i++) sum += C[i][i];
    
    printf("Checksum: %d\n", sum);
    free(A); free(B); free(C);
    return 0;
}