import { DarwinDriver } from './src/core/engine';
import { KnowledgeBase } from './src/memory/knowledge_base';
import { generateBenchmarks } from './src/validation/benchmark_generator';
import * as fs from 'fs';

async function main() {
    const kb = new KnowledgeBase();
    const driver = new DarwinDriver(kb);
    const targets = generateBenchmarks().filter(b =>
        ['BubbleSort_var0', 'BFS_Simulated_var0', 'CountVowels_var0', 'SumSquares_var0'].includes(b.id)
    );

    const results = [];
    for (const t of targets) {
        console.log(`\n=== Evolving ${t.id} (${t.category}) ===`);
        const res = await driver.evolve(t.id, t.category, t.code, { generations: 4, populationCap: 8, runsPerEval: 20 });
        for (const g of res.generations) {
            console.log(`  Gen ${g.generation}: best=${g.bestLatencyMs.toFixed(4)}ms (${g.improvementVsSeedPct.toFixed(1)}% vs seed), pareto=${g.paretoFrontSize}, +${g.acceptedMutations}/-${g.rejectedMutations}`);
        }
        console.log(`  FINAL: ${res.totalImprovementPct.toFixed(1)}% | lineage: ${res.bestLineage.join(' -> ') || '(seed)'}`);
        results.push(res);
    }

    console.log(`\nKnowledge base: ${kb.getTotalMutations()} mutations recorded`);
    console.log('Strategy priors (global):');
    for (const s of kb.getStrategyStats()) {
        console.log(`  ${s.strategy}: ${s.successes}/${s.attempts} success, avg gain ${s.avgImprovementPct.toFixed(1)}%`);
    }
    fs.writeFileSync('darwin_experiment_report.json', JSON.stringify(results, null, 2));
    kb.close();
}
main().catch(e => { console.error(e); process.exit(1); });
