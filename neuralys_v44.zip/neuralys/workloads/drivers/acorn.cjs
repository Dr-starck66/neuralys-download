const acorn = require(process.env.NEURALYS_PKG);
const fs = require('fs'), path = require('path');
const dir = path.resolve('node_modules/simple-statistics/src');
const files = fs.readdirSync(dir).filter(f => f.endsWith('.js')).slice(0, 60);
for (const f of files) {
  const src = fs.readFileSync(path.join(dir, f), 'utf-8');
  try { acorn.parse(src, { ecmaVersion: 2022, sourceType: 'module' }); } catch (e) {}
  try { acorn.parseExpressionAt('1 + 2 * 3', 0, { ecmaVersion: 2022 }); } catch (e) {}
  try { [...acorn.tokenizer(src, { ecmaVersion: 2022, sourceType: 'module' })].length; } catch (e) {}
}
