const { Command } = require(process.env.NEURALYS_PKG);
for (let i = 0; i < 200; i++) {
  const p = new Command();
  p.exitOverride().name('demo').description('d').version('1.0.0')
    .option('-v, --verbose', 'verbose').option('-n, --number <n>', 'number', '3')
    .command('build').option('--watch', 'watch');
  try { p.parse(['node', 'demo', 'build', '--watch', '-n', String(i)]); } catch (e) {}
  try { p.helpInformation(); } catch (e) {}
}
