const semver = require(process.env.NEURALYS_PKG);
const vs = ['1.0.0', '2.3.4', '1.2.3-alpha.1', '0.0.1', '10.20.30', '2.0.0-rc.2'];
for (let i = 0; i < 120; i++) {
  for (const a of vs) {
    semver.valid(a); semver.clean(' ' + a + ' '); semver.major(a); semver.minor(a); semver.patch(a);
    semver.inc(a, 'patch'); semver.prerelease(a);
    for (const b of vs) { semver.gt(a, b); semver.lt(a, b); semver.eq(a, b); semver.compare(a, b); semver.diff(a, b); }
    semver.satisfies(a, '>=1.0.0 <3.0.0'); semver.coerce(a);
  }
}
