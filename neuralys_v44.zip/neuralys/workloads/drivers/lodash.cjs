/* Charge réelle : pipeline de traitement de données tel qu'on l'écrit en production.
   Aucune API n'est appelée « pour la démonstration » : ce sont les fonctions
   qu'un service de reporting utilise effectivement. */
const _ = require(process.env.NEURALYS_PKG);
const rows = [];
let s = 1337;
for (let i = 0; i < 4000; i++) {
  s = (Math.imul(s, 1103515245) + 12345) & 0x7fffffff;
  rows.push({
    id: i,
    region: ['eu', 'us', 'apac'][s % 3],
    amount: (s % 10000) / 100,
    tags: ['a', 'b', 'c'].slice(0, 1 + (s % 3)),
    createdAt: 1700000000 + (s % 1000000)
  });
}
for (let pass = 0; pass < 12; pass++) {
  const byRegion = _.groupBy(rows, 'region');
  const totals = _.mapValues(byRegion, rs => _.sumBy(rs, 'amount'));
  const top = _.take(_.orderBy(rows, ['amount'], ['desc']), 50);
  const uniqTags = _.uniq(_.flatten(_.map(rows, 'tags')));
  const chunks = _.chunk(rows, 250);
  const merged = _.merge({}, totals, { computedAt: Date.now() });
  const picked = _.map(top, r => _.pick(r, ['id', 'region', 'amount']));
  const keyed = _.keyBy(picked, 'id');
  const filtered = _.filter(rows, r => r.amount > 25 && r.region !== 'apac');
  const diffed = _.difference(_.map(rows, 'id'), _.map(filtered, 'id'));
  const cloned = _.cloneDeep(chunks[0]);
  const sorted = _.sortBy(rows, ['region', 'amount']);
  void [totals, uniqTags, merged, keyed, diffed, cloned, sorted.length];
}
