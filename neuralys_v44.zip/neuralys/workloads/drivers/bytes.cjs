const bytes = require(process.env.NEURALYS_PKG);
for (let i = 0; i < 2000; i++) { bytes(i * 1024); bytes.format(i * 3571); bytes.parse('1.5MB'); bytes.parse(String(i) + 'kb'); }
