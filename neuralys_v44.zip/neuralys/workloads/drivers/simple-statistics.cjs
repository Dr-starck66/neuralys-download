const ss = require(process.env.NEURALYS_PKG);
let s = 7; const rnd = () => { s = (Math.imul(s, 1103515245) + 12345) & 0x7fffffff; return s / 0x7fffffff; };
const xs = Array.from({ length: 500 }, () => rnd() * 100);
const ys = xs.map(x => x * 2 + rnd());
for (let i = 0; i < 30; i++) {
  ss.mean(xs); ss.median(xs); ss.mode(xs.map(Math.round)); ss.variance(xs); ss.standardDeviation(xs);
  ss.min(xs); ss.max(xs); ss.sum(xs); ss.quantile(xs, 0.9); ss.interquartileRange(xs);
  ss.linearRegression(xs.map((x, j) => [x, ys[j]])); ss.sampleCorrelation(xs, ys);
  ss.zScore(50, ss.mean(xs), ss.standardDeviation(xs)); ss.sampleSkewness(xs);
  ss.harmonicMean(xs.map(Math.abs)); ss.geometricMean(xs.map(Math.abs));
  ss.uniqueCountSorted(xs.map(Math.round).sort((a, b) => a - b));
  ss.medianAbsoluteDeviation(xs); ss.rootMeanSquare(xs); ss.sumNthPowerDeviations(xs, 2);
}
