const ct = require(process.env.NEURALYS_PKG);
for (let i = 0; i < 1500; i++) {
  const s = ct.format({ type: 'text/html', parameters: { charset: 'utf-8', boundary: 'b' + i } });
  ct.parse(s); ct.parse('application/json; charset=utf-8');
}
