const cookie = require(process.env.NEURALYS_PKG);
for (let i = 0; i < 500; i++) {
  const s = cookie.serialize('sid', 'abc' + i, { httpOnly: true, maxAge: 3600, path: '/', sameSite: 'lax' });
  cookie.parse(s);
  cookie.parse('a=1; b=2; c=hello%20world; d=' + i);
}
