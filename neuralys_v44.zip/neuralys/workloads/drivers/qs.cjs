const qs = require(process.env.NEURALYS_PKG);
const objs = [
  { a: 1, b: 'x', c: [1, 2, 3] },
  { user: { name: 'ada', tags: ['a', 'b'] }, page: 2 },
  { filter: { region: ['eu', 'us'], amount: { gt: 10 } } },
];
for (let i = 0; i < 200; i++) {
  for (const o of objs) { const str = qs.stringify(o); qs.parse(str); qs.parse(str, { depth: 10 }); }
  qs.parse('a[]=1&a[]=2&b[c]=3'); qs.stringify({ q: 'hello world', n: i }, { encode: true });
}
