function buildReport(rows, region) {
  const summary = [];
  for (let i = 0; i < 12; i++) {
    const byRegion = _.groupBy(rows, 'region');
    const totals = _.mapValues(byRegion, rs => _.sumBy(rs, 'amount'));
    const ranked = _.orderBy(rows, ['amount'], ['desc']);
    summary.push({
      pass: i,
      regions: Object.keys(totals).length,
      top: ranked[0] ? ranked[0].id : null,
      total: _.sumBy(rows, 'amount')
    });
  }
  return summary;
}
