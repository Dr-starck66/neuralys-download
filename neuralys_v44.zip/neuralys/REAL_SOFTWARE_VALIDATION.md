# Validation sur logiciel réel — résultat négatif, diagnostiqué

Objectif posé : prouver que Neuralys améliore du logiciel réel, pas des
exemples jouets. Le protocole a été exécuté. Voici ce qu'il donne.

## 1. Le pipeline complet fonctionne sur du vrai code

Nouvelle architecture, pilotée par la charge réelle plutôt que par des
entrées synthétiques (`src/tools/workload_analyzer.ts`,
`src/tools/project_evolver.ts`) :

1. **Enregistrement** — les fonctions exportées d'un paquet npm sont
   enveloppées, un scénario réel est exécuté, chaque appel est capturé
   (arguments, résultat, durée). Aucune modification du code source.
2. **Points chauds** — le classement vient du temps mesuré, pas d'une
   heuristique statique. Sur une charge de reporting exerçant lodash :
   `orderBy` 50,2 % du temps, `sortBy` 15,0 %, `mapValues` 9,6 %,
   `cloneDeep` 9,6 %.
3. **Preuve par rejeu** — l'équivalence se vérifie sur les appels
   RÉELLEMENT observés, avec les sorties RÉELLEMENT observées.
4. **Mutation en contexte** — le paquet entier est copié dans un espace de
   travail, le fichier de la fonction y est réécrit, un processus enfant
   charge le paquet et rejoue le corpus. Les `require` internes fonctionnent :
   c'est ce qui permet de muter du code de bibliothèque plutôt que des
   fonctions isolées.

Cette architecture lève les quatre blocages mesurés en v31 (arité, types,
appels externes, méthodes de classe) parce qu'elle n'émet plus aucune
hypothèse sur la forme des entrées.

## 2. Le résultat, sans mise en scène

| Projet | Fonctions | Avec boucle | Mutables par la bibliothèque de règles |
|---|---|---|---|
| lodash | 474 | 91 | **0 (0,0 %)** |
| acorn | 3 | 1 | 0 |
| astring | 11 | 6 | 1 (9,1 %) |
| express | 11 | 2 | 1 (9,1 %) |

**2 fonctions mutables sur 499**, et les deux sont hors chemin critique :
`_defineProperties` (assistant Babel appelé une fois par classe) et
`sendfile` (dominé par les entrées-sorties). Aucun gain n'est atteignable
sur cette base.

Sur les six points chauds de lodash, le pipeline a produit **0 candidat**,
donc **0 mutation acceptée** — et surtout **aucune régression introduite**.

## 3. Diagnostic mécanistique

Les règles ciblent des motifs NAÏFS : tri à bulles, `.length` non hissé,
`filter().length`, appartenance par `indexOf`. Le code de production ne les
contient pas — ses auteurs, ses linters et le JIT les ont déjà éliminés.
91 fonctions de lodash contiennent des boucles ; aucune ne déclenche une
règle, parce que ces boucles sont déjà au minimum local pour ces
transformations.

Corollaire à énoncer clairement : les gains mesurés jusqu'ici (jusqu'à +97 %)
proviennent d'un corpus de code volontairement naïf. C'est un corpus
pédagogique, pas un échantillon de production. **Ils ne prédisent rien sur du
logiciel réel.**

## 4. Ce que ce résultat change dans la feuille de route

Par valeur attendue décroissante :

1. **Mutations proposées par LLM sur les points chauds réels.** C'est la
   seule source de transformations qui ne soit pas pré-encodée par moi. La
   pièce qui manquait n'était pas la génération mais la VÉRIFICATION sur du
   vrai code — le rejeu de corpus la fournit désormais. Nécessite une
   authentification (`claude login`) que ce conteneur n'a pas.
2. **Optimisation au niveau appelant plutôt qu'à l'intérieur des
   bibliothèques.** Le gain applicatif réel n'est pas dans `orderBy` mais
   dans le fait de l'appeler douze fois sur les mêmes données au lieu
   d'indexer une fois. C'est une classe de mutation entièrement absente du
   moteur.
3. **Règles orientées allocation** (tableaux intermédiaires, copies
   défensives). Le code de production en contient ; le moteur n'en cible
   aucune.

## 5. Reproduire

```bash
npm test                                  # 38 tests, dont l'enregistrement réel
npx tsx cli.ts workload lodash workloads/lodash_driver.cjs
```
