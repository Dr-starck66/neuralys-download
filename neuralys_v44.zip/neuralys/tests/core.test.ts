import { test } from 'node:test';
import assert from 'node:assert';
import { NSGA2 } from '../src/algorithms/nsga2';
import { Canonicalizer } from '../src/core/canonicalizer';
import { ThompsonPolicy, UCB1Policy } from '../src/core/selection_policies';

const SEED_BUBBLE = `function processPayload(arr) {
  const a = arr.slice();
  for (let i = 0; i < a.length; i++) {
    for (let j = 0; j < a.length - i - 1; j++) {
      if (a[j] > a[j + 1]) {
        const tmp = a[j];
        a[j] = a[j + 1];
        a[j + 1] = tmp;
      }
    }
  }
  return a[0] + a.length;
}`;

test('NSGA2: dominated solution never in front 0', () => {
    const mk = (id: string, o: number[]) => ({ id, branchName: id, objectives: o, dominationCount: 0, dominatedSolutions: [], rank: -1, crowdingDistance: 0 });
    const pop = [mk('a', [1, 1]), mk('b', [2, 2]), mk('c', [1, 3]), mk('d', [3, 1])];
    const fronts = NSGA2.fastNonDominatedSort(pop);
    assert.ok(fronts[0].some(c => c.id === 'a'));
    assert.ok(!fronts[0].some(c => c.id === 'b')); // dominated by a
});

test('Canonicalizer: alpha-equivalence merges, semantics separates', () => {
    const c = new Canonicalizer();
    const h1 = c.canonicalHash('function f(a) { let x = 0; for (let i = 0; i < a.length; i++) { x += a[i]; } return x; }');
    const h2 = c.canonicalHash('function f(arr) { let sum = 0; for (let k = 0; k < arr.length; k++) { sum += arr[k]; } return sum; }');
    const h3 = c.canonicalHash('function f(a) { let x = 1; for (let i = 0; i < a.length; i++) { x += a[i]; } return x; }');
    assert.strictEqual(h1, h2);
    assert.notStrictEqual(h1, h3);
});

test('Thompson: posterior concentrates on the better arm', () => {
    const p = new ThompsonPolicy(['good', 'bad'], []);
    for (let i = 0; i < 200; i++) { p.update('good', true, 10); p.update('bad', false, 0); }
    let wins = 0;
    for (let i = 0; i < 100; i++) if (p.rank()[0].strategy === 'good') wins++;
    assert.ok(wins > 90, `good ranked first only ${wins}/100`);
});

test('UCB1: untested arm explored first', () => {
    const p = new UCB1Policy(['tested', 'fresh'], [{ strategy: 'tested', attempts: 10, successes: 9, avgImprovementPct: 50 }]);
    assert.strictEqual(p.rank()[0].strategy, 'fresh');
});

test('Hypervolume: front amélioré => HV strictement supérieur, stagnation détectée sur plateau', async () => {
    const { HypervolumeTracker } = await import('../src/algorithms/hypervolume.ts');
    const ref = [10, 10];
    const weak = HypervolumeTracker.estimate([[8, 8]], ref);
    const strong = HypervolumeTracker.estimate([[2, 2]], ref);
    assert.ok(strong > weak, `HV(strong)=${strong} <= HV(weak)=${weak}`);
    const t = new HypervolumeTracker();
    t.record([[5, 5]], ref); t.record([[5, 5]], ref); t.record([[5, 5]], ref);
    assert.ok(t.isStagnant(2), 'plateau must be detected');
});

test('Mémoire de contre-exemples: divergence trouvée => persistée => rejoue contre les mutations futures', async () => {
    const { KnowledgeBase } = await import('../src/memory/knowledge_base.ts');
    const { AdvancedSemanticGuardian } = await import('../src/validation/semantic_guardian.ts');
    const fs = await import('fs');
    const db = '/tmp/neuralys_ce.db';
    if (fs.existsSync(db)) fs.unlinkSync(db);
    const kb = new KnowledgeBase(db);
    const g = new AdvancedSemanticGuardian();
    const orig = 'function processPayload(arr) { let s = 0; for (let i = 0; i < arr.length; i++) s += arr[i]; return s; }';
    const wrong = 'function processPayload(arr) { let s = 0; for (let i = 1; i < arr.length; i++) s += arr[i]; return s; }';
    const v = await g.evaluateEquivalence(orig, wrong);
    assert.strictEqual(v.passed, false);
    assert.ok(v.counterexample !== undefined, 'guardian must surface the counterexample');
    kb.storeCounterexample('sig-test', v.counterexample, 'unit');
    const stored = kb.getCounterexamples('sig-test');
    assert.ok(stored.length === 1, 'counterexample persisted');
    // the stored CE alone must kill the same wrong mutation via extraInputs
    const v2 = await g.evaluateEquivalence(orig, wrong, stored);
    assert.strictEqual(v2.passed, false);
    kb.close();
    fs.unlinkSync(db);
});

test('Mutation par intention: filter().length → boucle de comptage, équivalence prouvée', async () => {
    const { ASTMutator } = await import('../src/core/ast_mutator.ts');
    const { AdvancedSemanticGuardian } = await import('../src/validation/semantic_guardian.ts');
    const code = 'function processPayload(arr) { return arr.filter(x => x > 10).length + arr.length; }';
    const m = new ASTMutator();
    const out = m.getRules().find(r => r.name === 'intent_filter_count')!.apply(code);
    assert.notStrictEqual(out, code, 'intent rule must fire');
    assert.ok(!out.includes('.filter('), 'intermediate array eliminated');
    const v = await new AdvancedSemanticGuardian().evaluateEquivalence(code, out);
    assert.strictEqual(v.passed, true, v.issues.join('|'));
});

test('Mutation par intention: map().reduce(+) fusionné en une passe, équivalence prouvée', async () => {
    const { ASTMutator } = await import('../src/core/ast_mutator.ts');
    const { AdvancedSemanticGuardian } = await import('../src/validation/semantic_guardian.ts');
    const code = 'function processPayload(arr) { return arr.map(x => x * x).reduce((a, b) => a + b, 0); }';
    const m = new ASTMutator();
    const out = m.getRules().find(r => r.name === 'intent_map_reduce_fusion')!.apply(code);
    assert.notStrictEqual(out, code);
    assert.ok(!out.includes('.map(') && !out.includes('.reduce('), 'fused into one loop');
    const v = await new AdvancedSemanticGuardian().evaluateEquivalence(code, out);
    assert.strictEqual(v.passed, true, v.issues.join('|'));
});

test('Oracle génératif: les frontières du code muté sont ciblées et attrapent le bug boundary', async () => {
    const { generateAdversarialInputs } = await import('../src/validation/adversarial_generator.ts');
    const { AdvancedSemanticGuardian } = await import('../src/validation/semantic_guardian.ts');
    const orig = 'function processPayload(arr) { let c = 0; for (let i = 0; i < arr.length; i++) { if (Math.abs(arr[i]) % 26 < 13) c++; } return c; }';
    // mutation cassée EXACTEMENT sur la frontière 13 (<= au lieu de <)
    const broken = orig.replace('% 26 < 13', '% 26 <= 13');
    const adv = generateAdversarialInputs(orig, broken);
    assert.ok(adv.some(a => a.includes(13)), 'boundary 13 must be generated');
    assert.ok(adv.some(a => a.includes(26)), 'literal 26 must be generated');
    const v = await new AdvancedSemanticGuardian().evaluateEquivalence(orig, broken);
    assert.strictEqual(v.passed, false, 'boundary bug must be caught');
});

test('Arbre phylogénétique: contre-exemples annotés sur les nœuds rejetés', async () => {
    const { KnowledgeBase } = await import('../src/memory/knowledge_base.ts');
    const { LineageIO } = await import('../src/tools/lineage_io.ts');
    const fs = await import('fs');
    const db = '/tmp/phylo.db';
    if (fs.existsSync(db)) fs.unlinkSync(db);
    const kb = new KnowledgeBase(db);
    const h1 = kb.storeArtifact('function processPayload(a){return 0;}');
    const h2 = kb.storeArtifact('function processPayload(a){return 1;}');
    kb.recordMutation({ experimentId: 'e', generation: 1, benchmarkId: 'b', category: 'c',
        parentHash: h1, variantHash: h2, strategy: 'bad_rule', accepted: false,
        rejectionReason: 'semantic', latencyMean: null, latencyImprovementPct: null,
        memoryMb: null, complexity: null, pValue: null, reasoning: 'x', signature: 's' });
    kb.storeCounterexample('s', [42], 'bad_rule', h2);
    const tree = new LineageIO(kb).renderTree(h1);
    assert.ok(tree.includes('✗') && tree.includes('contre-exemple #') && tree.includes('[42]'));
    kb.close(); fs.unlinkSync(db);
});

test('Invariants: mutation qui MUTE l\'entrée passe le fuzzing différentiel mais est rejetée par l\'invariant nommé', async () => {
    const { AdvancedSemanticGuardian } = await import('../src/validation/semantic_guardian.ts');
    // seed: trie une COPIE — l'argument reste intact
    const seed = 'function processPayload(arr) { const a = arr.slice(); a.sort((x, y) => x - y); return a[0] + a.length; }';
    // mutant: trie EN PLACE — retourne exactement la même valeur (le fuzzing
    // différentiel sur les sorties ne peut pas le distinguer), mais détruit
    // l'ordre du tableau appelant. Classe de bug que seul l'invariant attrape.
    const mutant = 'function processPayload(arr) { arr.sort((x, y) => x - y); return arr[0] + arr.length; }';
    const v = await new AdvancedSemanticGuardian().evaluateEquivalence(seed, mutant);
    assert.strictEqual(v.fuzzingPassed, true, 'les sorties sont identiques: le fuzzing seul ne voit rien');
    assert.ok(v.invariantsViolated.includes('input_not_mutated'), `violation attendue, obtenu: ${JSON.stringify(v.invariantsViolated)}`);
    assert.strictEqual(v.passed, false, 'la mutation doit être rejetée');
    assert.ok(v.issues.some(i => i.includes('input_not_mutated')), 'diagnostic nommé attendu');
});

test('Invariants: profil VÉRIFIÉ, jamais supposé (order_insensitive absent quand faux)', async () => {
    const { InvariantExtractor } = await import('../src/validation/invariant_extractor.ts');
    const ex = new InvariantExtractor();
    const sum = ex.extract('function processPayload(arr) { let s = 0; for (let i = 0; i < arr.length; i++) s += arr[i]; return s; }');
    assert.ok(sum.invariants.includes('order_insensitive'), 'une somme est insensible à l\'ordre');
    assert.ok(sum.invariants.includes('input_not_mutated'));
    const first = ex.extract('function processPayload(arr) { return (arr[0] || 0) * 2; }');
    assert.ok(!first.invariants.includes('order_insensitive'), 'lire arr[0] dépend de l\'ordre: invariant NON revendiqué');
});

test('Intention : le tri croissant est reconnu sous ses deux formes (idiome et appel)', async () => {
    const { IntentDetector } = await import('../src/core/algorithm_space.ts');
    const d = new IntentDetector();
    const bubble = 'function processPayload(arr) { const a = arr.slice(); for (let i = 0; i < a.length; i++) { for (let j = 0; j < a.length - i - 1; j++) { if (a[j] > a[j+1]) { const t = a[j]; a[j] = a[j+1]; a[j+1] = t; } } } return a[0]; }';
    const called = 'function processPayload(arr) { const a = arr.slice(); a.sort((x, y) => x - y); return a[0]; }';
    const none = 'function processPayload(arr) { let s = 0; for (let i = 0; i < arr.length; i++) s += arr[i]; return s; }';
    assert.ok(d.detectSort(bubble), 'idiome compare-échange');
    assert.ok(d.detectSort(called), 'appel .sort comparatif');
    assert.strictEqual(d.detectSort(none), null, 'une somme n\'est pas un tri');
});

test('Espace de recherche : l\'ordre d\'exploration dépend du profil de données observé', async () => {
    const { AlgorithmSpace, profileInputs } = await import('../src/core/algorithm_space.ts');
    const space = new AlgorithmSpace();
    const bubble = 'function processPayload(arr) { const a = arr.slice(); for (let i = 0; i < a.length; i++) { for (let j = 0; j < a.length - i - 1; j++) { if (a[j] > a[j+1]) { const t = a[j]; a[j] = a[j+1]; a[j+1] = t; } } } return a[0]; }';

    const sorted = profileInputs([Array.from({ length: 500 }, (_, i) => i)]);
    const wide = profileInputs([Array.from({ length: 500 }, (_, i) => i * 100000)]);
    const first = (p: any) => space.generate(bubble, p)[0].strategy;

    assert.strictEqual(first(sorted), 'algo:insertion_sort', 'données presque triées → tri par insertion en tête');
    assert.ok(first(wide) !== 'algo:counting_sort', 'étendue énorme → le tri par comptage n\'est pas prioritaire');
    const generated = space.generate(bubble, sorted);
    assert.ok(generated.length >= 6, 'la famille entière est explorée, pas un seul choix');
    assert.ok(generated.some(c => c.strategy === 'algo:adaptive_dispatch'), 'le génome adaptatif fait partie de l\'espace');
});

test('Substitution algorithmique : tous les candidats générés sont prouvés équivalents', async () => {
    const { AlgorithmSpace, profileInputs } = await import('../src/core/algorithm_space.ts');
    const { AdvancedSemanticGuardian } = await import('../src/validation/semantic_guardian.ts');
    const { SandboxRunner } = await import('../src/validation/sandbox_runner.ts');
    const bubble = SEED_BUBBLE;
    const profile = profileInputs(SandboxRunner.benchmarkInputs());
    const cands = new AlgorithmSpace().generate(bubble, profile);
    assert.ok(cands.length >= 4, 'plusieurs implémentations candidates');
    const g = new AdvancedSemanticGuardian();
    for (const c of cands) {
        const v = await g.evaluateEquivalence(bubble, c.code);
        assert.strictEqual(v.passed, true, `${c.strategy} doit être prouvé équivalent (${v.issues.join('|')})`);
    }
});

test('L\'espace algorithmique bat la règle écrite à la main sur le même benchmark', async () => {
    const { AlgorithmSpace, profileInputs } = await import('../src/core/algorithm_space.ts');
    const { ASTMutator } = await import('../src/core/ast_mutator.ts');
    const { SandboxRunner } = await import('../src/validation/sandbox_runner.ts');
    const r = new SandboxRunner();
    // Minimum de trois campagnes : estimateur robuste aux pics de bruit et au
    // JIT froid. Une assertion adossée à une mesure doit être protégée du
    // bruit, sinon elle échoue une fois sur N sans qu'aucun code n'ait changé.
    const avg = (code: string) => {
        let best = Infinity;
        for (let k = 0; k < 3; k++) {
            const s = r.executeCodeBenchmark(code, 15).map(x => x.latencyMs);
            best = Math.min(best, s.reduce((a, b) => a + b, 0) / s.length);
        }
        return best;
    };
    const handwritten = new ASTMutator().getRules().find(x => x.name === 'sort_idiom_recognition')!.apply(SEED_BUBBLE);
    const generated = new AlgorithmSpace().generate(SEED_BUBBLE, profileInputs(SandboxRunner.benchmarkInputs()))[0];
    const base = avg(SEED_BUBBLE), hw = avg(handwritten), gen = avg(generated.code);
    assert.ok(hw < base && gen < base, 'les deux améliorent le seed');
    assert.ok(gen < hw, `le candidat généré (${gen.toFixed(4)}ms) doit battre la règle figée (${hw.toFixed(4)}ms)`);
});

test('Profileur : la densité d\'inversions sépare ce que l\'ordre local confond', async () => {
    const { profileRuntime } = await import('../src/core/selection_intelligence.ts');
    // Deux jeux qui ont le MÊME ordre local (~0,95) mais des coûts de tri opposés
    const quasiTrie = Array.from({ length: 2000 }, (_, i) => i);
    for (let k = 0; k + 1 < 2000; k += 50) { const t = quasiTrie[k]; quasiTrie[k] = quasiTrie[k + 1]; quasiTrie[k + 1] = t; }
    const localementOrdonne = Array.from({ length: 2000 }, (_, i) => (Math.imul(i, 48271) % 2147483647) % 1000000);

    const localOrder = (a: number[]) => { let o = 0; for (let i = 1; i < a.length; i++) if (a[i - 1] <= a[i]) o++; return o / (a.length - 1); };
    assert.ok(localOrder(quasiTrie) > 0.9 && localOrder(localementOrdonne) > 0.9, 'les deux paraissent triés localement');

    const p1 = profileRuntime(quasiTrie), p2 = profileRuntime(localementOrdonne);
    assert.ok(p1.inversionDensity < 0.05, `quasi trié doit avoir peu d'inversions, obtenu ${p1.inversionDensity}`);
    assert.ok(p2.inversionDensity > 0.3, `désordre global doit se voir, obtenu ${p2.inversionDensity}`);
});

test('Génome adaptatif : prouvé équivalent et il choisit la bonne branche', async () => {
    const { AlgorithmSpace, profileInputs } = await import('../src/core/algorithm_space.ts');
    const { AdvancedSemanticGuardian } = await import('../src/validation/semantic_guardian.ts');
    const cands = new AlgorithmSpace().generate(SEED_BUBBLE, profileInputs([[3, 1, 2]]));
    const adaptive = cands.find(c => c.strategy === 'algo:adaptive_dispatch');
    assert.ok(adaptive, 'un candidat adaptatif doit être généré');
    const v = await new AdvancedSemanticGuardian().evaluateEquivalence(SEED_BUBBLE, adaptive!.code);
    assert.strictEqual(v.passed, true, `le génome adaptatif doit être prouvé équivalent (${v.issues.join('|')})`);
    assert.ok(adaptive!.code.includes('__ns_insertion_sort') && adaptive!.code.includes('__ns_counting_sort'),
        'le génome embarque plusieurs branches algorithmiques');
});

test('Validation adversariale : chaque implémentation figée a un jeu qui la met en défaut', async () => {
    const { AlgorithmSpace, profileInputs } = await import('../src/core/algorithm_space.ts');
    const { ADVERSARIAL_DATASETS } = await import('../src/core/selection_intelligence.ts');
    const compile = (c: string) => new Function(`"use strict"; ${c}; return processPayload;`)();
    const bench = (fn: any, d: number[]) => {
        for (let w = 0; w < 25; w++) fn(d.slice());
        let best = Infinity;
        for (let k = 0; k < 2; k++) {
            const t0 = process.hrtime.bigint();
            for (let r = 0; r < 120; r++) fn(d.slice());
            best = Math.min(best, Number(process.hrtime.bigint() - t0) / 1e6 / 120);
        }
        return best;
    };
    const cands = new AlgorithmSpace().generate(SEED_BUBBLE, profileInputs([[1, 2, 3]]));
    const worst: Record<string, number> = {};
    const perDataset: Record<string, number>[] = [];
    for (const ds of ADVERSARIAL_DATASETS) {
        const data = ds.build(1500);
        const row: Record<string, number> = {};
        for (const c of cands) {
            const t = bench(compile(c.code), data);
            const k = c.strategy.slice(5);
            row[k] = t;
            worst[k] = Math.max(worst[k] ?? 0, t);
        }
        perDataset.push(row);
    }
    const adaptive = worst['adaptive_dispatch'];
    const fixedWorst = Object.entries(worst).filter(([k]) => k !== 'adaptive_dispatch').map(([, v]) => v).sort((a, b) => a - b);
    const median = fixedWorst[Math.floor(fixedWorst.length / 2)];
    // Affirmation structurelle plutôt que ratio de dispersion (sensible au
    // bruit) : AUCUNE implémentation figée ne domine — chacune est battue
    // d'un facteur 2 par une autre sur au moins une distribution. C'est
    // exactement ce que la recherche adversariale doit exhiber.
    const names = cands.map(c => c.strategy.slice(5)).filter(n => n !== 'adaptive_dispatch');
    for (const n of names) {
        const beaten = perDataset.some(row => names.some(other => other !== n && row[other] * 2 < row[n]));
        assert.ok(beaten, `${n} devrait être nettement battue par une autre implémentation sur au moins une distribution`);
    }
    // Assertion de RANG plutôt que de ratio : robuste au bruit de mesure tout
    // en portant la même affirmation — le dispatcher borne mieux son pire cas
    // que la majorité des choix figés.
    assert.ok(adaptive < median,
        `le pire cas adaptatif (${adaptive.toFixed(3)}) doit battre la médiane des pires cas figés (${median.toFixed(3)})`);
});

test('Apprentissage : la base répond « qui gagne pour cette classe de profil »', async () => {
    const { KnowledgeBase } = await import('../src/memory/knowledge_base.ts');
    const { profileRuntime, profileClass } = await import('../src/core/selection_intelligence.ts');
    const fs = await import('fs');
    const db = '/tmp/neuralys_algo_kb.db';
    if (fs.existsSync(db)) fs.unlinkSync(db);
    const kb = new KnowledgeBase(db);
    kb.registerAlgorithm({ name: 'counting_sort', family: 'sort_ascending', timeComplexity: 'O(n + k)', memoryBehavior: 'O(k)', inputConditions: 'petite étendue' });

    const cls = profileClass(profileRuntime(Array.from({ length: 1000 }, (_, i) => i % 50)));
    for (let i = 0; i < 5; i++) kb.recordAlgorithmOutcome('counting_sort', cls, true, 90 + i, 0.02);
    for (let i = 0; i < 5; i++) kb.recordAlgorithmOutcome('insertion_sort', cls, false, 0, 1.5);

    const ranked = kb.bestAlgorithmsForClass(cls);
    assert.strictEqual(ranked[0].algorithm, 'counting_sort');
    assert.strictEqual(ranked[0].winRate, 1);
    assert.ok(ranked[0].avgImprovementPct > 89);
    assert.strictEqual(ranked[0].meta.time_complexity, 'O(n + k)', 'le graphe porte la complexité');
    assert.ok(kb.knownProfileClasses().some(c => c.profile_class === cls));
    kb.close(); fs.unlinkSync(db);
});

test('Appelant : un appel pur invariant est hissé hors de la boucle, sorties inchangées', async () => {
    const { CallerOptimizer } = await import('../src/core/caller_optimizer.ts');
    const opt = new CallerOptimizer({ pure: new Set(['heavy']), impure: new Set() });
    const src = `function run(rows) {
  let acc = 0;
  for (let i = 0; i < 5; i++) { const g = heavy(rows, 'k'); acc += g.length; }
  return acc;
}`;
    const m = opt.applyHoistInvariantCall(src);
    assert.ok(m, 'la règle doit déclencher');
    assert.ok(m!.code.includes('const __hoisted_heavy'), 'un temporaire est introduit');
    let calls = 0;
    const heavy = (r: any[], _k: string) => { calls++; return r; };
    const before = new Function('heavy', `${src}; return run;`)(heavy);
    const rows = [1, 2, 3];
    const expected = before(rows);
    calls = 0;
    const after = new Function('heavy', `${m!.code}; return run;`)(heavy);
    const got = after(rows);
    assert.strictEqual(got, expected, 'même résultat');
    assert.strictEqual(calls, 1, `l'appel doit être évalué une seule fois, obtenu ${calls}`);
});

test('Appelant : contrôle négatif — une fonction observée IMPURE n\'est jamais hissée', async () => {
    const { CallerOptimizer } = await import('../src/core/caller_optimizer.ts');
    const src = `function run(rows) {
  let acc = 0;
  for (let i = 0; i < 5; i++) { const g = mutator(rows, 'k'); acc += g.length; }
  return acc;
}`;
    // preuve d'impureté observée → refus
    const guarded = new CallerOptimizer({ pure: new Set(), impure: new Set(['mutator']) });
    assert.strictEqual(guarded.applyHoistInvariantCall(src), null, 'une fonction impure ne doit pas être hissée');
    // absence de preuve → refus également (la pureté ne se suppose pas)
    const blind = new CallerOptimizer();
    assert.strictEqual(blind.applyHoistInvariantCall(src), null, 'sans preuve de pureté, la règle refuse');
});

test('Appelant : la pureté vient de l\'observation (args avant/après) et détecte une mutation', async () => {
    const { CallRecorder } = await import('../src/tools/workload_analyzer.ts');
    const { createRequire } = await import('module');
    const path = await import('path');
    const req = createRequire(import.meta.url);
    const rec = new CallRecorder().record(req.resolve('lodash'), path.resolve('workloads/lodash_driver.cjs'));
    const merge = rec.functions.find(f => f.name === 'merge');
    const groupBy = rec.functions.find(f => f.name === 'groupBy');
    assert.ok(merge && groupBy, 'les deux fonctions sont exercées par la charge');
    assert.strictEqual(merge!.observedNonMutating, false, '_.merge modifie son premier argument — détecté par comparaison avant/après');
    assert.strictEqual(groupBy!.observedPure, true, '_.groupBy est observée pure');
});

test('Évaluation : les intervalles de Wilson sont corrects, y compris à 0 succès', async () => {
    const { wilson, bootstrapCI } = await import('../src/tools/evaluation_suite.ts');
    const zero = wilson(0, 15);
    assert.strictEqual(zero.rate, 0);
    assert.ok(zero.ci95[0] === 0 && zero.ci95[1] > 0.15 && zero.ci95[1] < 0.30,
        `0/15 doit donner une borne supérieure ~21 %, obtenu ${(zero.ci95[1] * 100).toFixed(1)}`);
    const one = wilson(1, 15);
    assert.ok(one.ci95[0] > 0 && one.ci95[0] < 0.02 && one.ci95[1] > 0.25,
        `1/15 doit donner [~1 % ; ~30 %], obtenu [${(one.ci95[0] * 100).toFixed(1)} ; ${(one.ci95[1] * 100).toFixed(1)}]`);
    // Wald donnerait [0;0] pour 0/15 — c'est précisément le piège que Wilson évite
    const boot = bootstrapCI([4.7, 6.0, 5.4]);
    assert.ok(boot.mean > 5.3 && boot.mean < 5.4 && boot.ci95[0] >= 4.7 && boot.ci95[1] <= 6.0);
});

test('Capture universelle : toutes les formes de fonction sont instrumentées et rejouables', async () => {
    const { ExecutionInstrumenter, RECORDER_RUNTIME } = await import('../src/tools/execution_capture.ts');
    const src = `
function libre(a, b) { return a + b; }
const flechee = (a, b) => a * b;
class Boite {
  constructor(v) { this.v = v; }
  echelle(k) { this.v = this.v * k; return this.v; }
  async charge(x) { return x + this.v; }
}
function avecReste(...xs) { let s = 0; for (const x of xs) s += x; return s; }
function externe(n) { function interne(k) { return k * 2; } return interne(n) + 1; }
function* generateur() { yield 1; }
module.exports = { libre, flechee, Boite, avecReste, externe };
`;
    const { code, stats } = new ExecutionInstrumenter().instrument(src, 'demo.js');
    assert.strictEqual(stats.instrumented, 7, `7 formes doivent être enveloppées, obtenu ${stats.instrumented}`);
    assert.ok(stats.skipped['générateur (yield non enveloppable)'] === 1, 'le générateur est refusé explicitement, pas silencieusement');

    const mod: any = { exports: {} };
    const NR = new Function('module', 'exports', 'process', RECORDER_RUNTIME + '\n' + code + '\n; return globalThis.__NR;')(mod, mod.exports, process);
    const M = mod.exports;
    assert.strictEqual(M.libre(2, 3), 5, 'la sémantique de retour est préservée');
    assert.strictEqual(M.flechee(4, 5), 20, 'flèche à corps d\'expression préservée');
    const b = new M.Boite(10);
    assert.strictEqual(b.echelle(3), 30, 'méthode et this préservés');
    assert.strictEqual(M.avecReste(1, 2, 3), 6, 'paramètres rest préservés');
    assert.strictEqual(M.externe(7), 15, 'fonction imbriquée préservée');
    assert.strictEqual(await b.charge(5), 35, 'fonction asynchrone préservée');

    const dump = NR.dump();
    const ids = dump.map((d: any) => d.id.split('#')[1]);
    for (const expected of ['libre', 'flechee', 'Boite.echelle', 'avecReste', 'externe', 'interne', 'Boite.charge']) {
        assert.ok(ids.includes(expected), `${expected} doit être capturée`);
    }
    // Effet de bord observable détecté sans annotation ni supposition
    const scale = dump.find((d: any) => d.id.endsWith('#Boite.echelle'));
    assert.strictEqual(scale.mutatesThis, true, 'la mutation de this est détectée par comparaison avant/après');
    assert.strictEqual(dump.find((d: any) => d.id.endsWith('#libre')).mutatesArgs, false);
});
