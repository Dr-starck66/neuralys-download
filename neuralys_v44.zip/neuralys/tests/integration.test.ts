import { test } from 'node:test';
import assert from 'node:assert';
import * as fs from 'fs';
import { KnowledgeBase } from '../src/memory/knowledge_base.ts';
import { DarwinDriver } from '../src/core/engine.ts';
import { LineageIO } from '../src/tools/lineage_io.ts';
import { createApi } from '../src/api/server.ts';
import { AdvancedSemanticGuardian } from '../src/validation/semantic_guardian.ts';
import { SandboxRunner } from '../src/validation/sandbox_runner.ts';

const SEED = `function processPayload(arr) {
    const a = arr.slice();
    for (let i = 0; i < a.length; i++) {
        for (let j = 0; j < a.length - i - 1; j++) {
            if (a[j] > a[j + 1]) {
                const tmp = a[j]; a[j] = a[j + 1]; a[j + 1] = tmp;
            }
        }
    }
    return a[0] + a.length;
}`;

const DB = '/tmp/neuralys_itest.db';
if (fs.existsSync(DB)) fs.unlinkSync(DB);
const kb = new KnowledgeBase(DB);

test('mémoire génétique + apprentissage + population + crossover + Pareto + benchmark statistique (evolve end-to-end)', async () => {
    const driver = new DarwinDriver(kb);
    const res = await driver.evolve('itest', 'Sorting', SEED, { generations: 2, populationCap: 6, runsPerEval: 12 });
    assert.ok(res.totalImprovementPct > 30, `expected real gain, got ${res.totalImprovementPct}`);
    assert.ok(kb.getTotalMutations() > 0, 'KB must record mutations');
    assert.ok(res.generations[0].paretoFrontSize >= 1, 'Pareto front must exist');
    assert.ok(res.generations[0].metaPolicyState.length === 2, 'meta-policy learning active');
});

test('vérification équivalence: mutation fausse rejetée', async () => {
    const g = new AdvancedSemanticGuardian();
    const wrong = SEED.replace('return a[0] + a.length;', 'return a.length;');
    const v = await g.evaluateEquivalence(SEED, wrong);
    assert.strictEqual(v.passed, false);
});

test('sandbox: crash → passRate 0, jamais d\'exception', () => {
    const r = new SandboxRunner().executeCodeBenchmark('function processPayload(arr) { throw new Error("boom"); }', 3);
    assert.ok(r.every(x => x.testPassRate === 0));
});

test('export → import → replay reproduit un gain réel', async () => {
    const seedHash = KnowledgeBase.hashCode(SEED);
    const io = new LineageIO(kb);
    const bundle = io.export(seedHash);
    assert.ok(bundle.edges.length > 0 && Object.keys(bundle.artifacts).length > 1);

    const kb2 = new KnowledgeBase('/tmp/neuralys_itest2.db');
    const imported = new LineageIO(kb2).import(bundle);
    assert.ok(imported.artifacts > 1 && imported.edges > 0);

    const replay = await io.replay(seedHash);
    assert.ok(replay.steps.length > 0 && replay.steps.every(s => s.equivalent), 'replay steps must re-validate');
    assert.ok(replay.finalImprovementPct > 30, `replay must reproduce the gain, got ${replay.finalImprovementPct}`);
    kb2.close();
    fs.unlinkSync('/tmp/neuralys_itest2.db');
});

test('observabilité: arbre généalogique rendu', () => {
    const io = new LineageIO(kb);
    const tree = io.renderTree(KnowledgeBase.hashCode(SEED));
    assert.ok(tree.includes('seed') && tree.includes('sort_idiom'));
});

test('API REST: health + strategies + artifacts', async () => {
    const app = createApi(kb);
    const server = app.listen(0);
    const port = (server.address() as any).port;
    const health = await (await fetch(`http://127.0.0.1:${port}/health`)).json();
    assert.strictEqual(health.ok, true);
    const strategies = await (await fetch(`http://127.0.0.1:${port}/strategies`)).json();
    assert.ok(Array.isArray(strategies) && strategies.length > 0 && 'survival' in strategies[0]);
    const art = await (await fetch(`http://127.0.0.1:${port}/artifacts/${KnowledgeBase.hashCode(SEED)}`)).json();
    assert.ok(art.code.includes('processPayload'));
    server.close();
});

test('fédération: nœud B hérite mutations + contre-exemples + priors du nœud A', async () => {
    const { FederationSync } = await import('../src/tools/federation.ts');
    const kbA = new KnowledgeBase('/tmp/fed_a.db');
    const kbB = new KnowledgeBase('/tmp/fed_b.db');
    const h1 = kbA.storeArtifact('function processPayload(a){return 1;}');
    const h2 = kbA.storeArtifact('function processPayload(a){return 1;;}');
    kbA.recordMutation({ experimentId: 'fedexp', generation: 1, benchmarkId: 'x', category: 'Fed',
        parentHash: h1, variantHash: h2, strategy: 'sort_idiom_recognition', accepted: true,
        rejectionReason: null, latencyMean: 1, latencyImprovementPct: 40, memoryMb: null,
        complexity: null, pValue: 0.01, reasoning: 't', signature: 'fed-sig' });
    kbA.storeCounterexample('fed-sig', [1, 2, 3], 'unit');

    const delta = new FederationSync(kbA).exportDelta('1970-01-01');
    const merged = new FederationSync(kbB).merge(delta);
    assert.ok(merged.mutations >= 1 && merged.counterexamples >= 1 && merged.artifacts >= 2);
    // priors recomputed locally on B without any transfer
    const priors = kbB.getStrategyStatsBySignature('fed-sig');
    assert.ok(priors.some(p => p.strategy === 'sort_idiom_recognition' && p.successes >= 1));
    assert.strictEqual(kbB.getCounterexamples('fed-sig').length, 1);
    // idempotence
    const again = new FederationSync(kbB).merge(delta);
    assert.strictEqual(again.mutations, 0);
    kbA.close(); kbB.close();
    fs.unlinkSync('/tmp/fed_a.db'); fs.unlinkSync('/tmp/fed_b.db');
});

test('écologie de lignée: âge, reproduction, diversité, extinction', async () => {
    const eco = kb.getLineageEcology(KnowledgeBase.hashCode(SEED));
    assert.ok(eco.age >= 1 && eco.population >= 1);
    assert.ok(eco.reproductionRate >= 1 && eco.geneticDiversity > 0 && eco.geneticDiversity <= 1);
    assert.strictEqual(typeof eco.extinct, 'boolean');
});

test('Time Machine: manifest capturé, replay par id compare au résultat enregistré', async () => {
    const exps = (kb as any)['db'].prepare("SELECT id FROM experiments WHERE id LIKE 'exp-itest%'").all();
    assert.ok(exps.length >= 1);
    const exp = kb.getExperiment(exps[0].id)!;
    assert.ok(exp.manifest.seedHash && exp.manifest.config && exp.manifest.environment.node, 'manifest complet');
    assert.ok(typeof exp.manifest.recordedImprovementPct === 'number');
    const { LineageIO } = await import('../src/tools/lineage_io.ts');
    const r = await new LineageIO(kb).replayExperiment(exps[0].id);
    assert.ok(r.remeasuredImprovementPct > 30, `re-mesure ${r.remeasuredImprovementPct}`);
    assert.ok(Math.abs(r.deltaPts!) < 25, `écart au record trop grand: ${r.deltaPts} pts`);
});

test('Provenance blame: mécanisme + verdict + historique de rejets + oracle', async () => {
    const { Provenance } = await import('../src/tools/provenance.ts');
    const db = (kb as any)['db'];
    const winner = db.prepare('SELECT variant_hash FROM mutations WHERE accepted=1 LIMIT 1').get();
    const out = new Provenance(kb).render(winner.variant_hash);
    assert.ok(out.includes('mécanisme') && out.includes('verdict') && out.includes('oracle'));
});

test('Explainer: explication mécanistique déterministe avec faits structurels', async () => {
    const { Explainer } = await import('../src/tools/explainer.ts');
    const before = SEED;
    const after = SEED.replace(/for \(let i = 0[\s\S]*?\}\s*\}\s*\}/, 'a.sort((x, y) => x - y);');
    const txt = new Explainer().explain(before, after, ['sort_idiom_recognition'], 80);
    assert.ok(txt.includes('TimSort') && txt.includes('boucle(s) supprimée(s)') && txt.includes('fuzzing'));
});

test('Publication PDF: rapport généré avec stats fraîches', async () => {
    const { PublicationReport } = await import('../src/tools/publication.ts');
    const exps = (kb as any)['db'].prepare("SELECT id FROM experiments WHERE id LIKE 'exp-itest%'").all();
    const out = '/tmp/neuralys_report.pdf';
    await new PublicationReport(kb).generate(exps[0].id, out);
    const buf = fs.readFileSync(out);
    assert.ok(buf.length > 3000 && buf.subarray(0, 4).toString() === '%PDF');
    fs.unlinkSync(out);
});

test('Bundle génétique signé: intégrité + authenticité + rejet si falsifié', async () => {
    const { GeneticBundle } = await import('../src/tools/genetic_bundle.ts');
    const gb = new GeneticBundle(kb);
    const keys = GeneticBundle.generateKeypair();
    const signed = gb.publish(KnowledgeBase.hashCode(SEED), 'test-corp', keys.privateKey, keys.publicKey);
    const v = gb.verify(signed);
    assert.ok(v.integrity && v.authentic === true);
    // falsification: un artefact modifié doit invalider l'intégrité
    const tampered = JSON.parse(JSON.stringify(signed));
    const k = Object.keys(tampered.bundle.artifacts)[0];
    tampered.bundle.artifacts[k] += '// evil';
    const v2 = gb.verify(tampered);
    assert.strictEqual(v2.integrity, false);
    assert.throws(() => gb.install(tampered));
});

test('AI Software Engineer: repo Git → branche + patch + tests de régression générés VERTS + corps de PR', async () => {
    const { execSync } = await import('child_process');
    const os = await import('os');
    const path = await import('path');
    const { PullRequestGenerator } = await import('../src/tools/pr_generator.ts');

    const repo = fs.mkdtempSync(path.join(os.tmpdir(), 'neuralys-pr-'));
    fs.mkdirSync(path.join(repo, 'src'));
    fs.writeFileSync(path.join(repo, 'src', 'lib.ts'), `export function rankScores(scores) {
    const a = scores.slice();
    for (let i = 0; i < a.length; i++) {
        for (let j = 0; j < a.length - i - 1; j++) {
            if (a[j] > a[j + 1]) { const t = a[j]; a[j] = a[j + 1]; a[j + 1] = t; }
        }
    }
    return a[0] + a.length;
}
`);
    execSync('git init -q && git config user.email t@t && git config user.name t && git add -A && git commit -qm init', { cwd: repo });
    fs.symlinkSync(path.join(process.cwd(), 'node_modules'), path.join(repo, 'node_modules'));

    const kbPR = new KnowledgeBase(path.join(repo, 'kb.db'));
    const pr = await new PullRequestGenerator(kbPR).generate(repo, { generations: 2, maxFunctions: 5 });
    assert.ok(pr, 'une PR doit être produite');
    assert.ok(pr!.testsGenerated > 10, `tests générés: ${pr!.testsGenerated}`);
    assert.ok(pr!.meanGainPct > 20, `gain moyen: ${pr!.meanGainPct}`);
    assert.strictEqual(pr!.risk, 'faible');

    // la branche existe, le commit est là, et les tests générés repassent verts
    const branch = execSync('git rev-parse --abbrev-ref HEAD', { cwd: repo, encoding: 'utf-8' }).trim();
    assert.strictEqual(branch, pr!.branch);
    execSync('npx tsx --test neuralys.regression.test.ts', { cwd: repo, stdio: 'pipe' });

    const body = fs.readFileSync(pr!.prBodyFile, 'utf-8');
    assert.ok(body.includes('Invariants vérifiés') && body.includes('Risque'));
    assert.ok(fs.readFileSync(path.join(repo, 'src', 'lib.ts'), 'utf-8').includes('.sort('), 'le code est bien patché');
    kbPR.close();
    fs.rmSync(repo, { recursive: true, force: true });
});

test('API: état des runs persisté en KB (survit à un redémarrage de processus)', async () => {
    const { createApi } = await import('../src/api/server.ts');
    const path = await import('path');
    const os = await import('os');
    const dbPath = path.join(os.tmpdir(), `neuralys_api_${Date.now()}.db`);

    const kb1 = new KnowledgeBase(dbPath);
    kb1.setRunState('run-persist', 'DONE', { totalImprovementPct: 42.5 });
    kb1.close(); // simule l'arrêt du serveur

    const kb2 = new KnowledgeBase(dbPath); // nouveau processus, même stockage
    const app = createApi(kb2);
    const server = app.listen(0);
    const port = (server.address() as any).port;
    const state = await (await fetch(`http://127.0.0.1:${port}/experiments/run-persist`)).json();
    assert.strictEqual(state.status, 'DONE');
    assert.strictEqual(state.totalImprovementPct, 42.5);
    const list = await (await fetch(`http://127.0.0.1:${port}/experiments`)).json();
    assert.ok(list.some((r: any) => r.id === 'run-persist'));
    server.close(); kb2.close();
    fs.unlinkSync(dbPath);
});

test('Couverture: le taux d\'éligibilité réel est mesurable et exposé', async () => {
    const { RepoOptimizer } = await import('../src/tools/repo_optimizer.ts');
    const c = new RepoOptimizer(kb).coverage('./src');
    assert.ok(c.total > 50, 'le scan doit voir le code réel');
    // Le point n'est pas que ce soit haut, c'est que ce soit MESURÉ et motivé
    assert.ok(Object.keys(c.reasons).length > 0, 'les motifs d\'exclusion doivent être remontés');
    assert.ok(c.ratio >= 0 && c.ratio <= 1);
});

test('Charge réelle : enregistrement des appels sur un vrai paquet npm (lodash)', async () => {
    const { CallRecorder } = await import('../src/tools/workload_analyzer.ts');
    const { createRequire } = await import('module');
    const path = await import('path');
    const req = createRequire(import.meta.url);

    const report = new CallRecorder().record(req.resolve('lodash'), path.resolve('workloads/lodash_driver.cjs'));
    assert.ok(report.functions.length >= 10, `au moins 10 fonctions réellement appelées, obtenu ${report.functions.length}`);
    assert.ok(report.ranked[0].shareOfTotal > 0.1, 'un point chaud domine le temps mesuré');
    // Le classement vient de la MESURE, pas d'une heuristique statique
    for (let i = 1; i < report.ranked.length; i++) {
        assert.ok(report.ranked[i - 1].totalMs >= report.ranked[i].totalMs, 'classement décroissant par temps mesuré');
    }
    const top = report.functions.find(f => f.name === report.ranked[0].name)!;
    assert.ok(top.calls.length > 0 && top.calls[0].args.length >= 1, 'le corpus contient les arguments réels observés');
});

test('Évolution sur projet réel : le pipeline s\'exécute de bout en bout sans rien casser', async () => {
    const { CallRecorder } = await import('../src/tools/workload_analyzer.ts');
    const { ProjectEvolver } = await import('../src/tools/project_evolver.ts');
    const { createRequire } = await import('module');
    const path = await import('path');
    const req = createRequire(import.meta.url);

    const pkgDir = path.dirname(req.resolve('lodash'));
    const report = new CallRecorder().record(req.resolve('lodash'), path.resolve('workloads/lodash_driver.cjs'));
    const evolver = new ProjectEvolver(pkgDir);
    const target = report.ranked[0].name;
    const rec = report.functions.find(f => f.name === target)!;

    const located = evolver.locate(target);
    assert.ok(located && located.source.includes(`function ${target}`), 'la source de la fonction cible est localisée dans le paquet');

    const ev = evolver.evolveFunction(target, rec.calls, 5);
    assert.strictEqual(ev.functionName, target);
    // Résultat scientifique attendu et vérifié : sur du code de production
    // déjà optimisé, la bibliothèque de règles ne produit aucun candidat.
    // Le test verrouille cette honnêteté — jamais d'acceptation sans preuve.
    for (const c of ev.candidates) {
        if (!c.equivalent) assert.strictEqual(c.improvementPct, null, 'aucun gain ne peut être annoncé sans équivalence prouvée');
    }
    if (ev.accepted) assert.ok(ev.accepted.equivalent && ev.accepted.improvementPct! > 2);
    // l'installation réelle du paquet ne doit pas avoir été modifiée
    const fs2 = await import('fs');
    assert.ok(fs2.readFileSync(path.join(pkgDir, 'lodash.js'), 'utf-8').length > 100000, 'le paquet installé est intact');
});
