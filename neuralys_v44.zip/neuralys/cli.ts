import { program } from 'commander';
import * as fs from 'fs';
import { KnowledgeBase } from './src/memory/knowledge_base';
import { DarwinDriver } from './src/core/engine';
import { LineageIO } from './src/tools/lineage_io';
import { PromptDarwin } from './src/promptlab/prompt_darwin';

const kb = new KnowledgeBase();
const io = new LineageIO(kb);

program.name('neuralys').description('Darwinian software evolution laboratory');

program.command('evolve <file>').description('Evolve a TypeScript function (processPayload)')
    .option('-g, --generations <n>', 'generations', '3')
    .action(async (file, opts) => {
        const code = fs.readFileSync(file, 'utf-8');
        const res = await new DarwinDriver(kb).evolve(file, 'CLI', code, { generations: parseInt(opts.generations) });
        console.log(`${res.totalImprovementPct.toFixed(1)}% | ${res.bestLineage.join(' -> ') || '(seed)'}`);
        console.log(res.bestCode);
    });

program.command('promptlab <dataset> <prompt>').description('Evolve a prompt against an eval dataset')
    .action(async (dataset, prompt) => {
        const res = await new PromptDarwin(kb).evolve(fs.readFileSync(prompt, 'utf-8'), JSON.parse(fs.readFileSync(dataset, 'utf-8')));
        console.log(`économie ${res.savingsPct.toFixed(0)}% | qualité ${(res.champion.metrics.quality * 100).toFixed(0)}% (holdout ${(res.champion.metrics.holdoutQuality * 100).toFixed(0)}%)`);
        console.log(res.champion.prompt);
    });

program.command('lineage <hash>').description('Print the genetic tree of an artifact')
    .action(hash => console.log(io.renderTree(hash)));

program.command('export <hash> <out>').description('Export a lineage bundle')
    .action((hash, out) => { fs.writeFileSync(out, JSON.stringify(io.export(hash), null, 2)); console.log(`exported to ${out}`); });

program.command('import <file>').description('Import a lineage bundle')
    .action(file => console.log(io.import(JSON.parse(fs.readFileSync(file, 'utf-8')))));

program.command('replay <hash>').description('Re-execute and re-measure a recorded lineage')
    .action(async hash => {
        const r = await io.replay(hash);
        for (const s of r.steps) console.log(`  [${s.strategy}] ${s.equivalent ? '✓' : '✗'} ${s.latencyMs.toFixed(4)}ms`);
        console.log(`gain re-mesuré: ${r.finalImprovementPct.toFixed(1)}%`);
    });

program.command('pr <repoPath>').description('Repo Git → branche + patch + tests de régression générés + corps de PR')
    .option('-m, --max <n>', 'fonctions max', '20')
    .option('-g, --generations <n>', 'générations', '2')
    .action(async (repoPath, opts) => {
        const { PullRequestGenerator } = await import('./src/tools/pr_generator');
        const pr = await new PullRequestGenerator(kb).generate(repoPath, {
            maxFunctions: parseInt(opts.max), generations: parseInt(opts.generations)
        });
        if (!pr) return console.log('Aucune optimisation prouvée sur ce dépôt.');
        console.log(`branche ${pr.branch} | ${pr.filesModified} fichier(s) | ${pr.testsGenerated} tests générés | +${pr.meanGainPct.toFixed(1)}% moyen | risque ${pr.risk}`);
        console.log(`corps de PR: ${pr.prBodyFile}`);
    });

program.command('workload <moduleName> <driverPath>').description('Enregistre une charge réelle et classe les points chauds par temps mesuré')
    .action(async (moduleName, driverPath) => {
        const { CallRecorder } = await import('./src/tools/workload_analyzer');
        const { createRequire } = await import('module');
        const path = await import('path');
        const req = createRequire(import.meta.url);
        const r = new CallRecorder().record(req.resolve(moduleName), path.resolve(driverPath));
        console.log(`${r.functions.length} fonctions réellement appelées, ${r.totalMs.toFixed(0)} ms cumulés`);
        for (const h of r.ranked.slice(0, 15)) {
            console.log(`  ${h.name.padEnd(18)} ${String(h.calls).padStart(7)} appels  ${h.totalMs.toFixed(2).padStart(9)} ms  ${(h.shareOfTotal * 100).toFixed(1).padStart(5)}%`);
        }
    });

program.command('evolve-project <packageDir> <functionName> <driverPath>').description('Fait évoluer une fonction d\'un vrai paquet avec preuve par rejeu de charge')
    .action(async (packageDir, functionName, driverPath) => {
        const { CallRecorder } = await import('./src/tools/workload_analyzer');
        const { ProjectEvolver } = await import('./src/tools/project_evolver');
        const { createRequire } = await import('module');
        const path = await import('path');
        const req = createRequire(import.meta.url);
        const r = new CallRecorder().record(req.resolve(packageDir), path.resolve(driverPath));
        const rec = r.functions.find(f => f.name === functionName);
        if (!rec) return console.log(`${functionName} n'a pas été appelée par cette charge.`);
        const ev = new ProjectEvolver(path.dirname(req.resolve(packageDir))).evolveFunction(functionName, rec.calls);
        console.log(`${ev.functionName} (${ev.file}) — ${ev.candidates.length} candidat(s)`);
        for (const c of ev.candidates) console.log(`  ${c.strategy.padEnd(32)} ${c.equivalent ? 'équivalent sur ' + c.checked + ' appels' : 'rejeté'}${c.improvementPct !== null ? '  Δ ' + c.improvementPct.toFixed(1) + '%' : ''}`);
        console.log(ev.accepted ? `RETENU : ${ev.accepted.strategy} (+${ev.accepted.improvementPct!.toFixed(1)}%)` : 'Aucune mutation retenue.');
    });

program.command('capture <packageDir> <driverPath> <name>').description('Instrumente un paquet, exécute un scénario réel et mesure la couverture d\'exécution')
    .action(async (packageDir, driverPath, name) => {
        const { ExecutionCapture } = await import('./src/tools/execution_capture');
        const path = await import('path');
        const r = new ExecutionCapture().capture(path.resolve(packageDir), driverPath, name);
        const cov = r.functionsFound ? r.functionsReplayable / r.functionsFound * 100 : 0;
        const covLoaded = r.functionsInLoadedFiles ? r.functionsReplayable / r.functionsInLoadedFiles * 100 : 0;
        console.log(`${name} : ${r.functionsFound} fonctions, ${r.functionsInstrumented} instrumentées, ${r.captured.length} exécutées, ${r.functionsReplayable} rejouables`);
        console.log(`couverture : ${cov.toFixed(1)} % (globale) | ${covLoaded.toFixed(1)} % (fichiers chargés)`);
        if (r.error) console.log('erreur :', r.error);
    });

program.command('evaluate').description('Évaluation reproductible sur les dépôts open source installés (rapport + IC 95 %)')
    .action(async () => {
        const { execSync } = await import('child_process');
        execSync('npx tsx run_evaluation.ts', { stdio: 'inherit' });
    });

program.command('caller-scan <dir>').description('Détecte les appels purs hissables ou factorisables dans du code applicatif')
    .action(async dir => {
        const { CallerOptimizer } = await import('./src/core/caller_optimizer');
        const path = await import('path');
        const walk = (d: string, acc: string[] = []): string[] => {
            for (const e of fs.readdirSync(d, { withFileTypes: true })) {
                if (e.name === 'node_modules' || e.name.startsWith('.')) continue;
                const p2 = path.join(d, e.name);
                if (e.isDirectory()) walk(p2, acc);
                else if (/\.(ts|js)$/.test(e.name) && !/\.(min|test)\./.test(e.name)) acc.push(p2);
            }
            return acc;
        };
        const opt = new CallerOptimizer();
        let hoist = 0, cse = 0;
        const byFn: Record<string, number> = {};
        for (const f of walk(dir)) {
            let text: string;
            try { text = fs.readFileSync(f, 'utf-8'); } catch { continue; }
            if (text.length > 300000) continue;
            for (const s2 of opt.detect(text)) {
                if (s2.kind === 'hoist_invariant_call') hoist++; else cse++;
                byFn[s2.calleeName] = (byFn[s2.calleeName] || 0) + 1;
            }
        }
        console.log(`${hoist} appel(s) hissable(s) hors boucle, ${cse} appel(s) factorisable(s)`);
        console.log('appelés le plus souvent :', Object.entries(byFn).sort((a, b) => b[1] - a[1]).slice(0, 8).map(([k, v]) => `${k}(${v})`).join(', '));
        console.log('Rappel : la transformation exige une preuve de pureté obtenue par `neuralys workload`.');
    });

program.command('coverage <repoPath>').description('Taux de fonctions réellement éligibles au harnais (et motifs d\'exclusion)')
    .action(async repoPath => {
        const { RepoOptimizer } = await import('./src/tools/repo_optimizer');
        const c = new RepoOptimizer(kb).coverage(repoPath);
        console.log(`${c.eligible}/${c.total} fonctions éligibles = ${(c.ratio * 100).toFixed(1)}%`);
        for (const [r, n] of Object.entries(c.reasons).sort((a, b) => b[1] - a[1])) console.log(`  ${n}× ${r}`);
    });

program.command('invariants <file>').description('Extrait et vérifie les invariants d\'une fonction')
    .action(async file => {
        const { InvariantExtractor } = await import('./src/validation/invariant_extractor');
        const p = new InvariantExtractor().extract(fs.readFileSync(file, 'utf-8'));
        for (const i of p.invariants) console.log(`  ✓ ${i} — ${p.descriptions[i]}`);
        if (p.invariants.length === 0) console.log('  (aucun invariant vérifié)');
    });

program.command('blame <hash>').description('Provenance complète (git blame de l\'évolution)')
    .action(async hash => {
        const { Provenance } = await import('./src/tools/provenance');
        console.log(new Provenance(kb).render(hash));
    });

program.command('replay-exp <experimentId>').description('Time Machine: rejoue une expérience et compare au résultat enregistré')
    .action(async id => {
        const r = await io.replayExperiment(id);
        console.log(`enregistré: ${r.recordedImprovementPct?.toFixed(1) ?? 'n/a'}% | re-mesuré: ${r.remeasuredImprovementPct.toFixed(1)}%` +
            (r.deltaPts !== null ? ` | écart ${r.deltaPts.toFixed(1)} pts` : ''));
    });

program.command('report <experimentId> <out.pdf>').description('Rapport scientifique PDF (CI 95%, p-value, effet de taille)')
    .action(async (id, out) => {
        const { PublicationReport } = await import('./src/tools/publication');
        console.log('PDF:', await new PublicationReport(kb).generate(id, out));
    });

program.command('publish <hash> <out.json>').description('Publie une lignée en bundle signé')
    .option('--publisher <name>', 'nom éditeur', 'anonymous')
    .action(async (hash, out, opts) => {
        const { GeneticBundle } = await import('./src/tools/genetic_bundle');
        const keys = GeneticBundle.generateKeypair();
        const signed = new GeneticBundle(kb).publish(hash, opts.publisher, keys.privateKey, keys.publicKey);
        fs.writeFileSync(out, JSON.stringify(signed, null, 2));
        console.log(`bundle signé écrit: ${out} (sha256 ${signed.manifest.contentSha256.slice(0, 16)}…)`);
    });

program.command('install <bundle.json>').description('Vérifie et installe un bundle de lignée')
    .action(async file => {
        const { GeneticBundle } = await import('./src/tools/genetic_bundle');
        console.log(new GeneticBundle(kb).install(JSON.parse(fs.readFileSync(file, 'utf-8'))));
    });

program.command('serve').description('Start the REST API').action(async () => {
    const { createApi } = await import('./src/api/server');
    createApi(kb).listen(4000, () => console.log('API on :4000'));
});

program.parseAsync().then(() => { if (process.argv.length > 2 && !process.argv.includes('serve')) kb.close(); });
