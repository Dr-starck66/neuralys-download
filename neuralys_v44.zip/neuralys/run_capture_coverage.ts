import { ExecutionCapture, isReplayableCall } from './src/tools/execution_capture.ts';
import * as fs from 'fs';
import * as path from 'path';

const TARGETS: [string, string, string][] = [
  // Racine du paquet dans tous les cas : c'est elle que `require` résout.
  ['lodash', 'node_modules/lodash', 'workloads/drivers/lodash.cjs'],
  ['simple-statistics', 'node_modules/simple-statistics', 'workloads/drivers/simple-statistics.cjs'],
  ['qs', 'node_modules/qs', 'workloads/drivers/qs.cjs'],
  ['cookie', 'node_modules/cookie', 'workloads/drivers/cookie.cjs'],
  ['semver', 'node_modules/semver', 'workloads/drivers/semver.cjs'],
  ['acorn', 'node_modules/acorn', 'workloads/drivers/acorn.cjs'],
  ['bytes', 'node_modules/bytes', 'workloads/drivers/bytes.cjs'],
  ['content-type', 'node_modules/content-type', 'workloads/drivers/content-type.cjs'],
  ['commander', 'node_modules/commander', 'workloads/drivers/commander.cjs'],
];

const cap = new ExecutionCapture();
const rows: any[] = [];
console.log('paquet'.padEnd(20), 'fonctions'.padStart(10), 'instrum.'.padStart(9), 'exécutées'.padStart(10), 'rejouables'.padStart(11), 'couverture'.padStart(11));
for (const [name, dir, driver] of TARGETS) {
  if (!fs.existsSync(dir) || !fs.existsSync(driver)) { console.log(name.padEnd(20), '(absent)'); continue; }
  let r;
  try { r = cap.capture(path.resolve(dir), driver, name); }
  catch (e: any) { console.log(name.padEnd(20), 'erreur:', e.message.slice(0, 50)); continue; }
  const executed = r.captured.length;
  const cov = r.functionsFound ? r.functionsReplayable / r.functionsFound : 0;
  rows.push({ name, ...r, executed, coverage: cov });
  console.log(name.padEnd(20), String(r.functionsFound).padStart(10), String(r.functionsInstrumented).padStart(9),
    String(executed).padStart(10), String(r.functionsReplayable).padStart(11), (cov * 100).toFixed(1).padStart(10) + '%',
    r.error ? ' [' + r.error.slice(0, 40) + ']' : '');
}

const tot = (f: (r: any) => number) => rows.reduce((a, r) => a + f(r), 0);
const found = tot(r => r.functionsFound), instr = tot(r => r.functionsInstrumented),
      exec = tot(r => r.executed), replay = tot(r => r.functionsReplayable);
function wilson(s: number, n: number): [number, number] {
  if (!n) return [0, 0];
  const z = 1.959963985, p = s / n, d = 1 + z * z / n;
  const c = p + z * z / (2 * n), m = z * Math.sqrt(p * (1 - p) / n + z * z / (4 * n * n));
  return [(c - m) / d, (c + m) / d];
}
const ci = wilson(replay, found);
console.log('\n═══ KPI : couverture d\'exécution ═══');
console.log(`fonctions trouvées        : ${found}`);
console.log(`instrumentées             : ${instr} (${(instr / found * 100).toFixed(1)} %)`);
console.log(`réellement exécutées      : ${exec} (${(exec / found * 100).toFixed(1)} %)`);
console.log(`AVEC APPEL REJOUABLE      : ${replay} / ${found} = ${(replay / found * 100).toFixed(1)} % [IC 95 % : ${(ci[0] * 100).toFixed(1)} ; ${(ci[1] * 100).toFixed(1)}]`);
console.log(`\nRappel harnais synthétique (v42) : 0,9 % [0,4 ; 2,1]`);
const skipAll: Record<string, number> = {};
for (const r of rows) for (const [k, v] of Object.entries(r.skipped)) skipAll[k] = (skipAll[k] || 0) + (v as number);
console.log('\nnon instrumentées, par motif :', Object.entries(skipAll).sort((a, b) => b[1] - a[1]).map(([k, v]) => `${k}=${v}`).join(', ') || 'aucune');
fs.writeFileSync('capture_coverage.json', JSON.stringify(rows.map(r => ({ ...r, captured: undefined })), null, 2));
