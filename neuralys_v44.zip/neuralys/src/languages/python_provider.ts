import { spawnSync } from 'child_process';
import * as fs from 'fs';
import * as os from 'os';
import * as path from 'path';
import { LanguageProvider, BenchmarkSamples } from './language_provider';

/**
 * Real Python language provider. Everything runs in a python3 subprocess:
 * - compile check via compile()
 * - differential fuzzing: both versions executed on identical seeded
 *   integer lists, deep-compared; exception classes must match
 * - calibrated benchmark: warmup + repetition until samples >= 2ms,
 *   perf_counter timing of the call only
 * Mutations for Python come exclusively from the LLM ensemble; the
 * validation pipeline here is what makes them safe to accept.
 */
export class PythonProvider implements LanguageProvider {
    public language = 'python';
    public entryFunctionName = 'process_payload';
    private workDir = fs.mkdtempSync(path.join(os.tmpdir(), 'neuralys-py-'));

    private runPy(script: string, timeoutMs: number = 30000): { ok: boolean; stdout: string; stderr: string } {
        const file = path.join(this.workDir, `job_${Date.now()}_${Math.random().toString(36).slice(2)}.py`);
        fs.writeFileSync(file, script);
        const res = spawnSync('python3', [file], { timeout: timeoutMs, encoding: 'utf-8' });
        fs.unlinkSync(file);
        return { ok: res.status === 0, stdout: res.stdout || '', stderr: res.stderr || '' };
    }

    public async checkCompiles(code: string): Promise<{ ok: boolean; error?: string }> {
        const r = this.runPy(`
import json, sys
code = json.loads(${JSON.stringify(JSON.stringify(code))})
try:
    compile(code, '<mutation>', 'exec')
    ns = {}
    exec(code, ns)
    assert callable(ns.get('process_payload')), 'process_payload missing'
    print('OK')
except Exception as e:
    print(f'ERR:{type(e).__name__}:{e}', file=sys.stderr)
    sys.exit(1)
`);
        return r.ok ? { ok: true } : { ok: false, error: r.stderr.trim().slice(0, 200) };
    }

    public async differentialFuzz(originalCode: string, mutatedCode: string, cases: number = 200): Promise<{ equivalent: boolean; counterexample?: string }> {
        const r = this.runPy(`
import json, random, sys
orig_src = json.loads(${JSON.stringify(JSON.stringify(originalCode))})
mut_src = json.loads(${JSON.stringify(JSON.stringify(mutatedCode))})
ns1, ns2 = {}, {}
exec(orig_src, ns1); exec(mut_src, ns2)
f1, f2 = ns1['process_payload'], ns2['process_payload']
rng = random.Random(1337)
edge = [[], [0], [-1], [1,1,1], list(range(500, 0, -1))]
tests = edge + [[rng.randint(-10000, 10000) for _ in range(rng.randint(0, 300))] for _ in range(int(${cases}))]
for t in tests:
    r1 = e1 = r2 = e2 = None
    try: r1 = f1(list(t))
    except Exception as ex: e1 = type(ex).__name__
    try: r2 = f2(list(t))
    except Exception as ex: e2 = type(ex).__name__
    if e1 != e2 or (e1 is None and r1 != r2):
        print(json.dumps({'equivalent': False, 'counterexample': t[:20]}))
        sys.exit(0)
print(json.dumps({'equivalent': True}))
`);
        if (!r.ok) return { equivalent: false, counterexample: `harness error: ${r.stderr.slice(0, 150)}` };
        try {
            const parsed = JSON.parse(r.stdout.trim().split('\n').pop()!);
            return { equivalent: parsed.equivalent, counterexample: parsed.counterexample ? JSON.stringify(parsed.counterexample) : undefined };
        } catch {
            return { equivalent: false, counterexample: 'unparseable harness output' };
        }
    }

    public async benchmark(code: string, samples: number = 15): Promise<BenchmarkSamples> {
        const r = this.runPy(`
import json, time, random, sys
src = json.loads(${JSON.stringify(JSON.stringify(code))})
ns = {}
exec(src, ns)
f = ns['process_payload']
def make_input(seed):
    rng = random.Random(seed)
    d = list(range(1000)); rng.shuffle(d); return d
for w in range(3): f(make_input(w))
t0 = time.perf_counter(); f(make_input(99)); single = max(time.perf_counter() - t0, 1e-7)
reps = max(1, min(2000, int(0.002 / single) + 1))
lat, ok = [], 0
for s in range(int(${samples})):
    inputs = [make_input(1337 + s * reps + r) for r in range(reps)]
    a = time.perf_counter()
    try:
        for r_ in range(reps): res = f(inputs[r_])
        ok += 1
    except Exception:
        lat.append(9999.0); continue
    lat.append((time.perf_counter() - a) * 1000 / reps)
print(json.dumps({'latencyMs': lat, 'passRate': ok / int(${samples})}))
`, 120000);
        if (!r.ok) return { latencyMs: Array(samples).fill(9999), passRate: 0 };
        try {
            return JSON.parse(r.stdout.trim().split('\n').pop()!);
        } catch {
            return { latencyMs: Array(samples).fill(9999), passRate: 0 };
        }
    }
}
