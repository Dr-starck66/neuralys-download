export interface BenchmarkSamples {
    latencyMs: number[];
    passRate: number; // 0..1
}

/**
 * Plugin seam for multi-language evolution (spec point 9/13).
 * A provider is only shipped when ALL four capabilities are real:
 * compile-check, differential fuzzing, calibrated benchmark, mutation
 * source. TypeScript: full (symbolic rules + LLM). Python: real harness
 * (subprocess), LLM-only mutations - no symbolic rules are faked.
 */
export interface LanguageProvider {
    language: string;
    entryFunctionName: string;
    checkCompiles(code: string): Promise<{ ok: boolean; error?: string }>;
    differentialFuzz(originalCode: string, mutatedCode: string, cases: number): Promise<{ equivalent: boolean; counterexample?: string }>;
    benchmark(code: string, samples: number): Promise<BenchmarkSamples>;
}
