/**
 * Monte Carlo hypervolume estimator for minimization fronts.
 * Exact hypervolume is #P-hard beyond 3 objectives; MC estimation with a
 * fixed seed gives a reproducible, dimension-agnostic convergence signal.
 * Objectives are normalized into [0,1]^d against the provided reference
 * point (worst observed values); the estimate is the fraction of the unit
 * box dominated by the front. Strictly monotone in front improvement.
 */
export class HypervolumeTracker {
    private history: number[] = [];

    public static estimate(front: number[][], reference: number[], samples: number = 20000, seed: number = 424242): number {
        if (front.length === 0) return 0;
        const d = reference.length;
        const norm = front.map(p => p.map((v, i) => Math.min(1, Math.max(0, reference[i] > 0 ? v / reference[i] : 0))));
        let rngState = seed;
        const rng = () => {
            rngState = (rngState * 48271) % 2147483647;
            return rngState / 2147483647;
        };
        let dominated = 0;
        for (let s = 0; s < samples; s++) {
            const pt = Array.from({ length: d }, () => rng());
            if (norm.some(p => p.every((v, i) => v <= pt[i]))) dominated++;
        }
        return dominated / samples;
    }

    public record(front: number[][], reference: number[]): number {
        const hv = HypervolumeTracker.estimate(front, reference);
        this.history.push(hv);
        return hv;
    }

    /** Stagnation: hypervolume gain below epsilon over the last `window` generations. */
    public isStagnant(window: number = 2, epsilon: number = 0.005): boolean {
        if (this.history.length < window + 1) return false;
        const recent = this.history.slice(-(window + 1));
        return recent[recent.length - 1] - recent[0] < epsilon;
    }

    public getHistory(): number[] { return [...this.history]; }
}
