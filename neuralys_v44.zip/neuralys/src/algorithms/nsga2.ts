export interface Candidate {
    id: string;
    branchName: string;
    objectives: number[]; // Minimization constraint: e.g., [latency, memory, error_rate]
    dominationCount: number;
    dominatedSolutions: string[];
    rank: number;
    crowdingDistance: number;
}

/**
 * Non-Dominated Sorting Genetic Algorithm II (NSGA-II)
 * Core mathematical sorting for multi-objective Pareto optimization.
 */
export class NSGA2 {
    
    /**
     * Sorts a population into Pareto fronts.
     * Front 0 contains the strictly non-dominated solutions.
     */
    public static fastNonDominatedSort(population: Candidate[]): Candidate[][] {
        const fronts: Candidate[][] = [[]];
        
        for (const p of population) {
            p.dominationCount = 0;
            p.dominatedSolutions = [];
            p.crowdingDistance = 0; // Initialize
            
            for (const q of population) {
                if (this.dominates(p, q)) {
                    p.dominatedSolutions.push(q.id);
                } else if (this.dominates(q, p)) {
                    p.dominationCount += 1;
                }
            }
            
            if (p.dominationCount === 0) {
                p.rank = 0;
                fronts[0].push(p);
            }
        }
        
        let i = 0;
        while (fronts[i] && fronts[i].length > 0) {
            const nextFront: Candidate[] = [];
            for (const p of fronts[i]) {
                for (const qId of p.dominatedSolutions) {
                    const q = population.find(c => c.id === qId)!;
                    q.dominationCount -= 1;
                    if (q.dominationCount === 0) {
                        q.rank = i + 1;
                        nextFront.push(q);
                    }
                }
            }
            i++;
            if (nextFront.length > 0) {
                fronts.push(nextFront);
            }
        }
        
        return fronts;
    }

    /**
     * Assigns crowding distance to maintain population diversity along the Pareto frontier.
     */
    public static assignCrowdingDistance(front: Candidate[]) {
        const l = front.length;
        if (l <= 2) {
            for (const p of front) p.crowdingDistance = Infinity;
            return;
        }
        
        for (const p of front) p.crowdingDistance = 0;
        
        const numObjectives = front[0].objectives.length;
        
        for (let m = 0; m < numObjectives; m++) {
            // Sort by objective m
            front.sort((a, b) => a.objectives[m] - b.objectives[m]);
            
            front[0].crowdingDistance = Infinity;
            front[l - 1].crowdingDistance = Infinity; // Boundary points are always retained
            
            const fMax = front[l - 1].objectives[m];
            const fMin = front[0].objectives[m];
            const diff = fMax - fMin || 1; // Prevent division by zero
            
            for (let i = 1; i < l - 1; i++) {
                if (front[i].crowdingDistance !== Infinity) {
                    front[i].crowdingDistance += (front[i + 1].objectives[m] - front[i - 1].objectives[m]) / diff;
                }
            }
        }
    }

    /**
     * Strict Pareto Dominance
     * Assumes objective minimization.
     */
    private static dominates(p: Candidate, q: Candidate): boolean {
        let strictBetter = false;
        for (let i = 0; i < p.objectives.length; i++) {
            if (p.objectives[i] > q.objectives[i]) return false; // Worse in at least one objective
            if (p.objectives[i] < q.objectives[i]) strictBetter = true; // Better in at least one
        }
        return strictBetter;
    }
}
