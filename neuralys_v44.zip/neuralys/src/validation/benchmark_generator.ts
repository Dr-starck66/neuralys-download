import * as fs from 'fs';

export interface BenchmarkTarget {
    id: string;
    category: string;
    code: string;
}

const templates: { category: string, id: string, generator: (i: number) => string }[] = [
    {
        category: "Sorting",
        id: "BubbleSort",
        generator: (i) => `function processPayload(arr) {
    const n = arr.length;
    for (let i = 0; i < n; i++) {
        for (let j = 0; j < n - i - 1; j++) {
            if (arr[j] > arr[j + 1]) {
                const temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
    }
    return arr[0] + ${i};
}`
    },
    {
        category: "Numerical",
        id: "FibonacciIterative",
        generator: (i) => `function processPayload(arr) {
    let n = Math.min(arr.length, 50);
    let a = 0, b = 1, c;
    if (n === 0) return a;
    for (let i = 2; i <= n; i++) {
        c = a + b;
        a = b;
        b = c;
    }
    return b + ${i};
}`
    },
    {
        category: "String",
        id: "ReverseString",
        generator: (i) => `function processPayload(arr) {
    let str = arr.join('');
    let reversed = '';
    for (let i = str.length - 1; i >= 0; i--) {
        reversed += str[i];
    }
    return reversed.length + ${i};
}`
    },
    {
        category: "Math",
        id: "SumSquares",
        generator: (i) => `function processPayload(arr) {
    let sum = 0;
    for (let j = 0; j < arr.length; j++) {
        sum += arr[j] * arr[j];
    }
    return sum + ${i};
}`
    },
    {
        category: "Graph",
        id: "BFS_Simulated",
        generator: (i) => `function processPayload(arr) {
    let queue = [0];
    let visited = new Set([0]);
    let count = 0;
    while (queue.length > 0) {
        let node = queue.shift();
        count++;
        let neighbors = [node + 1, node + 2];
        for (let n of neighbors) {
            if (n < arr.length && !visited.has(n)) {
                visited.add(n);
                queue.push(n);
            }
        }
    }
    return count + ${i};
}`
    },
    {
        category: "Matrix",
        id: "MatrixVectorMultiply",
        generator: (i) => `function processPayload(arr) {
    let n = Math.min(arr.length, 100);
    let res = 0;
    for (let i = 0; i < n; i++) {
        let sum = 0;
        for (let j = 0; j < n; j++) {
            sum += i * j;
        }
        res += sum;
    }
    return res + ${i};
}`
    },
    {
        category: "Parsing",
        id: "CountVowels",
        generator: (i) => `function processPayload(arr) {
    let count = 0;
    let vowels = 'aeiou';
    for (let i = 0; i < arr.length; i++) {
        let str = String(arr[i]);
        for(let j=0; j<str.length; j++) {
           if (vowels.indexOf(str[j]) !== -1) count++;
        }
    }
    return count + ${i};
}`
    },
    {
        category: "DynamicProgramming",
        id: "CoinChangeSimulated",
        generator: (i) => `function processPayload(arr) {
    let amount = Math.min(arr.length, 100);
    let coins = [1, 2, 5];
    let dp = new Array(amount + 1).fill(amount + 1);
    dp[0] = 0;
    for (let i = 1; i <= amount; i++) {
        for (let j = 0; j < coins.length; j++) {
            if (coins[j] <= i) {
                dp[i] = Math.min(dp[i], dp[i - coins[j]] + 1);
            }
        }
    }
    return dp[amount] + ${i};
}`
    },
    {
        category: "Compression",
        id: "RunLengthEncoding",
        generator: (i) => `function processPayload(arr) {
    let str = arr.join('');
    if (!str) return 0;
    let res = '';
    let count = 1;
    for (let i = 1; i < str.length; i++) {
        if (str[i] === str[i-1]) {
            count++;
        } else {
            res += str[i-1] + count;
            count = 1;
        }
    }
    res += str[str.length-1] + count;
    return res.length + ${i};
}`
    },
    {
        category: "DataStructures",
        id: "StackOperations",
        generator: (i) => `function processPayload(arr) {
    let stack = [];
    let sum = 0;
    for (let j = 0; j < arr.length; j++) {
        stack.push(arr[j]);
        if (stack.length > 10) {
            sum += stack.pop();
        }
    }
    return sum + ${i};
}`
    }
];

export function generateBenchmarks(): BenchmarkTarget[] {
    const benchmarks: BenchmarkTarget[] = [];
    
    // Generate 100 benchmarks (10 templates * 10 variations each)
    for (let t = 0; t < templates.length; t++) {
        for (let v = 0; v < 10; v++) {
            benchmarks.push({
                id: `${templates[t].id}_var${v}`,
                category: templates[t].category,
                code: templates[t].generator(v)
            });
        }
    }
    return benchmarks;
}
