import * as fc from 'fast-check';
import * as vm from 'vm';
import * as ts from 'typescript';
import { Project, SyntaxKind } from 'ts-morph';
import { generateAdversarialInputs } from './adversarial_generator';
import { InvariantExtractor, InvariantProfile } from './invariant_extractor';

export interface SemanticValidationResult {
    confidenceScore: number; // 0.0 to 1.0
    passed: boolean;
    fuzzingPassed: boolean;
    formalVerified: boolean;
    staticChecksPassed: boolean;
    invariantsPreserved: string[];
    invariantsViolated: string[];
    issues: string[];
    counterexample?: unknown;
}

/**
 * Semantic equivalence guardian.
 * - Static analysis: exported/declared surface must match.
 * - Differential fuzzing: both versions executed on the SAME generated
 *   inputs inside isolated vm contexts; any observable divergence rejects.
 * - Formal verification: explicitly NOT implemented (TS -> SMT-LIB
 *   translation out of scope); never contributes to the score.
 */
export class AdvancedSemanticGuardian {
    private project: Project;
    private invariants = new InvariantExtractor();
    private profileCache = new Map<string, InvariantProfile>();

    constructor() {
        this.project = new Project({ useInMemoryFileSystem: true });
    }

    public async evaluateEquivalence(originalCode: string, mutatedCode: string, testInputs: any[] = []): Promise<SemanticValidationResult> {
        const issues: string[] = [];
        let fuzzingPassed = false;
        let staticChecksPassed = false;
        this.lastCounterexample = undefined;

        try {
            staticChecksPassed = this.performStaticAnalysis(originalCode, mutatedCode, issues);
        } catch (e: any) {
            issues.push(`Static analysis error: ${e.message}`);
        }

        try {
            fuzzingPassed = this.performDifferentialFuzzing(originalCode, mutatedCode, issues, testInputs);
        } catch (e: any) {
            issues.push(`Fuzzing error: ${e.message}`);
        }

        // Third layer: verified-invariant obligations. The seed's profile
        // is inferred once (cached by content) and every invariant it
        // provably holds becomes a requirement on the mutant. A violation
        // yields a NAMED diagnosis, not just a divergence.
        let seedProfile = this.profileCache.get(originalCode);
        if (!seedProfile) {
            seedProfile = this.invariants.extract(originalCode);
            this.profileCache.set(originalCode, seedProfile);
        }
        let invariantsViolated: string[] = [];
        try {
            invariantsViolated = this.invariants.violations(mutatedCode, seedProfile);
        } catch { /* invariant layer is additive, never blocks on its own failure */ }
        for (const v of invariantsViolated) {
            issues.push(`Invariant du seed violé: ${v} (${seedProfile.descriptions[v] || ''})`);
        }

        let confidenceScore = 0;
        if (staticChecksPassed) confidenceScore += 0.4;
        if (fuzzingPassed) confidenceScore += 0.6;

        return {
            confidenceScore,
            passed: confidenceScore >= 0.8 && invariantsViolated.length === 0,
            fuzzingPassed,
            formalVerified: false,
            staticChecksPassed,
            invariantsPreserved: seedProfile.invariants.filter(i => !invariantsViolated.includes(i)),
            invariantsViolated,
            issues,
            counterexample: this.lastCounterexample
        };
    }

    private lastCounterexample: unknown = undefined;

    private getEntryFunctionName(code: string): string | null {
        const file = this.project.createSourceFile('entry.ts', code, { overwrite: true });
        const fns = file.getDescendantsOfKind(SyntaxKind.FunctionDeclaration);
        for (const fn of fns) {
            const name = fn.getName();
            if (name) return name;
        }
        return null;
    }

    private compileToRunner(code: string, fnName: string): ((input: any) => any) {
        const js = ts.transpileModule(code, {
            compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 }
        }).outputText;

        const context = vm.createContext({ Math, Set, Map, Array, JSON, String, Number, exports: {}, module: { exports: {} } });
        new vm.Script(js).runInContext(context, { timeout: 2000 });
        const script = new vm.Script(`${fnName}(__input__)`);

        return (input: any) => {
            (context as any).__input__ = JSON.parse(JSON.stringify(input));
            return script.runInContext(context, { timeout: 2000 });
        };
    }

    private performStaticAnalysis(orig: string, mut: string, issues: string[]): boolean {
        const origName = this.getEntryFunctionName(orig);
        const mutName = this.getEntryFunctionName(mut);

        if (!origName) {
            issues.push('Original code declares no named function.');
            return false;
        }
        if (origName !== mutName) {
            issues.push(`Entry function mismatch: '${origName}' vs '${mutName}'.`);
            return false;
        }
        return true;
    }

    private performDifferentialFuzzing(orig: string, mut: string, issues: string[], extraInputs: any[]): boolean {
        const fnName = this.getEntryFunctionName(orig);
        if (!fnName) {
            issues.push('Cannot fuzz: no entry function found.');
            return false;
        }

        let origRunner: (i: any) => any;
        let mutRunner: (i: any) => any;
        try {
            origRunner = this.compileToRunner(orig, fnName);
            mutRunner = this.compileToRunner(mut, fnName);
        } catch (e: any) {
            issues.push(`Compilation for fuzzing failed: ${e.message}`);
            return false;
        }

        // Structured input families + stored counterexamples + user tests.
        // Families target classic optimization bugs: stability (duplicates),
        // ordering assumptions (sorted/reversed/alternating), degenerate
        // sizes, and magnitude extremes.
        const n = 400;
        const edgeCases: any[] = [
            [], [0], [-1], [1, 1, 1],
            Array.from({ length: 500 }, (_, i) => 500 - i),          // reversed
            Array.from({ length: n }, (_, i) => i),                   // sorted
            Array.from({ length: n }, () => 7),                       // all-equal (stability)
            Array.from({ length: n }, (_, i) => i % 5),               // duplicate-heavy
            Array.from({ length: n }, (_, i) => (i % 2 ? 1 : -1) * i),// alternating signs
            Array.from({ length: n }, (_, i) => (i % 2 ? 2147480000 : -2147480000) + i), // magnitude extremes
            // Generative oracle: boundary-value inputs derived from the
            // literals and thresholds of BOTH versions of the code
            ...generateAdversarialInputs(orig, mut),
            ...extraInputs
        ];
        for (const input of edgeCases) {
            if (!this.compareOnce(origRunner, mutRunner, input, issues)) {
                this.lastCounterexample = input;
                return false;
            }
        }

        // Property-based differential testing on random integer arrays
        const result = fc.check(
            fc.property(
                fc.array(fc.integer({ min: -10000, max: 10000 }), { minLength: 0, maxLength: 300 }),
                (arr) => this.compareOnce(origRunner, mutRunner, arr, issues)
            ),
            { numRuns: 200 }
        );

        if (result.failed) {
            issues.push(`Differential fuzzing found divergence. Counterexample: ${JSON.stringify(result.counterexample).slice(0, 200)}`);
            // fast-check shrinks to a minimal counterexample: persist THAT
            this.lastCounterexample = Array.isArray(result.counterexample) ? result.counterexample[0] : result.counterexample;
            return false;
        }
        return true;
    }

    private compareOnce(origRunner: (i: any) => any, mutRunner: (i: any) => any, input: any, issues: string[]): boolean {
        let r1: any, e1: string | null = null;
        let r2: any, e2: string | null = null;
        try { r1 = origRunner(input); } catch (e: any) { e1 = e.constructor?.name || 'Error'; }
        try { r2 = mutRunner(input); } catch (e: any) { e2 = e.constructor?.name || 'Error'; }

        if (e1 !== e2) return false;
        if (e1 !== null) return true; // both threw the same class of error
        return JSON.stringify(r1) === JSON.stringify(r2);
    }
}
