import * as vm from 'vm';
import * as ts from 'typescript';

export interface Invariant {
    name: string;
    description: string;
    check: (fn: (input: number[]) => any, probes: number[][]) => boolean;
}

export interface InvariantProfile {
    invariants: string[];
    descriptions: Record<string, string>;
}

/**
 * Preuve formelle légère par extraction d'invariants.
 * Principe : les propriétés du SEED sont INFÉRÉES empiriquement sur un
 * corpus de sondes, puis chaque candidate est VÉRIFIÉE sur l'ensemble des
 * sondes avant d'être adoptée (jamais d'invariant supposé). Le profil
 * obtenu devient un ensemble d'obligations de preuve : toute mutation
 * doit préserver CHAQUE invariant vérifié du seed, en plus de l'égalité
 * différentielle. Une violation est nommée ("perd l'insensibilité à
 * l'ordre"), ce qui transforme un rejet brut en diagnostic.
 * C'est de la vérification par propriétés, pas du SMT — et c'est dit.
 */
export class InvariantExtractor {
    private probes: number[][];

    constructor() {
        const mk = (n: number, seed: number) => {
            const d = Array.from({ length: n }, (_, i) => i - Math.floor(n / 2));
            let s = seed;
            for (let i = n - 1; i > 0; i--) {
                s = (s * 48271) % 2147483647;
                const j = s % (i + 1);
                [d[i], d[j]] = [d[j], d[i]];
            }
            return d;
        };
        this.probes = [
            [], [0], [-1], [5], [1, 1, 1], [3, 1, 2],
            mk(20, 7), mk(50, 11), mk(200, 13), mk(200, 17),
            Array.from({ length: 30 }, () => 4),
            Array.from({ length: 40 }, (_, i) => -i)
        ];
    }

    private compile(code: string): (input: number[]) => any {
        const js = ts.transpileModule(code, { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 } }).outputText;
        const ctx = vm.createContext({ Math, Set, Map, Array, JSON, String, Number, exports: {}, module: { exports: {} } });
        new vm.Script(js).runInContext(ctx, { timeout: 2000 });
        const name = (code.match(/function\s+(\w+)/) || [])[1];
        const script = new vm.Script(`${name}(__in__)`);
        // L'argument est passé PAR RÉFÉRENCE (pas de copie profonde ici,
        // contrairement au runner de fuzzing) : c'est la seule façon
        // d'observer si la fonction mute son entrée. L'appelant fournit
        // une copie fraîche à chaque appel.
        return (input: number[]) => {
            (ctx as any).__in__ = input;
            return script.runInContext(ctx, { timeout: 2000 });
        };
    }

    private shuffle(a: number[], seed: number): number[] {
        const d = a.slice();
        let s = seed;
        for (let i = d.length - 1; i > 0; i--) {
            s = (s * 48271) % 2147483647;
            const j = s % (i + 1);
            [d[i], d[j]] = [d[j], d[i]];
        }
        return d;
    }

    private candidates(): Invariant[] {
        const safe = (f: () => boolean) => { try { return f(); } catch { return false; } };
        return [
            {
                name: 'deterministic',
                description: 'même entrée deux fois → même sortie (aucune source de hasard ni d\'état caché)',
                check: (fn, probes) => probes.every(p => safe(() => JSON.stringify(fn(p.slice())) === JSON.stringify(fn(p.slice()))))
            },
            {
                name: 'input_not_mutated',
                description: 'l\'argument n\'est jamais modifié (pureté vis-à-vis de l\'entrée)',
                check: (fn, probes) => probes.every(p => safe(() => { const c = p.slice(); fn(c); return JSON.stringify(c) === JSON.stringify(p); }))
            },
            {
                name: 'numeric_output',
                description: 'la sortie est toujours un nombre fini',
                check: (fn, probes) => probes.every(p => safe(() => Number.isFinite(fn(p.slice()))))
            },
            {
                name: 'integer_output_on_integers',
                description: 'entrées entières → sortie entière',
                check: (fn, probes) => probes.every(p => safe(() => Number.isInteger(fn(p.slice()))))
            },
            {
                name: 'order_insensitive',
                description: 'f(permutation(x)) = f(x) — le calcul ne dépend pas de l\'ordre des éléments',
                check: (fn, probes) => probes.filter(p => p.length > 1).every(p =>
                    safe(() => JSON.stringify(fn(p.slice())) === JSON.stringify(fn(this.shuffle(p, 991))) &&
                               JSON.stringify(fn(p.slice())) === JSON.stringify(fn(this.shuffle(p, 313)))))
            },
            {
                name: 'empty_input_total',
                description: 'définie sur le tableau vide (ne lève pas d\'exception sur [])',
                check: (fn) => safe(() => { fn([]); return true; })
            },
            {
                name: 'length_scalable',
                description: 'accepte des tailles d\'entrée arbitraires sans exception (1 à 200 testées)',
                check: (fn, probes) => probes.every(p => safe(() => { fn(p.slice()); return true; }))
            }
        ];
    }

    /** Infers then VERIFIES invariants of the seed. Never assumes. */
    public extract(code: string): InvariantProfile {
        let fn: (i: number[]) => any;
        try { fn = this.compile(code); } catch { return { invariants: [], descriptions: {} }; }
        const held: string[] = [];
        const descriptions: Record<string, string> = {};
        for (const inv of this.candidates()) {
            if (inv.check(fn, this.probes)) { held.push(inv.name); descriptions[inv.name] = inv.description; }
        }
        return { invariants: held, descriptions };
    }

    /** Which of the seed's verified invariants does the mutant violate? */
    public violations(mutatedCode: string, seedProfile: InvariantProfile): string[] {
        if (seedProfile.invariants.length === 0) return [];
        let fn: (i: number[]) => any;
        try { fn = this.compile(mutatedCode); } catch { return ['compilation']; }
        const out: string[] = [];
        for (const inv of this.candidates()) {
            if (seedProfile.invariants.includes(inv.name) && !inv.check(fn, this.probes)) out.push(inv.name);
        }
        return out;
    }
}
