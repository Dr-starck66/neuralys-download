import * as vm from 'vm';
import { performance } from 'perf_hooks';
import * as ts from 'typescript';

interface SandboxRunResult {
    latencyMs: number;
    memoryMb: number;
    testPassRate: number; // 0 or 1
    actualResult?: any;
}

/**
 * Benchmark runner (vm-based isolation).
 * Fixes vs previous version:
 * - Timing measures ONLY the function invocation, not script compilation
 *   or context setup (previously ~all measured time was setup noise).
 * - Deterministic seeded-shuffled input: identical across original and
 *   evolved code, realistic (unsorted) workload for sorting benchmarks.
 * - JIT warmup runs excluded from measurement.
 */
export class SandboxRunner {
    /** Accumulateur consommé par le benchmark — empêche toute élimination de code mort. */
    public static sink = 0;

    /** Entrées exactes utilisées par le banc de mesure — servent au profilage. */
    public static benchmarkInputs(count: number = 4): number[][] {
        const r = new SandboxRunner();
        return Array.from({ length: count }, () => (r as any).makeInput());
    }

    private makeInput(): number[] {
        // Deterministic LCG shuffle - same input for every variant, every run
        const n = 1000;
        const data = Array.from({ length: n }, (_, i) => i);
        let seed = 1337;
        for (let i = n - 1; i > 0; i--) {
            seed = (seed * 1103515245 + 12345) & 0x7fffffff;
            const j = seed % (i + 1);
            [data[i], data[j]] = [data[j], data[i]];
        }
        return data;
    }

    public executeCodeBenchmark(code: string, numRuns: number = 5, expectedResult?: any): SandboxRunResult[] {
        const results: SandboxRunResult[] = [];

        try {
            const cleanCode = ts.transpileModule(code, {
                compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 }
            }).outputText;

            const scriptStr = `
                ${cleanCode}
                if (typeof processPayload === 'function') {
                    module.exports = processPayload;
                } else if (typeof exports.processPayload === 'function') {
                    module.exports = exports.processPayload;
                }
            `;
            const script = new vm.Script(scriptStr);

            const sandbox = { exports: {}, module: { exports: null as any }, Math, Set, Map, Array, JSON, String, Number, console: {} };
            const context = vm.createContext(sandbox);
            script.runInContext(context, { timeout: 5000 });
            const func = sandbox.module.exports;

            if (typeof func !== 'function') {
                throw new Error('No function exported (define function processPayload)');
            }

            // Échauffement JIT (non mesuré). 3 passes suffisaient pour une
            // fonction mono-algorithme mais pénalisaient lourdement les
            // génomes adaptatifs (plusieurs branches, plus de code à
            // optimiser) : mesuré jusqu'à 15× d'écart entre un harnais à 3
            // échauffements et un harnais à 30. Le biais favorisait
            // systématiquement le code le plus petit.
            for (let w = 0; w < 30; w++) {
                try { func(this.makeInput()); } catch { /* measured below */ }
            }

            // Calibrate repetitions so each measured sample is >= 2ms:
            // sub-millisecond samples are dominated by timer jitter and GC,
            // which previously produced noise-driven false regressions.
            let reps = 1;
            {
                const t0 = performance.now();
                try { func(this.makeInput()); } catch { /* handled below */ }
                const single = Math.max(performance.now() - t0, 0.0001);
                reps = Math.max(1, Math.min(2000, Math.ceil(2 / single)));
            }

            for (let i = 0; i < numRuns; i++) {
                // Inputs pre-generated OUTSIDE the timed section
                const inputs: number[][] = [];
                for (let r = 0; r < reps; r++) inputs.push(this.makeInput());

                const startMem = process.memoryUsage().heapUsed;
                const start = performance.now();

                let result: any;
                let crashed = false;
                try {
                    // Puits anti-élimination de code mort : le résultat de CHAQUE
                    // répétition est consommé, pas seulement le dernier. Sans cela,
                    // un moteur pourrait en principe supprimer des calculs qu'un
                    // appelant réel exigerait, et gonfler artificiellement le gain.
                    for (let r = 0; r < reps; r++) {
                        result = func(inputs[r]);
                        SandboxRunner.sink += typeof result === 'number'
                            ? (Number.isFinite(result) ? result : 0)
                            : (result == null ? 0 : 1);
                    }
                } catch {
                    crashed = true;
                }

                const end = performance.now();
                const endMem = process.memoryUsage().heapUsed;

                if (crashed) {
                    results.push({ latencyMs: 9999, memoryMb: 9999, testPassRate: 0.0 });
                    continue;
                }

                let passRate = 1.0;
                if (result === undefined || result === null || (typeof result === 'number' && isNaN(result))) {
                    passRate = 0.0;
                }
                if (expectedResult !== undefined && JSON.stringify(result) !== JSON.stringify(expectedResult)) {
                    passRate = 0.0; // semantic invariance violated
                }

                results.push({
                    latencyMs: (end - start) / reps,
                    memoryMb: Math.max(0, (endMem - startMem) / 1024 / 1024 / reps),
                    testPassRate: passRate,
                    actualResult: result
                });
            }
        } catch {
            for (let i = 0; i < numRuns; i++) {
                results.push({ latencyMs: 9999, memoryMb: 9999, testPassRate: 0.0 });
            }
        }

        return results;
    }
}
