/**
 * Generative oracle (niveau supérieur du fuzzing) : au lieu de tester
 * uniquement des familles génériques, ANALYSE les deux versions du code
 * et génère des entrées adversariales ciblées par boundary value
 * analysis : pour chaque littéral numérique et chaque seuil de condition
 * présents dans l'une OU l'autre version, produit les entrées qui
 * franchissent exactement cette frontière (valeur-1, valeur, valeur+1,
 * tableaux de cette taille, valeur en tête/queue). Les mutations cassent
 * presque toujours SUR leurs propres constantes — c'est là qu'on vise.
 */
export function generateAdversarialInputs(originalCode: string, mutatedCode: string, cap: number = 40): number[][] {
    const literals = new Set<number>([0, 1, -1]);
    const src = originalCode + '\n' + mutatedCode;
    for (const m of src.matchAll(/(?<![\w.])(-?\d+)(?!\.)/g)) {
        const v = parseInt(m[1], 10);
        if (Number.isFinite(v) && Math.abs(v) <= 100000) literals.add(v);
    }
    // Comparison thresholds get priority (x < N, x >= N, length - N...)
    for (const m of src.matchAll(/[<>]=?\s*(-?\d+)|(-?\d+)\s*[<>]=?/g)) {
        const v = parseInt(m[1] ?? m[2], 10);
        if (Number.isFinite(v)) { literals.add(v - 1); literals.add(v); literals.add(v + 1); }
    }

    const inputs: number[][] = [];
    const push = (a: number[]) => { if (inputs.length < cap) inputs.push(a); };
    const sorted = [...literals].sort((a, b) => Math.abs(a) - Math.abs(b)).slice(0, 12);

    for (const v of sorted) {
        push([v]);                              // the boundary value alone
        push([v - 1, v, v + 1]);                // crossing the boundary
        push([v, v]);                           // duplicates of it
        if (v > 0 && v <= 2000) {
            push(Array.from({ length: v }, (_, i) => i));       // array OF that size
            push(Array.from({ length: v + 1 }, (_, i) => i));   // one past that size
        }
        push([v, ...Array.from({ length: 5 }, (_, i) => i)]);   // boundary at head
        push([...Array.from({ length: 5 }, (_, i) => i), v]);   // boundary at tail
    }
    return inputs;
}
