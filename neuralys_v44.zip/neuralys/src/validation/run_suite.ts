import * as fs from 'fs';
import { DarwinDriver } from '../core/engine';
import { KnowledgeBase } from '../memory/knowledge_base';
import { generateBenchmarks } from './benchmark_generator';

/**
 * Scientific validation suite - now a thin driver over the ONE evolution
 * engine (single evaluation path; the former parallel evaluator is gone).
 * Each benchmark = a 1-generation evolution; the report aggregates the
 * engine's own measurements, p-values and lineages from the shared KB.
 */
async function main() {
    const kb = new KnowledgeBase();
    const driver = new DarwinDriver(kb);
    const benchmarks = generateBenchmarks();
    const results: any[] = [];

    for (let i = 0; i < benchmarks.length; i++) {
        const b = benchmarks[i];
        console.log(`[${i + 1}/${benchmarks.length}] ${b.id}...`);
        try {
            const res = await driver.evolve(b.id, b.category, b.code, { generations: 1, populationCap: 4, runsPerEval: 30 });
            results.push({
                benchmarkId: b.id, category: b.category,
                improved: res.totalImprovementPct > 0,
                improvementPct: res.totalImprovementPct,
                lineage: res.bestLineage,
                hypervolume: res.generations[0].hypervolume,
                accepted: res.generations[0].acceptedMutations,
                rejected: res.generations[0].rejectedMutations
            });
        } catch (e: any) {
            results.push({ benchmarkId: b.id, category: b.category, improved: false, improvementPct: 0, error: e.message });
        }
    }

    const improved = results.filter(r => r.improved && r.improvementPct > 1);
    const md = [
        '# Scientific Validation Report',
        `- Benchmarks: ${results.length}`,
        `- Improved (>1%): ${improved.length}`,
        `- Mean gain (improved): ${improved.length ? (improved.reduce((a, r) => a + r.improvementPct, 0) / improved.length).toFixed(1) : 0}%`,
        `- Rejections (regressions or divergences): ${results.reduce((a, r) => a + (r.rejected || 0), 0)}`,
        '', '| Benchmark | Categorie | Gain | Lignee |', '|---|---|---|---|',
        ...results.map(r => `| ${r.benchmarkId} | ${r.category} | ${r.improvementPct.toFixed(1)}% | ${(r.lineage || []).join(' -> ') || '-'} |`)
    ].join('\n');
    fs.writeFileSync('scientific_validation_report.md', md);
    fs.writeFileSync('scientific_validation_raw.json', JSON.stringify(results, null, 2));
    console.log(`Report written. Improved: ${improved.length}/${results.length}`);
    kb.close();
}
main();
