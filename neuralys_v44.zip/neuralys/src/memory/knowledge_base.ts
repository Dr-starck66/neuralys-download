import { hostname } from 'os';
import Database from 'better-sqlite3';
import * as path from 'path';
import * as fs from 'fs';
import * as crypto from 'crypto';

export interface MutationRecord {
    experimentId: string;
    generation: number;
    benchmarkId: string;
    category: string;
    parentHash: string;
    variantHash: string;
    strategy: string;
    accepted: boolean;
    rejectionReason: string | null;
    latencyMean: number | null;
    latencyImprovementPct: number | null;
    memoryMb: number | null;
    complexity: number | null;
    pValue: number | null;
    reasoning: string;
    signature?: string;
    language?: string;
    llmProvider?: string | null;
}

export interface StrategyStats {
    strategy: string;
    category: string;
    attempts: number;
    successes: number;
    avgImprovementPct: number;
}

/**
 * Persistent long-term knowledge base (Phase 3 / Phase 7 substrate).
 * Every mutation, benchmark outcome and failure is recorded; strategy
 * priors are derived from history and consumed by the UCB1 selector,
 * so later experiments inherit what earlier ones learned.
 */
export class KnowledgeBase {
    private db: Database.Database;

    constructor(dbPath?: string) {
        const dir = path.join(process.cwd(), 'data');
        if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
        this.db = new Database(dbPath || path.join(dir, 'knowledge.db'));
        this.db.pragma('journal_mode = WAL');
        this.migrate();
        // Idempotent column migration for pre-signature databases
        try { this.db.exec("ALTER TABLE mutations ADD COLUMN signature TEXT DEFAULT ''"); } catch { /* exists */ }
        try { this.db.exec("ALTER TABLE mutations ADD COLUMN language TEXT DEFAULT 'typescript'"); } catch { /* exists */ }
        try { this.db.exec("ALTER TABLE mutations ADD COLUMN llm_provider TEXT DEFAULT NULL"); } catch { /* exists */ }
        try { this.db.exec("ALTER TABLE mutations ADD COLUMN machine TEXT DEFAULT ''"); } catch { /* exists */ }
        try { this.db.exec("ALTER TABLE experiments ADD COLUMN manifest TEXT DEFAULT '{}'"); } catch { /* exists */ }
        try { this.db.exec("ALTER TABLE counterexamples ADD COLUMN mutation_variant_hash TEXT DEFAULT NULL"); } catch { /* exists */ }
    }

    private migrate() {
        this.db.exec(`
            CREATE TABLE IF NOT EXISTS code_artifacts (
                hash TEXT PRIMARY KEY,
                code TEXT NOT NULL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            );
            CREATE TABLE IF NOT EXISTS mutations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                experiment_id TEXT NOT NULL,
                generation INTEGER NOT NULL,
                benchmark_id TEXT NOT NULL,
                category TEXT NOT NULL,
                parent_hash TEXT NOT NULL REFERENCES code_artifacts(hash),
                variant_hash TEXT NOT NULL REFERENCES code_artifacts(hash),
                strategy TEXT NOT NULL,
                accepted INTEGER NOT NULL,
                rejection_reason TEXT,
                latency_mean REAL,
                latency_improvement_pct REAL,
                memory_mb REAL,
                complexity REAL,
                p_value REAL,
                reasoning TEXT NOT NULL,
                signature TEXT DEFAULT '',
                language TEXT DEFAULT 'typescript',
                llm_provider TEXT DEFAULT NULL,
                machine TEXT DEFAULT '',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            );
            CREATE INDEX IF NOT EXISTS idx_mutations_strategy ON mutations(strategy, category);
            CREATE INDEX IF NOT EXISTS idx_mutations_signature ON mutations(signature);
            CREATE INDEX IF NOT EXISTS idx_mutations_experiment ON mutations(experiment_id, generation);
            CREATE TABLE IF NOT EXISTS counterexamples (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                signature TEXT NOT NULL,
                input_json TEXT NOT NULL,
                source_strategy TEXT NOT NULL,
                mutation_variant_hash TEXT DEFAULT NULL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(signature, input_json)
            );
            CREATE INDEX IF NOT EXISTS idx_ce_signature ON counterexamples(signature);
            CREATE TABLE IF NOT EXISTS algorithm_meta (
                name TEXT PRIMARY KEY,
                family TEXT NOT NULL,
                time_complexity TEXT,
                memory_behavior TEXT,
                input_conditions TEXT
            );
            CREATE TABLE IF NOT EXISTS algorithm_outcomes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                algorithm TEXT NOT NULL,
                profile_class TEXT NOT NULL,
                won INTEGER NOT NULL,
                improvement_pct REAL,
                latency_ms REAL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            );
            CREATE INDEX IF NOT EXISTS idx_outcomes_class ON algorithm_outcomes(profile_class, algorithm);
            CREATE TABLE IF NOT EXISTS experiments (
                id TEXT PRIMARY KEY,
                target TEXT NOT NULL,
                generations INTEGER DEFAULT 0,
                status TEXT DEFAULT 'RUNNING',
                manifest TEXT DEFAULT '{}',
                started_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                finished_at DATETIME
            );
        `);
    }

    public static hashCode(code: string): string {
        return crypto.createHash('sha256').update(code).digest('hex').slice(0, 16);
    }

    public storeArtifact(code: string): string {
        const hash = KnowledgeBase.hashCode(code);
        this.db.prepare('INSERT OR IGNORE INTO code_artifacts (hash, code) VALUES (?, ?)').run(hash, code);
        return hash;
    }

    public getArtifact(hash: string): string | null {
        const row = this.db.prepare('SELECT code FROM code_artifacts WHERE hash = ?').get(hash) as any;
        return row ? row.code : null;
    }

    public startExperiment(id: string, target: string, manifest: object = {}) {
        this.db.prepare('INSERT OR REPLACE INTO experiments (id, target, manifest) VALUES (?, ?, ?)')
            .run(id, target, JSON.stringify(manifest));
    }

    public getExperiment(id: string): { id: string; target: string; manifest: any } | null {
        const row = this.db.prepare('SELECT id, target, manifest FROM experiments WHERE id = ?').get(id) as any;
        return row ? { ...row, manifest: JSON.parse(row.manifest || '{}') } : null;
    }

    public getExperimentSeedHash(id: string): string | null {
        // The seed is the unique root of the experiment's mutation graph
        const row = this.db.prepare(`
            SELECT parent_hash FROM mutations WHERE experiment_id = ?
            AND parent_hash NOT IN (SELECT variant_hash FROM mutations WHERE experiment_id = ?)
            LIMIT 1`).get(id, id) as any;
        return row ? row.parent_hash : null;
    }

    /** Run state for the API layer: survives restarts, shared across processes. */
    public setRunState(id: string, status: string, payload: object) {
        const exp = this.getExperiment(id);
        const manifest = exp ? exp.manifest : {};
        manifest.runState = { status, ...payload, updatedAt: new Date().toISOString() };
        this.db.prepare('INSERT OR REPLACE INTO experiments (id, target, manifest, status) VALUES (?, COALESCE((SELECT target FROM experiments WHERE id = ?), ?), ?, ?)')
            .run(id, id, id, JSON.stringify(manifest), status);
    }

    public getRunState(id: string): any | null {
        const exp = this.getExperiment(id);
        return exp?.manifest?.runState || null;
    }

    public listRuns(limit: number = 50): { id: string; target: string; status: string }[] {
        return this.db.prepare('SELECT id, target, status FROM experiments ORDER BY started_at DESC LIMIT ?').all(limit) as any[];
    }

    public finishExperiment(id: string, generations: number) {
        this.db.prepare("UPDATE experiments SET status='DONE', generations=?, finished_at=CURRENT_TIMESTAMP WHERE id=?")
            .run(generations, id);
    }

    public recordMutation(r: MutationRecord) {
        this.db.prepare(`
            INSERT INTO mutations (experiment_id, generation, benchmark_id, category, parent_hash, variant_hash,
                strategy, accepted, rejection_reason, latency_mean, latency_improvement_pct, memory_mb, complexity, p_value, reasoning, signature, language, llm_provider, machine)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `).run(
            r.experimentId, r.generation, r.benchmarkId, r.category, r.parentHash, r.variantHash,
            r.strategy, r.accepted ? 1 : 0, r.rejectionReason, r.latencyMean, r.latencyImprovementPct,
            r.memoryMb, r.complexity, r.pValue, r.reasoning, r.signature || '',
            r.language || 'typescript',
            r.strategy.startsWith('llm:') ? r.strategy.slice(4) : (r.llmProvider || null),
            hostname()
        );
    }

    /**
     * Strategy priors, optionally category-scoped. This is the memory
     * the UCB1 selector reads: history from ALL past experiments.
     */
    /**
     * Genetic memory lookup: signature-scoped priors first (structural
     * similarity transfers across functions), category fallback.
     */
    public getStrategyStatsBySignature(signature: string): StrategyStats[] {
        const rows = this.db.prepare(`
            SELECT strategy, signature as category, COUNT(*) as attempts, SUM(accepted) as successes,
                   AVG(CASE WHEN accepted=1 THEN latency_improvement_pct END) as avg_impr
            FROM mutations WHERE signature = ? GROUP BY strategy`).all(signature);
        return (rows as any[]).map(r => ({
            strategy: r.strategy, category: r.category, attempts: r.attempts,
            successes: r.successes || 0, avgImprovementPct: r.avg_impr || 0
        }));
    }

    public getStrategyStats(category?: string): StrategyStats[] {
        const rows = category
            ? this.db.prepare(`
                SELECT strategy, category, COUNT(*) as attempts, SUM(accepted) as successes,
                       AVG(CASE WHEN accepted=1 THEN latency_improvement_pct END) as avg_impr
                FROM mutations WHERE category = ? GROUP BY strategy`).all(category)
            : this.db.prepare(`
                SELECT strategy, 'ALL' as category, COUNT(*) as attempts, SUM(accepted) as successes,
                       AVG(CASE WHEN accepted=1 THEN latency_improvement_pct END) as avg_impr
                FROM mutations GROUP BY strategy`).all();

        return (rows as any[]).map(r => ({
            strategy: r.strategy,
            category: r.category,
            attempts: r.attempts,
            successes: r.successes || 0,
            avgImprovementPct: r.avg_impr || 0
        }));
    }

    public getSuccessfulLineage(benchmarkId: string): MutationRecord[] {
        return this.db.prepare(
            'SELECT * FROM mutations WHERE benchmark_id = ? AND accepted = 1 ORDER BY generation'
        ).all(benchmarkId) as any[];
    }

    /**
     * Genetic graph: full descendant tree of an artifact via recursive CTE.
     * Each edge is a mutation; nodes are content-addressed code artifacts.
     */
    public getDescendantTree(rootHash: string): { parent: string; child: string; strategy: string; accepted: boolean; depth: number }[] {
        return this.db.prepare(`
            WITH RECURSIVE tree(parent_hash, variant_hash, strategy, accepted, depth) AS (
                SELECT parent_hash, variant_hash, strategy, accepted, 1 FROM mutations WHERE parent_hash = ?
                UNION ALL
                SELECT m.parent_hash, m.variant_hash, m.strategy, m.accepted, t.depth + 1
                FROM mutations m JOIN tree t ON m.parent_hash = t.variant_hash
                WHERE t.depth < 50
            )
            SELECT parent_hash as parent, variant_hash as child, strategy, accepted, depth FROM tree ORDER BY depth
        `).all(rootHash) as any[];
    }

    /** Ancestry chain of a variant back to its root seed. */
    public getAncestry(variantHash: string): { parent: string; child: string; strategy: string; depth: number }[] {
        return this.db.prepare(`
            WITH RECURSIVE up(parent_hash, variant_hash, strategy, depth) AS (
                SELECT parent_hash, variant_hash, strategy, 1 FROM mutations WHERE variant_hash = ?
                UNION ALL
                SELECT m.parent_hash, m.variant_hash, m.strategy, u.depth + 1
                FROM mutations m JOIN up u ON m.variant_hash = u.parent_hash
                WHERE u.depth < 50
            )
            SELECT parent_hash as parent, variant_hash as child, strategy, depth FROM up ORDER BY depth DESC
        `).all(variantHash) as any[];
    }

    /**
     * Survival rate of a strategy: fraction of its offspring that themselves
     * produced accepted descendants (lineage fitness, not just point wins).
     */
    public getSurvivalRate(strategy: string): { offspring: number; fertile: number; survivalRate: number } {
        const row = this.db.prepare(`
            SELECT COUNT(*) as offspring,
                   SUM(EXISTS(SELECT 1 FROM mutations c WHERE c.parent_hash = m.variant_hash AND c.accepted = 1)) as fertile
            FROM mutations m WHERE m.strategy = ? AND m.accepted = 1
        `).get(strategy) as any;
        return { offspring: row.offspring, fertile: row.fertile || 0, survivalRate: row.offspring ? (row.fertile || 0) / row.offspring : 0 };
    }

    /** Similar past mutations: same signature, accepted, best gains first. */
    public findSimilarWinners(signature: string, limit: number = 10): MutationRecord[] {
        return this.db.prepare(`
            SELECT * FROM mutations WHERE signature = ? AND accepted = 1
            ORDER BY latency_improvement_pct DESC LIMIT ?
        `).all(signature, limit) as any[];
    }

    /**
     * Counterexample memory (CEGIS-lite): inputs that ever exposed a
     * semantic divergence are stored per signature and replayed as
     * mandatory cases against every future mutation of similar code.
     * The fuzzing oracle therefore gets strictly stronger over time.
     */
    public storeCounterexample(signature: string, input: unknown, sourceStrategy: string, mutationVariantHash?: string) {
        try {
            this.db.prepare('INSERT OR IGNORE INTO counterexamples (signature, input_json, source_strategy, mutation_variant_hash) VALUES (?, ?, ?, ?)')
                .run(signature, JSON.stringify(input), sourceStrategy, mutationVariantHash || null);
        } catch { /* non-fatal */ }
    }

    /** Counterexamples discovered while rejecting a given variant (phylogenetic annotation). */
    public getCounterexamplesForVariant(variantHash: string): { id: number; input_json: string }[] {
        return this.db.prepare('SELECT id, input_json FROM counterexamples WHERE mutation_variant_hash = ?')
            .all(variantHash) as any[];
    }

    public getCounterexamples(signature: string, limit: number = 50): unknown[] {
        return (this.db.prepare('SELECT input_json FROM counterexamples WHERE signature = ? ORDER BY id DESC LIMIT ?')
            .all(signature, limit) as any[]).map(r => { try { return JSON.parse(r.input_json); } catch { return null; } })
            .filter(x => x !== null);
    }

    /**
     * Lineage ecology (active lineages): demographic statistics of a
     * genetic subtree. Extinction = no accepted descendant exists at the
     * deepest explored level (the lineage stopped producing survivors).
     */
    public getLineageEcology(rootHash: string): {
        age: number; population: number; accepted: number;
        reproductionRate: number; geneticDiversity: number; extinct: boolean;
    } {
        const tree = this.getDescendantTree(rootHash);
        if (tree.length === 0) return { age: 0, population: 0, accepted: 0, reproductionRate: 0, geneticDiversity: 0, extinct: true };
        const age = Math.max(...tree.map(t => t.depth));
        const accepted = tree.filter(t => t.accepted).length;
        const parents = new Set(tree.map(t => t.parent));
        const strategies = new Set(tree.map(t => t.strategy));
        const deepest = tree.filter(t => t.depth === age);
        return {
            age,
            population: tree.length,
            accepted,
            reproductionRate: tree.length / parents.size,
            geneticDiversity: strategies.size / tree.length,
            extinct: !deepest.some(t => t.accepted)
        };
    }

    /* ─── Graphe de connaissance algorithmique ───────────────────────── */

    public registerAlgorithm(m: { name: string; family: string; timeComplexity: string; memoryBehavior: string; inputConditions: string }) {
        this.db.prepare('INSERT OR REPLACE INTO algorithm_meta (name, family, time_complexity, memory_behavior, input_conditions) VALUES (?, ?, ?, ?, ?)')
            .run(m.name, m.family, m.timeComplexity, m.memoryBehavior, m.inputConditions);
    }

    public recordAlgorithmOutcome(algorithm: string, profileClass: string, won: boolean, improvementPct: number | null, latencyMs: number | null) {
        this.db.prepare('INSERT INTO algorithm_outcomes (algorithm, profile_class, won, improvement_pct, latency_ms) VALUES (?, ?, ?, ?, ?)')
            .run(algorithm, profileClass, won ? 1 : 0, improvementPct, latencyMs);
    }

    /**
     * « Pour cette classe de problèmes, quel algorithme l'emporte
     * habituellement ? » — la réponse est déduite des victoires observées,
     * pas d'une table écrite à la main. Elle devient plus fiable à mesure
     * que les expériences s'accumulent, y compris entre machines fédérées.
     */
    public bestAlgorithmsForClass(profileClass: string): { algorithm: string; runs: number; wins: number; winRate: number; avgImprovementPct: number; meta: any }[] {
        const rows = this.db.prepare(`
            SELECT o.algorithm, COUNT(*) as runs, SUM(o.won) as wins,
                   AVG(CASE WHEN o.won = 1 THEN o.improvement_pct END) as avg_impr
            FROM algorithm_outcomes o WHERE o.profile_class = ?
            GROUP BY o.algorithm ORDER BY (CAST(SUM(o.won) AS REAL) / COUNT(*)) DESC, avg_impr DESC
        `).all(profileClass) as any[];
        const meta = this.db.prepare('SELECT * FROM algorithm_meta WHERE name = ?');
        return rows.map(r => ({
            algorithm: r.algorithm, runs: r.runs, wins: r.wins || 0,
            winRate: r.runs ? (r.wins || 0) / r.runs : 0,
            avgImprovementPct: r.avg_impr || 0,
            meta: meta.get(r.algorithm) || null
        }));
    }

    public knownProfileClasses(): { profile_class: string; observations: number }[] {
        return this.db.prepare('SELECT profile_class, COUNT(*) as observations FROM algorithm_outcomes GROUP BY profile_class ORDER BY observations DESC').all() as any[];
    }

    public getExperimentCount(target: string): number {
        return (this.db.prepare('SELECT COUNT(*) as c FROM experiments WHERE target = ?').get(target) as any).c;
    }

    public getTotalMutations(): number {
        return (this.db.prepare('SELECT COUNT(*) as c FROM mutations').get() as any).c;
    }

    public close() {
        this.db.close();
    }
}
