import express from 'express';
import { KnowledgeBase } from '../memory/knowledge_base';
import { DarwinDriver } from '../core/engine';
import { LineageIO } from '../tools/lineage_io';
import { FederationSync } from '../tools/federation';
import { generateBenchmarks } from '../validation/benchmark_generator';

/**
 * Public REST API (spec point 12). Thin layer over the engine and KB:
 * no logic lives here. Experiments run asynchronously; state is queried
 * from the KB, which is the single source of truth.
 */
export function createApi(kb: KnowledgeBase = new KnowledgeBase()) {
    const app = express();
    app.use(express.json({ limit: '2mb' }));
    const driver = new DarwinDriver(kb);
    const io = new LineageIO(kb);
    const fed = new FederationSync(kb);
    // L'état des runs vit dans la KB, pas en mémoire : il survit au
    // redémarrage et reste cohérent entre plusieurs processus/utilisateurs.

    // Create + launch an evolution experiment
    app.post('/experiments', (req, res) => {
        const { id, code, category, generations, populationCap } = req.body || {};
        if (!id || !code) return res.status(400).json({ error: 'id and code required' });
        const existing = kb.getRunState(id);
        if (existing && existing.status === 'RUNNING') return res.status(409).json({ error: 'experiment id already running' });
        kb.setRunState(id, 'RUNNING', {});
        driver.evolve(id, category || 'API', code, { generations, populationCap })
            .then(result => kb.setRunState(id, 'DONE', {
                totalImprovementPct: result.totalImprovementPct,
                bestLineage: result.bestLineage,
                bestCodeHash: KnowledgeBase.hashCode(result.bestCode)
            }))
            .catch(e => kb.setRunState(id, 'FAILED', { error: e.message }));
        res.status(202).json({ id, status: 'RUNNING' });
    });

    app.get('/experiments/:id', (req, res) => {
        const state = kb.getRunState(req.params.id);
        if (!state) return res.status(404).json({ error: 'unknown experiment' });
        res.json(state);
    });

    app.get('/experiments', (_req, res) => res.json(kb.listRuns()));

    app.get('/coverage', (req, res) => {
        const repoPath = String(req.query.path || '');
        if (!repoPath) return res.status(400).json({ error: 'query param `path` required' });
        try {
            const { RepoOptimizer } = require('../tools/repo_optimizer');
            res.json(new RepoOptimizer(kb).coverage(repoPath));
        } catch (e: any) { res.status(400).json({ error: e.message }); }
    });

    // Genetic graph observability
    app.get('/lineage/:hash', (req, res) => res.json({ tree: kb.getDescendantTree(req.params.hash), ascii: io.renderTree(req.params.hash) }));
    app.get('/lineage/:hash/export', (req, res) => res.json(io.export(req.params.hash)));
    app.post('/lineage/import', (req, res) => {
        try { res.json(io.import(req.body)); } catch (e: any) { res.status(400).json({ error: e.message }); }
    });
    app.post('/lineage/:hash/replay', async (req, res) => {
        try { res.json(await io.replay(req.params.hash)); } catch (e: any) { res.status(400).json({ error: e.message }); }
    });

    app.get('/artifacts/:hash', (req, res) => {
        const code = kb.getArtifact(req.params.hash);
        code ? res.json({ hash: req.params.hash, code }) : res.status(404).json({ error: 'unknown artifact' });
    });

    // Learned strategy priors + lineage survival
    app.get('/strategies', (_req, res) => {
        res.json(kb.getStrategyStats().map(s => ({ ...s, survival: kb.getSurvivalRate(s.strategy) })));
    });

    app.get('/benchmarks', (_req, res) => res.json(generateBenchmarks().map(b => ({ id: b.id, category: b.category }))));
    // Federated evolution: pull-based delta sync between nodes
    app.get('/federation/delta', (req, res) => res.json(fed.exportDelta(String(req.query.since || '1970-01-01'))));
    app.post('/federation/sync', async (req, res) => {
        try { res.json(await fed.syncFromPeer(req.body.peerUrl, req.body.since)); }
        catch (e: any) { res.status(502).json({ error: e.message }); }
    });

    app.get('/health', (_req, res) => res.json({ ok: true, mutations: kb.getTotalMutations() }));
    return app;
}

if (process.argv[1] && process.argv[1].endsWith('server.ts')) {
    const port = parseInt(process.env.PORT || '4000', 10);
    createApi().listen(port, () => console.log(`[neuralys-api] listening on :${port}`));
}
