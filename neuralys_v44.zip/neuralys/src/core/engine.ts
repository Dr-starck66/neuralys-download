import * as ss from 'simple-statistics';
import { ASTMutator } from './ast_mutator';
import { SandboxRunner } from '../validation/sandbox_runner';
import { AdvancedSemanticGuardian } from '../validation/semantic_guardian';
import { computeASTMetrics } from '../metrics/ast_complexity';
import { NSGA2, Candidate } from '../algorithms/nsga2';
import { HypervolumeTracker } from '../algorithms/hypervolume';
import { KnowledgeBase } from '../memory/knowledge_base';
import { MetaPolicySelector } from './selection_policies';
import { Canonicalizer, codeSignature } from './canonicalizer';
import { AlgorithmSpace, profileInputs, GeneratedCandidate, DataProfile, SORTING_FAMILY, ADAPTIVE_CANDIDATE } from './algorithm_space';
import { profileRuntime, profileClass, describeRuntimeProfile } from './selection_intelligence';
import { MultiAgentMutator } from '../llm/llm_providers';
import * as os from 'os';

/**
 * Genome (explicit DNA): `strategyLineage` is the gene sequence (ordered
 * operator applications), `code` the phenotype, `parents` the direct
 * ancestry (two entries for crossover children), fitness = the metric
 * vector below. Descendants/history live in the KB genetic graph.
 */
export interface Individual {
    id: string;
    code: string;
    parents: string[];
    strategyLineage: string[];
    latencyMean: number;
    latencySamples: number[];
    memoryMean: number;
    complexity: number;
    codeSize: number;
    passRate: number;
}

export interface GenerationReport {
    generation: number;
    populationSize: number;
    bestLatencyMs: number;
    improvementVsSeedPct: number;
    paretoFrontSize: number;
    acceptedMutations: number;
    rejectedMutations: number;
    strategyRanking: { strategy: string; ucb: number; attempts: number }[];
    selectionPolicy: string;
    metaPolicyState: { policy: string; posteriorSample: number; observations: number }[];
    hypervolume: number;
    explorationBoost: boolean;
}

export interface ExperimentResult {
    intent: string;
    dataProfile: DataProfile;
    dataClass: string;
    dataProfileDescription: string;
    benchmarkId: string;
    seedLatencyMs: number;
    finalBestLatencyMs: number;
    totalImprovementPct: number;
    generations: GenerationReport[];
    bestCode: string;
    bestLineage: string[];
}

/**
 * Generational Darwinian loop (Phases 2/6/7/10 integrated):
 * - Population of semantically-verified variants
 * - Variation: bandit-ordered symbolic rules + rule-set crossover + optional LLM
 * - Selection: NSGA-II on [latency, memory, cyclomatic complexity] (minimization)
 * - Learning: every outcome recorded in the persistent knowledge base and
 *   fed back into the UCB1 priors for this and all future experiments
 * - Explainability: full lineage, measured deltas and p-values persisted
 */
/** Métadonnées statiques du graphe de connaissance algorithmique. */
const ALGO_COMPLEXITY: Record<string, { time: string; memory: string }> = {
    native_timsort: { time: 'O(n log n)', memory: 'O(n) copie' },
    insertion_sort: { time: 'O(n + I) où I = inversions', memory: 'O(1) en place' },
    counting_sort: { time: 'O(n + k)', memory: 'O(k) — k = étendue des valeurs' },
    radix_sort_lsd: { time: 'O(n · w)', memory: 'O(n + 256)' },
    merge_sort: { time: 'O(n log n) garanti', memory: 'O(n log n) allocations' },
    adaptive_dispatch: { time: 'profilage O(n) + coût de la branche choisie', memory: 'celle de la branche choisie' }
};

export class DarwinDriver {
    private ast = new ASTMutator();
    private multiAgent = new MultiAgentMutator();
    private canon = new Canonicalizer();
    private algoSpace = new AlgorithmSpace();
    private runner = new SandboxRunner();
    private guardian = new AdvancedSemanticGuardian();

    constructor(private kb: KnowledgeBase) {}

    public async evolve(
        benchmarkId: string,
        category: string,
        seedCode: string,
        opts: { generations?: number; populationCap?: number; runsPerEval?: number } = {}
    ): Promise<ExperimentResult> {
        const generations = opts.generations ?? 4;
        const populationCap = opts.populationCap ?? 8;
        const runsPerEval = opts.runsPerEval ?? 20;
        const experimentId = `exp-${benchmarkId}-${Date.now()}`;

        const seedHash = this.kb.storeArtifact(seedCode);
        const signature = codeSignature(seedCode);
        // Time Machine manifest: everything needed to reproduce this run.
        // Deterministic layers (sandbox LCG seeds, fuzz seeds, MC seed) are
        // compile-time constants; the stochastic layer (LLM outputs) is
        // reproduced from recorded artifacts, never re-sampled.
        this.kb.startExperiment(experimentId, benchmarkId, {
            seedHash,
            category,
            signature,
            config: { generations, populationCap, runsPerEval },
            environment: {
                node: process.version,
                platform: `${os.platform()}-${os.arch()}`,
                hostname: os.hostname(),
                cpus: os.cpus()[0]?.model || 'unknown'
            },
            determinism: { sandboxSeed: 1337, fuzzSeed: 'fast-check default + fixed families', hypervolumeSeed: 424242 },
            llmProviders: this.multiAgent.availableProviders(),
            recordedImprovementPct: null as number | null
        });

        const seed = this.evaluate('seed', seedCode, [], runsPerEval, []);
        if (seed.passRate < 1.0) throw new Error('Seed failed baseline validation.');

        // Espace de recherche algorithmique : dérivé de l'INTENTION du code et
        // du profil des données réellement mesurées, pas d'une table de
        // correspondance. Chaque candidat devient un bras de bandit à part
        // entière et repart dans le pipeline de preuve habituel.
        const benchInputs = SandboxRunner.benchmarkInputs();
        const dataProfile: DataProfile = profileInputs(benchInputs);
        const runtimeProfile = profileRuntime(benchInputs.reduce((a, b) => (b.length > a.length ? b : a), benchInputs[0] || []));
        const dataClass = profileClass(runtimeProfile);
        // Métadonnées du graphe de connaissance : complexité, comportement
        // mémoire et conditions d'entrée de chaque implémentation candidate.
        for (const c of [...SORTING_FAMILY, ADAPTIVE_CANDIDATE]) {
            this.kb.registerAlgorithm({
                name: c.name, family: c.family,
                timeComplexity: ALGO_COMPLEXITY[c.name]?.time || 'n/a',
                memoryBehavior: ALGO_COMPLEXITY[c.name]?.memory || 'n/a',
                inputConditions: c.rationale
            });
        }
        const algoCandidates: GeneratedCandidate[] = this.algoSpace.generate(seedCode, dataProfile);
        const algoArms = algoCandidates.map(c => c.strategy);
        const ruleNames = this.ast.getRules().map(r => r.name);
        const llmArms = this.multiAgent.availableProviders().map(p => `llm:${p}`);
        const bandit = new MetaPolicySelector(this.kb, [...ruleNames, ...algoArms, ...llmArms, 'crossover_rule_union'], category, signature);

        let population: Individual[] = [seed];
        const reports: GenerationReport[] = [];
        const hvTracker = new HypervolumeTracker();
        const storedCEs = this.kb.getCounterexamples(signature);
        let explorationBoost = false;
        // Ecosystem dynamics: a parent accumulating consecutive failed
        // offspring becomes sterile (extinct as a reproducer) and stops
        // consuming variation budget; selection may still keep its code.
        const consecutiveFailures = new Map<string, number>();
        const STERILITY_THRESHOLD = 4;
        // Canonical hashes: alpha-equivalent variants (same computation,
        // different naming/layout) are deduplicated BEFORE any benchmark runs
        const triedHashes = new Set<string>([this.canon.canonicalHash(seedCode)]);

        for (let gen = 1; gen <= generations; gen++) {
            let accepted = 0, rejected = 0;
            const offspring: Individual[] = [];
            const activePolicy = bandit.beginGeneration();
            const ranking = bandit.rankArms();

            // Stagnation-adaptive exploration: when the Pareto front stops
            // growing (hypervolume plateau), invert the strategy order for
            // this generation - least-tried operators first - and widen the
            // per-parent offspring budget. Deterministic, KB-observable.
            const orderedStrategies = explorationBoost
                ? [...ranking].sort((a, b) => a.attempts - b.attempts).map(r => r.strategy)
                : ranking.map(r => r.strategy);

            for (const parent of population) {
                if ((consecutiveFailures.get(parent.id) || 0) >= STERILITY_THRESHOLD) continue; // extinct lineage tip
                const candidates = await this.generateOffspring(parent, orderedStrategies, population, explorationBoost ? 4 : 3, algoCandidates);

                for (const cand of candidates) {
                    const candHashEarly = this.canon.canonicalHash(cand.code);
                    if (triedHashes.has(candHashEarly)) continue; // alpha-equivalent or already-tried: skip benchmark entirely
                    triedHashes.add(candHashEarly);

                    // Stored counterexamples for this signature are replayed
                    // as mandatory cases (CEGIS-lite regression corpus)
                    const verdict = await this.guardian.evaluateEquivalence(seedCode, cand.code, storedCEs);
                    const parentHash = KnowledgeBase.hashCode(parent.code);
                    const candHash = this.kb.storeArtifact(cand.code);
                    const strategy = cand.strategyLineage[cand.strategyLineage.length - 1];

                    if (!verdict.passed) {
                        rejected++;
                        consecutiveFailures.set(parent.id, (consecutiveFailures.get(parent.id) || 0) + 1);
                        if (verdict.counterexample !== undefined) {
                            this.kb.storeCounterexample(signature, verdict.counterexample, strategy, candHash);
                        }
                        bandit.update(strategy, false, 0);
                        this.kb.recordMutation({
                            experimentId, generation: gen, benchmarkId, category,
                            parentHash, variantHash: candHash, strategy,
                            accepted: false, rejectionReason: `semantic:${verdict.issues[0] || 'divergence'}`,
                            latencyMean: null, latencyImprovementPct: null, memoryMb: null,
                            complexity: null, pValue: null,
                            reasoning: this.explainStrategy(strategy), signature
                        });
                        continue;
                    }

                    const evaluated = this.evaluate(cand.id, cand.code, cand.strategyLineage, runsPerEval, [KnowledgeBase.hashCode(parent.code)]);
                    if (evaluated.passRate < 1.0) {
                        rejected++;
                        bandit.update(strategy, false, 0);
                        this.kb.recordMutation({
                            experimentId, generation: gen, benchmarkId, category,
                            parentHash, variantHash: candHash, strategy,
                            accepted: false, rejectionReason: 'runtime:behavior_or_crash',
                            latencyMean: evaluated.latencyMean, latencyImprovementPct: null,
                            memoryMb: evaluated.memoryMean, complexity: evaluated.complexity, pValue: null,
                            reasoning: this.explainStrategy(strategy), signature
                        });
                        continue;
                    }

                    const { pValue, significantlyBetter } = this.compare(parent.latencySamples, evaluated.latencySamples);
                    const improvementPct = (parent.latencyMean - evaluated.latencyMean) / parent.latencyMean * 100;
                    const keep = significantlyBetter || improvementPct > -5; // NSGA-II arbitrates borderline cases

                    const kbAccepted = keep && improvementPct > 0;
                    if (strategy.startsWith('algo:')) {
                        this.kb.recordAlgorithmOutcome(strategy.slice(5), dataClass, kbAccepted, improvementPct, evaluated.latencyMean);
                    }
                    if (keep) { accepted++; offspring.push(evaluated); consecutiveFailures.set(parent.id, 0); }
                    else { rejected++; consecutiveFailures.set(parent.id, (consecutiveFailures.get(parent.id) || 0) + 1); }
                    bandit.update(strategy, kbAccepted, improvementPct);
                    this.kb.recordMutation({
                        experimentId, generation: gen, benchmarkId, category,
                        parentHash, variantHash: candHash, strategy,
                        accepted: kbAccepted,
                        rejectionReason: keep ? null : 'performance:regression',
                        latencyMean: evaluated.latencyMean, latencyImprovementPct: improvementPct,
                        memoryMb: evaluated.memoryMean, complexity: evaluated.complexity, pValue,
                        reasoning: this.explainStrategy(strategy), signature
                    });
                }
            }

            population = this.select([...population, ...offspring], populationCap);
            const best = population.reduce((a, b) => a.latencyMean < b.latencyMean ? a : b);
            const reference = [
                Math.max(...population.map(p => p.latencyMean)) * 1.1 || 1,
                Math.max(...population.map(p => p.memoryMean)) * 1.1 || 1,
                Math.max(...population.map(p => p.complexity)) * 1.1 || 1,
                Math.max(...population.map(p => p.codeSize)) * 1.1 || 1
            ];
            const hv = hvTracker.record(
                population.map(p => [p.latencyMean, p.memoryMean, p.complexity, p.codeSize]),
                reference
            );
            const boostNext = hvTracker.isStagnant();
            reports.push({
                generation: gen,
                populationSize: population.length,
                bestLatencyMs: best.latencyMean,
                improvementVsSeedPct: (seed.latencyMean - best.latencyMean) / seed.latencyMean * 100,
                paretoFrontSize: this.paretoFrontSize(population),
                acceptedMutations: accepted,
                rejectedMutations: rejected,
                strategyRanking: bandit.rankArms().map(r => ({ strategy: r.strategy, ucb: Number(r.ucb.toFixed(3)), attempts: r.attempts })),
                selectionPolicy: activePolicy,
                metaPolicyState: bandit.metaState(),
                hypervolume: Number(hv.toFixed(4)),
                explorationBoost
            });
            explorationBoost = boostNext;
        }

        const best = population.reduce((a, b) => a.latencyMean < b.latencyMean ? a : b);
        // Persist the measured outcome into the manifest for replay comparison
        const exp = this.kb.getExperiment(experimentId);
        if (exp) {
            exp.manifest.recordedImprovementPct = (seed.latencyMean - best.latencyMean) / seed.latencyMean * 100;
            this.kb.startExperiment(experimentId, benchmarkId, exp.manifest);
        }
        this.kb.finishExperiment(experimentId, generations);
        return {
            intent: this.algoSpace.detect(seedCode),
            dataProfile,
            dataClass,
            dataProfileDescription: describeRuntimeProfile(runtimeProfile),
            benchmarkId,
            seedLatencyMs: seed.latencyMean,
            finalBestLatencyMs: best.latencyMean,
            totalImprovementPct: (seed.latencyMean - best.latencyMean) / seed.latencyMean * 100,
            generations: reports,
            bestCode: best.code,
            bestLineage: best.strategyLineage
        };
    }

    private async generateOffspring(parent: Individual, orderedStrategies: string[], population: Individual[], budget: number = 3, algoCandidates: GeneratedCandidate[] = []) {
        const out: { id: string; code: string; strategyLineage: string[] }[] = [];

        for (const strategy of orderedStrategies) {
            const rule = this.ast.getRules().find(r => r.name === strategy);
            if (rule) {
                try {
                    const mutated = rule.apply(parent.code);
                    if (mutated !== parent.code) {
                        out.push({ id: `${parent.id}>${strategy}`, code: mutated, strategyLineage: [...parent.strategyLineage, strategy] });
                    }
                } catch { /* rule inapplicable */ }
            } else if (strategy.startsWith('algo:')) {
                // Substitution d'algorithme : seulement sur le seed (le site de
                // tri disparaît après la première substitution)
                const cand = algoCandidates.find(c => c.strategy === strategy);
                if (cand && parent.strategyLineage.every(g => !g.startsWith('algo:'))) {
                    out.push({ id: `${parent.id}>${strategy}`, code: cand.code, strategyLineage: [...parent.strategyLineage, strategy] });
                }
            } else if (strategy.startsWith('llm:')) {
                // Multi-agent ensemble: each provider proposes independently;
                // provider identity is preserved so the bandit learns per model
                const proposals = await this.multiAgent.proposeAll(parent.code);
                for (const prop of proposals) {
                    out.push({ id: `${parent.id}>llm:${prop.provider}`, code: prop.code, strategyLineage: [...parent.strategyLineage, `llm:${prop.provider}`] });
                }
            } else if (strategy === 'crossover_rule_union' && population.length >= 2) {
                // Rule-set crossover: apply the union of both parents' successful rule lineages to the seed's fittest parent
                const other = population[Math.floor(Math.random() * population.length)];
                if (other !== parent && other.strategyLineage.length > 0) {
                    let code = parent.code;
                    for (const rn of other.strategyLineage) {
                        const r = this.ast.getRules().find(x => x.name === rn);
                        if (r) { try { const nx = r.apply(code); if (nx !== code) code = nx; } catch { /* skip */ } }
                    }
                    if (code !== parent.code) {
                        out.push({ id: `${parent.id}x${other.id}`, code, strategyLineage: [...parent.strategyLineage, 'crossover_rule_union'] });
                    }
                }
            }
            if (out.length >= budget) break; // bounded variation per parent per generation
        }
        return out;
    }

    private evaluate(id: string, code: string, lineage: string[], runs: number, parents: string[] = []): Individual {
        const samples = this.runner.executeCodeBenchmark(code, runs);
        const latencies = samples.map(s => s.latencyMs);
        // Maintainability objective = cyclomatic complexity + max nesting
        // depth (deep nesting is the readability cost the raw cyclomatic
        // count misses). One composite keeps the Pareto at 4 objectives,
        // where NSGA-II crowding remains statistically meaningful.
        let complexity = 0;
        try {
            complexity = computeASTMetrics(code).cyclomaticComplexity + this.maxNestingDepth(code);
        } catch { complexity = 999; }
        return {
            id, code, parents, strategyLineage: lineage,
            latencyMean: ss.mean(latencies),
            latencySamples: latencies,
            memoryMean: ss.mean(samples.map(s => s.memoryMb)),
            complexity,
            codeSize: code.replace(/\s+/g, '').length,
            passRate: samples.reduce((a, s) => a + s.testPassRate, 0) / samples.length
        };
    }

    private maxNestingDepth(code: string): number {
        let depth = 0, max = 0;
        for (const ch of code) {
            if (ch === '{') { depth++; if (depth > max) max = depth; }
            else if (ch === '}') depth--;
        }
        return max;
    }

    private compare(baseline: number[], candidate: number[]) {
        try {
            const t = ss.tTestTwoSample(baseline, candidate, 0) || 0;
            const pValue = ss.cumulativeStdNormalProbability(-Math.abs(t)) * 2;
            return { pValue, significantlyBetter: pValue < 0.05 && ss.mean(candidate) < ss.mean(baseline) };
        } catch {
            const better = ss.mean(candidate) < ss.mean(baseline);
            return { pValue: better ? 0 : 1, significantlyBetter: better };
        }
    }

    private select(pool: Individual[], cap: number): Individual[] {
        const candidates: Candidate[] = pool.map((ind, i) => ({
            id: String(i), branchName: ind.id,
            objectives: [ind.latencyMean, ind.memoryMean, ind.complexity, ind.codeSize],
            dominationCount: 0, dominatedSolutions: [], rank: -1, crowdingDistance: 0
        }));
        const fronts = NSGA2.fastNonDominatedSort(candidates);
        for (const f of fronts) NSGA2.assignCrowdingDistance(f);

        const survivors: Individual[] = [];
        for (const front of fronts) {
            const sorted = [...front].sort((a, b) => b.crowdingDistance - a.crowdingDistance);
            for (const c of sorted) {
                if (survivors.length >= cap) return survivors;
                survivors.push(pool[Number(c.id)]);
            }
        }
        return survivors;
    }

    private paretoFrontSize(pop: Individual[]): number {
        const candidates: Candidate[] = pop.map((ind, i) => ({
            id: String(i), branchName: ind.id,
            objectives: [ind.latencyMean, ind.memoryMean, ind.complexity, ind.codeSize],
            dominationCount: 0, dominatedSolutions: [], rank: -1, crowdingDistance: 0
        }));
        return NSGA2.fastNonDominatedSort(candidates)[0].length;
    }

    private explainStrategy(strategy: string): string {
        const explanations: Record<string, string> = {
            sort_idiom_recognition: 'Replaces O(n^2) adjacent compare-and-swap loops with native TimSort (O(n log n)).',
            shift_to_index_pointer: 'Replaces Array.shift() dequeue with a head index pointer to avoid per-call element moves.',
            string_accumulation_to_join: 'Replaces string += accumulation with array push + single join to avoid quadratic copies.',
            indexof_to_set_lookup: 'Replaces linear String.indexOf membership tests with O(1) Set.has lookups.',
            loop_invariant_length_caching: 'Hoists loop-invariant .length reads out of loop conditions.',
            strength_reduction: 'Replaces integer multiplication by powers of two with bit shifts.',
            llm_architectural_refactor: 'LLM-proposed architectural or algorithmic rewrite (behavior-preserving).',
            common_subexpression_elimination: 'Hoists repeated pure element accesses inside loop bodies into a single const.',
            crossover_rule_union: 'Genetic crossover: applies the union of two parents\' successful rule lineages.'
        };
        if (strategy.startsWith('algo:')) {
            const c = SORTING_FAMILY.find(x => `algo:${x.name}` === strategy);
            return c ? `Substitution algorithmique dérivée de l'intention « tri croissant » : ${c.rationale}.` : strategy;
        }
        if (strategy.startsWith('llm:')) return `Architectural rewrite proposed by the ${strategy.slice(4)} model (ensemble member), behavior-preserving.`;
        return explanations[strategy] || strategy;
    }
}
