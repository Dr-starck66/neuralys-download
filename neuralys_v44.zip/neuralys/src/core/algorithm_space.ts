import { Project, SyntaxKind, Node } from 'ts-morph';
import { ADAPTIVE_DISPATCHER, RuntimeProfile } from './selection_intelligence';

/**
 * ═══ ESPACE DE RECHERCHE ALGORITHMIQUE ═══════════════════════════════════
 *
 * Rupture avec le schéma « motif → remplacement ». Le pipeline devient :
 *
 *     code → intention → profil de données observé → espace de candidats
 *          → preuve d'équivalence → mesure → sélection
 *
 * Le moteur ne sait plus « remplacer un tri à bulles par sort() ». Il sait
 * qu'un fragment de code A POUR INTENTION de trier en ordre croissant, et
 * dérive de cette intention une famille d'implémentations interchangeables.
 * Le choix final n'est pas écrit dans une règle : il émerge de la mesure sur
 * la distribution de données réellement observée.
 *
 * Limite à énoncer : l'algorithme retenu est optimal POUR LE PROFIL MESURÉ.
 * Si la distribution de production diffère du corpus de benchmark, le choix
 * peut être mauvais. Le profil est donc reporté dans le rapport, jamais tu.
 */

export type Intent = 'sort_ascending' | 'unknown';

export interface DataProfile {
    size: number;
    valueRange: number;        // max - min
    uniqueRatio: number;       // valeurs distinctes / taille
    sortedness: number;        // fraction de paires adjacentes ordonnées (conservé: NE PRÉDIT PAS le coût du tri par insertion)
    inversionDensity?: number; // 0 = trié, ~0,5 = aléatoire — le vrai prédicteur
    entropy?: number;
    integersOnly: boolean;
}

export interface AlgorithmCandidate {
    name: string;
    family: Intent;
    /** Priorité a priori pour ce profil : ordonne l'exploration, ne décide rien. */
    priorFor(profile: DataProfile): number;
    /** Source du helper, en place, retournant le tableau (sémantique de Array#sort). */
    source(helperName: string): string;
    rationale: string;
}

/* ─── Profilage des données réellement passées au harnais ─────────────── */

export function profileInputs(inputs: number[][]): DataProfile {
    const flat = inputs.filter(a => a.length > 0);
    if (flat.length === 0) return { size: 0, valueRange: 0, uniqueRatio: 1, sortedness: 1, integersOnly: true };
    const sample = flat.reduce((a, b) => (b.length > a.length ? b : a));
    let min = sample[0], max = sample[0], integersOnly = true, ordered = 0;
    const seen = new Set<number>();
    for (let i = 0; i < sample.length; i++) {
        const v = sample[i];
        if (v < min) min = v;
        if (v > max) max = v;
        if (!Number.isInteger(v)) integersOnly = false;
        seen.add(v);
        if (i > 0 && sample[i - 1] <= v) ordered++;
    }
    // densité d'inversions échantillonnée, O(k)
    let s = 1337, inv = 0, pairs = 0;
    for (let t = 0; t < 512; t++) {
        s = (Math.imul(s, 1103515245) + 12345) & 0x7fffffff; const i = s % sample.length;
        s = (Math.imul(s, 1103515245) + 12345) & 0x7fffffff; const j = s % sample.length;
        if (i === j) continue;
        const lo = Math.min(i, j), hi = Math.max(i, j);
        if (sample[lo] > sample[hi]) inv++;
        pairs++;
    }
    return {
        size: sample.length,
        valueRange: max - min,
        uniqueRatio: seen.size / sample.length,
        sortedness: sample.length > 1 ? ordered / (sample.length - 1) : 1,
        inversionDensity: pairs ? inv / pairs : 0,
        integersOnly
    };
}

/* ─── Famille « tri croissant » ───────────────────────────────────────── */

const writeBack = (body: string) => `
    const __out = ${body};
    for (let __i = 0; __i < __a.length; __i++) __a[__i] = __out[__i];
    return __a;`;

export const SORTING_FAMILY: AlgorithmCandidate[] = [
    {
        name: 'native_timsort',
        family: 'sort_ascending',
        rationale: "TimSort natif du moteur : référence robuste, aucune hypothèse sur les données",
        priorFor: () => 0.5,
        source: (h) => `function ${h}(__a) {${writeBack('__a.slice().sort((__x, __y) => __x - __y)')}\n}`
    },
    {
        name: 'insertion_sort',
        family: 'sort_ascending',
        rationale: "O(n·d) où d est le désordre : imbattable sur des données presque triées, catastrophique sinon",
        // Prédicteur corrigé : c'est la densité d'inversions qui gouverne le
        // coût d'un tri par insertion, pas la fraction d'ordre local.
        priorFor: (p) => (p.inversionDensity !== undefined
            ? (p.inversionDensity < 0.02 ? 1.0 : p.size < 50 ? 0.6 : 0.02)
            : (p.sortedness > 0.9 ? 1.0 : 0.05)),
        source: (h) => `function ${h}(__a) {
    for (let __i = 1; __i < __a.length; __i++) {
        const __v = __a[__i];
        let __j = __i - 1;
        while (__j >= 0 && __a[__j] > __v) { __a[__j + 1] = __a[__j]; __j--; }
        __a[__j + 1] = __v;
    }
    return __a;
}`
    },
    {
        name: 'counting_sort',
        family: 'sort_ascending',
        rationale: "O(n + k) : domine quand l'étendue des valeurs est petite ou les doublons nombreux",
        priorFor: (p) => (!p.integersOnly ? 0 : p.valueRange <= 4 * p.size ? 1.0 : 0.1),
        source: (h) => `function ${h}(__a) {
    if (__a.length === 0) return __a;
    let __mn = __a[0], __mx = __a[0];
    for (let __i = 1; __i < __a.length; __i++) { if (__a[__i] < __mn) __mn = __a[__i]; if (__a[__i] > __mx) __mx = __a[__i]; }
    const __range = __mx - __mn + 1;
    if (!Number.isInteger(__range) || __range > 4 * __a.length + 4096) {
        const __s = __a.slice().sort((__x, __y) => __x - __y);
        for (let __i = 0; __i < __a.length; __i++) __a[__i] = __s[__i];
        return __a;
    }
    const __counts = new Int32Array(__range);
    for (let __i = 0; __i < __a.length; __i++) __counts[__a[__i] - __mn]++;
    let __k = 0;
    for (let __v = 0; __v < __range; __v++) for (let __c = __counts[__v]; __c > 0; __c--) __a[__k++] = __v + __mn;
    return __a;
}`
    },
    {
        name: 'radix_sort_lsd',
        family: 'sort_ascending',
        rationale: "O(n·w) par chiffres base 256 : bat les tris comparatifs sur de grands volumes d'entiers",
        priorFor: (p) => (!p.integersOnly ? 0 : p.size >= 500 ? 0.8 : 0.2),
        source: (h) => `function ${h}(__a) {
    if (__a.length === 0) return __a;
    let __mn = __a[0];
    for (let __i = 1; __i < __a.length; __i++) if (__a[__i] < __mn) __mn = __a[__i];
    if (!Number.isInteger(__mn) || !__a.every(Number.isInteger)) {
        const __s = __a.slice().sort((__x, __y) => __x - __y);
        for (let __i = 0; __i < __a.length; __i++) __a[__i] = __s[__i];
        return __a;
    }
    let __arr = new Array(__a.length);
    for (let __i = 0; __i < __a.length; __i++) __arr[__i] = __a[__i] - __mn;
    let __mx = 0;
    for (let __i = 0; __i < __arr.length; __i++) if (__arr[__i] > __mx) __mx = __arr[__i];
    for (let __exp = 1; Math.floor(__mx / __exp) > 0; __exp *= 256) {
        const __buckets = new Int32Array(256), __out = new Array(__arr.length);
        for (let __i = 0; __i < __arr.length; __i++) __buckets[Math.floor(__arr[__i] / __exp) % 256]++;
        for (let __i = 1; __i < 256; __i++) __buckets[__i] += __buckets[__i - 1];
        for (let __i = __arr.length - 1; __i >= 0; __i--) { const __d = Math.floor(__arr[__i] / __exp) % 256; __out[--__buckets[__d]] = __arr[__i]; }
        __arr = __out;
    }
    for (let __i = 0; __i < __a.length; __i++) __a[__i] = __arr[__i] + __mn;
    return __a;
}`
    },
    {
        name: 'merge_sort',
        family: 'sort_ascending',
        rationale: "O(n log n) stable et sans pire cas quadratique : garantie de robustesse",
        priorFor: () => 0.3,
        source: (h) => `function ${h}(__a) {
    const __merge = (__l, __r) => {
        const __o = new Array(__l.length + __r.length);
        let __i = 0, __j = 0, __k = 0;
        while (__i < __l.length && __j < __r.length) __o[__k++] = __l[__i] <= __r[__j] ? __l[__i++] : __r[__j++];
        while (__i < __l.length) __o[__k++] = __l[__i++];
        while (__j < __r.length) __o[__k++] = __r[__j++];
        return __o;
    };
    const __ms = (__x) => __x.length <= 1 ? __x : __merge(__ms(__x.slice(0, __x.length >> 1)), __ms(__x.slice(__x.length >> 1)));
    const __s = __ms(__a.slice());
    for (let __i = 0; __i < __a.length; __i++) __a[__i] = __s[__i];
    return __a;
}`
    }
];

/**
 * Candidat ADAPTATIF : au lieu de figer une implémentation, le code évolué
 * embarque le dispatcher et les implémentations, et choisit à l'exécution
 * selon le profil de SON entrée. Supprime la limite du choix figé — le prix
 * est un surcoût de profilage O(n), mesuré comme tout le reste.
 */
export const ADAPTIVE_CANDIDATE: AlgorithmCandidate = {
    name: 'adaptive_dispatch',
    family: 'sort_ascending',
    rationale: "profile l'entrée à l'exécution (densité d'inversions, étendue, type) et choisit l'implémentation — robuste au changement de distribution, au prix d'une passe O(n)",
    priorFor: () => 0.9,
    source: () => [
        ADAPTIVE_DISPATCHER,
        ...SORTING_FAMILY.map(c => c.source(`__ns_${c.name}`))
    ].join('\n\n')
};

/* ─── Détection d'intention ───────────────────────────────────────────── */

export interface SortSite {
    /** Texte exact à remplacer dans le source. */
    snippet: string;
    /** Nom du tableau trié en place. */
    arrayName: string;
    /** Ce que le site doit produire : instruction (in place) ou expression. */
    kind: 'statement' | 'expression';
}

export class IntentDetector {
    private project = new Project({ useInMemoryFileSystem: true });

    /**
     * Reconnaît une INTENTION de tri croissant, quelle que soit sa forme :
     * - imbrication compare-échange adjacente (tri à bulles, tout nommage)
     * - appel `.sort((a, b) => a - b)` déjà présent
     * La détection est structurelle (AST), donc insensible au style.
     */
    public detectSort(code: string): SortSite | null {
        const file = this.project.createSourceFile('intent.ts', code, { overwrite: true });

        // Forme 1 : appel de tri comparatif numérique croissant
        for (const call of file.getDescendantsOfKind(SyntaxKind.CallExpression)) {
            const callee = call.getExpression();
            if (!Node.isPropertyAccessExpression(callee) || callee.getName() !== 'sort') continue;
            const cmp = call.getArguments()[0];
            if (!cmp) continue;
            const t = cmp.getText().replace(/\s+/g, '');
            const m = t.match(/^\((\w+),(\w+)\)=>\1-\2$/);
            if (!m) continue;
            const obj = callee.getExpression();
            if (!Node.isIdentifier(obj)) continue;
            return { snippet: call.getText(), arrayName: obj.getText(), kind: 'expression' };
        }

        // Forme 2 : idiome compare-échange adjacent (tri à bulles)
        for (const outer of file.getDescendantsOfKind(SyntaxKind.ForStatement)) {
            const inners = outer.getDescendantsOfKind(SyntaxKind.ForStatement).filter(f => f !== outer);
            if (inners.length !== 1) continue;
            const ifs = inners[0].getDescendantsOfKind(SyntaxKind.IfStatement);
            if (ifs.length !== 1) continue;
            const test = ifs[0].getExpression().getText().replace(/\s+/g, '');
            const m = test.match(/^(\w+)\[(\w+)\]>(\w+)\[\2\+1\]$/);
            if (!m || m[1] !== m[3]) continue;
            const body = ifs[0].getThenStatement().getText().replace(/[\s{}]/g, '');
            const arr = m[1], idx = m[2];
            const swap = new RegExp(`^(?:const|let|var)(\\w+)=${arr}\\[${idx}\\];${arr}\\[${idx}\\]=${arr}\\[${idx}\\+1\\];${arr}\\[${idx}\\+1\\]=\\1;$`);
            if (!swap.test(body)) continue;
            return { snippet: outer.getText(), arrayName: arr, kind: 'statement' };
        }
        return null;
    }
}

/* ─── Génération de l'espace de recherche ─────────────────────────────── */

export interface GeneratedCandidate {
    strategy: string;       // ex. « algo:counting_sort »
    code: string;
    rationale: string;
    prior: number;
}

export class AlgorithmSpace {
    private detector = new IntentDetector();

    /**
     * Produit une variante par implémentation candidate de la famille
     * correspondant à l'intention détectée. Rien n'est retenu ici : chaque
     * candidat repart dans le pipeline normal (invariants → fuzzing →
     * benchmark → Pareto). L'ordre reflète le profil de données observé.
     */
    public generate(code: string, profile: DataProfile): GeneratedCandidate[] {
        const site = this.detector.detectSort(code);
        if (!site) return [];

        const out: GeneratedCandidate[] = [];
        for (const cand of [...SORTING_FAMILY, ADAPTIVE_CANDIDATE]) {
            const helper = `__ns_${cand.name}`;
            const call = `${helper}(${site.arrayName})`;
            let mutated: string;
            if (site.kind === 'statement') {
                mutated = code.replace(site.snippet, `${call};`);
            } else {
                mutated = code.replace(site.snippet, call);
            }
            if (mutated === code) continue;
            // helper injecté après la fonction : portée module, aucun risque de capture
            mutated = `${mutated}\n\n${cand.source(helper)}`;
            out.push({
                strategy: `algo:${cand.name}`,
                code: mutated,
                rationale: cand.rationale,
                prior: cand.priorFor(profile)
            });
        }
        return out.sort((a, b) => b.prior - a.prior);
    }

    public detect(code: string): Intent {
        return this.detector.detectSort(code) ? 'sort_ascending' : 'unknown';
    }

    public static describeProfile(p: DataProfile): string {
        const traits: string[] = [`n=${p.size}`, `étendue=${p.valueRange}`];
        if (p.sortedness > 0.9) traits.push('presque trié');
        if (p.uniqueRatio < 0.3) traits.push('nombreux doublons');
        if (p.valueRange <= 4 * p.size) traits.push('petite étendue');
        if (!p.integersOnly) traits.push('non entiers');
        return traits.join(', ');
    }
}
