import { KnowledgeBase } from '../memory/knowledge_base';

export interface SelectionPolicy {
    name: string;
    rank(): { strategy: string; score: number; attempts: number }[];
    update(strategy: string, accepted: boolean, improvementPct: number): void;
}

/** UCB1: deterministic optimism under uncertainty. */
export class UCB1Policy implements SelectionPolicy {
    public name = 'ucb1';
    protected counts = new Map<string, number>();
    protected rewards = new Map<string, number>();
    protected totalPulls = 0;

    constructor(arms: string[], priors: { strategy: string; attempts: number; successes: number; avgImprovementPct: number }[]) {
        for (const a of arms) { this.counts.set(a, 0); this.rewards.set(a, 0); }
        for (const p of priors) {
            if (!this.counts.has(p.strategy)) continue;
            this.counts.set(p.strategy, p.attempts);
            this.rewards.set(p.strategy, p.successes * (1 + Math.min(Math.max(p.avgImprovementPct, 0), 100) / 100) / 2);
            this.totalPulls += p.attempts;
        }
    }

    rank() {
        const out: { strategy: string; score: number; attempts: number }[] = [];
        for (const [arm, n] of this.counts.entries()) {
            const mean = n > 0 ? this.rewards.get(arm)! / n : 0;
            const expl = n > 0 ? Math.sqrt((2 * Math.log(Math.max(this.totalPulls, 1))) / n) : Number.POSITIVE_INFINITY;
            out.push({ strategy: arm, score: mean + expl, attempts: n });
        }
        return out.sort((a, b) => b.score - a.score);
    }

    update(strategy: string, accepted: boolean, improvementPct: number) {
        if (!this.counts.has(strategy)) { this.counts.set(strategy, 0); this.rewards.set(strategy, 0); }
        this.counts.set(strategy, this.counts.get(strategy)! + 1);
        this.totalPulls++;
        if (accepted) this.rewards.set(strategy, this.rewards.get(strategy)! + (1 + Math.min(Math.max(improvementPct, 0), 100) / 100) / 2);
    }
}

/**
 * Thompson Sampling: Beta-Bernoulli posterior per arm, one sample per
 * ranking. Stochastic exploration - complements UCB1's determinism.
 * Priors from the KB initialize alpha (successes) and beta (failures).
 */
export class ThompsonPolicy implements SelectionPolicy {
    public name = 'thompson';
    private alpha = new Map<string, number>();
    private beta = new Map<string, number>();

    constructor(arms: string[], priors: { strategy: string; attempts: number; successes: number }[]) {
        for (const a of arms) { this.alpha.set(a, 1); this.beta.set(a, 1); }
        for (const p of priors) {
            if (!this.alpha.has(p.strategy)) continue;
            this.alpha.set(p.strategy, 1 + p.successes);
            this.beta.set(p.strategy, 1 + Math.max(0, p.attempts - p.successes));
        }
    }

    private sampleBeta(a: number, b: number): number {
        // Marsaglia-Tsang gamma sampling; Beta = Ga/(Ga+Gb)
        const gamma = (shape: number): number => {
            if (shape < 1) return gamma(shape + 1) * Math.pow(Math.random(), 1 / shape);
            const d = shape - 1 / 3, c = 1 / Math.sqrt(9 * d);
            for (;;) {
                let x: number, v: number;
                do {
                    const u1 = Math.random(), u2 = Math.random();
                    x = Math.sqrt(-2 * Math.log(u1)) * Math.cos(2 * Math.PI * u2);
                    v = 1 + c * x;
                } while (v <= 0);
                v = v * v * v;
                const u = Math.random();
                if (u < 1 - 0.0331 * x * x * x * x) return d * v;
                if (Math.log(u) < 0.5 * x * x + d * (1 - v + Math.log(v))) return d * v;
            }
        };
        const ga = gamma(a), gb = gamma(b);
        return ga / (ga + gb);
    }

    rank() {
        const out: { strategy: string; score: number; attempts: number }[] = [];
        for (const [arm, a] of this.alpha.entries()) {
            const b = this.beta.get(arm)!;
            out.push({ strategy: arm, score: this.sampleBeta(a, b), attempts: a + b - 2 });
        }
        return out.sort((x, y) => y.score - x.score);
    }

    update(strategy: string, accepted: boolean, _improvementPct: number) {
        if (!this.alpha.has(strategy)) { this.alpha.set(strategy, 1); this.beta.set(strategy, 1); }
        if (accepted) this.alpha.set(strategy, this.alpha.get(strategy)! + 1);
        else this.beta.set(strategy, this.beta.get(strategy)! + 1);
    }
}

/**
 * META-EVOLUTION of the selection operator itself: a meta-bandit
 * (Thompson) chooses, per generation, WHICH policy ranks the strategies.
 * The policy whose generations produce more accepted mutations gains
 * posterior mass - the engine learns how to learn. Meta-policy state is
 * persisted in the KB as strategy records under category 'MetaPolicy'.
 */
export class MetaPolicySelector {
    private meta: ThompsonPolicy;
    private policies: Map<string, SelectionPolicy>;
    private activePolicy: SelectionPolicy;

    constructor(kb: KnowledgeBase, arms: string[], category?: string, signature?: string) {
        let priors = signature ? kb.getStrategyStatsBySignature(signature) : [];
        if (priors.length === 0) priors = kb.getStrategyStats(category);
        this.policies = new Map<string, SelectionPolicy>([
            ['ucb1', new UCB1Policy(arms, priors)],
            ['thompson', new ThompsonPolicy(arms, priors)]
        ]);
        const metaPriors = kb.getStrategyStats('MetaPolicy');
        this.meta = new ThompsonPolicy(['ucb1', 'thompson'], metaPriors);
        this.activePolicy = this.policies.get(this.meta.rank()[0].strategy)!;
    }

    /** Called at the start of each generation. */
    public beginGeneration(): string {
        this.activePolicy = this.policies.get(this.meta.rank()[0].strategy)!;
        return this.activePolicy.name;
    }

    public rankArms() { return this.activePolicy.rank().map(r => ({ strategy: r.strategy, ucb: r.score, attempts: r.attempts })); }

    public update(strategy: string, accepted: boolean, improvementPct: number) {
        // Both policies observe every outcome (shared evidence);
        // only the active one earns meta-credit.
        for (const p of this.policies.values()) p.update(strategy, accepted, improvementPct);
        this.meta.update(this.activePolicy.name, accepted, improvementPct);
    }

    public metaState() {
        return this.meta.rank().map(r => ({ policy: r.strategy, posteriorSample: Number(r.score.toFixed(3)), observations: r.attempts }));
    }
}
