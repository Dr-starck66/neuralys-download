import { KnowledgeBase } from '../memory/knowledge_base';
import { ThompsonPolicy } from './selection_policies';

export interface EngineConfig {
    populationCap: number;
    generations: number;
    runsPerEval: number;
}

const CONFIG_ARMS: Record<string, EngineConfig> = {
    'frugal':      { populationCap: 4, generations: 2, runsPerEval: 12 },
    'balanced':    { populationCap: 6, generations: 3, runsPerEval: 20 },
    'exploratory': { populationCap: 8, generations: 4, runsPerEval: 15 },
    'rigorous':    { populationCap: 6, generations: 2, runsPerEval: 30 }
};

/**
 * Meta-evolution of the engine's own hyperparameters (spec: "l'évolution
 * de l'évolution"). A Thompson bandit over discrete engine configurations,
 * rewarded by IMPROVEMENT PER SECOND (gain must pay for its compute).
 * Posterior state persists in the KB (category 'MetaHyperparams'), so the
 * daemon's unattended cycles converge on the config that earns the most
 * per unit of benchmark time on this machine and corpus.
 */
export class HyperparamEvolver {
    private bandit: ThompsonPolicy;
    private current: string = 'balanced';

    constructor(private kb: KnowledgeBase) {
        this.bandit = new ThompsonPolicy(Object.keys(CONFIG_ARMS), kb.getStrategyStats('MetaHyperparams'));
    }

    public next(): { name: string; config: EngineConfig } {
        this.current = this.bandit.rank()[0].strategy;
        return { name: this.current, config: CONFIG_ARMS[this.current] };
    }

    public report(improvementPct: number, durationSec: number) {
        const gainPerSec = improvementPct / Math.max(durationSec, 1);
        const success = gainPerSec > 0.5; // >0.5%/s of compute
        this.bandit.update(this.current, success, gainPerSec);
        const metaHash = this.kb.storeArtifact(`// meta-hyperparam arm: ${this.current}`);
        this.kb.recordMutation({
            experimentId: `meta-${Date.now()}`, generation: 0, benchmarkId: 'hyperparams',
            category: 'MetaHyperparams', parentHash: metaHash, variantHash: metaHash,
            strategy: this.current, accepted: success, rejectionReason: null,
            latencyMean: durationSec, latencyImprovementPct: gainPerSec,
            memoryMb: null, complexity: null, pValue: null,
            reasoning: `engine config arm; reward = improvement%/s = ${gainPerSec.toFixed(2)}`
        });
    }
}
