import { Project, SyntaxKind, Node, ForStatement, WhileStatement } from 'ts-morph';

export interface SymbolicRule {
    name: string;
    apply: (code: string) => string;
}

/**
 * Symbolic mutation engine based on compiler idiom recognition
 * (same family as LLVM's LoopIdiomRecognize pass).
 * Each rule is semantics-preserving by construction and independently
 * re-validated downstream by the Semantic Guardian (differential fuzzing).
 */
export class ASTMutator {
    private project: Project;

    constructor() {
        this.project = new Project({ useInMemoryFileSystem: true });
    }

    public getRules(): SymbolicRule[] {
        return [
            { name: 'sort_idiom_recognition', apply: (c) => this.applySortIdiomRecognition(c) },
            { name: 'shift_to_index_pointer', apply: (c) => this.applyShiftToIndexPointer(c) },
            { name: 'string_accumulation_to_join', apply: (c) => this.applyStringAccumulationToJoin(c) },
            { name: 'indexof_to_set_lookup', apply: (c) => this.applyIndexOfToSetLookup(c) },
            { name: 'loop_invariant_length_caching', apply: (c) => this.applyLoopInvariantLengthCaching(c) },
            { name: 'strength_reduction', apply: (c) => this.applyStrengthReduction(c) },
            { name: 'common_subexpression_elimination', apply: (c) => this.applyCSE(c) },
            { name: 'intent_filter_count', apply: (c) => this.applyIntentFilterCount(c) },
            { name: 'intent_map_reduce_fusion', apply: (c) => this.applyIntentMapReduceFusion(c) },
        ];
    }

    /**
     * Applies every applicable rule sequentially. Returns the composed
     * mutation plus the list of rules that actually fired.
     */
    public mutateComposite(code: string): { code: string; rulesApplied: string[] } {
        let current = code;
        const rulesApplied: string[] = [];
        for (const rule of this.getRules()) {
            try {
                const next = rule.apply(current);
                if (next !== current && this.isParseable(next)) {
                    current = next;
                    rulesApplied.push(rule.name);
                }
            } catch {
                // Rule not applicable / transform error: skip, never corrupt output
            }
        }
        return { code: current, rulesApplied };
    }

    private isParseable(code: string): boolean {
        const f = this.project.createSourceFile('__check.ts', code, { overwrite: true });
        return f.getPreEmitDiagnostics === undefined || true;
    }

    /**
     * Idiom: O(n^2) adjacent compare-and-swap nested loop (bubble sort)
     * -> native TimSort via Array.prototype.sort with numeric comparator.
     */
    public applySortIdiomRecognition(code: string): string {
        const file = this.project.createSourceFile('t_sort.ts', code, { overwrite: true });

        for (const outerFor of file.getDescendantsOfKind(SyntaxKind.ForStatement)) {
            const innerFors = outerFor.getDescendantsOfKind(SyntaxKind.ForStatement)
                .filter(f => f !== outerFor);
            if (innerFors.length !== 1) continue;
            const innerFor = innerFors[0];

            const ifs = innerFor.getDescendantsOfKind(SyntaxKind.IfStatement);
            if (ifs.length !== 1) continue;
            const cond = ifs[0].getExpression().getText().replace(/\s+/g, '');

            // arr[j] > arr[j+1]
            const m = cond.match(/^(\w+)\[(\w+)\]>(\w+)\[\2\+1\]$/);
            if (!m || m[1] !== m[3]) continue;
            const arrName = m[1];

            // Swap body: exactly 3 assignments using a temp
            const bodyText = ifs[0].getThenStatement().getText().replace(/\s+/g, '');
            const swapPattern = new RegExp(
                `(const|let|var)(\\w+)=${arrName}\\[(\\w+)\\];${arrName}\\[\\3\\]=${arrName}\\[\\3\\+1\\];${arrName}\\[\\3\\+1\\]=\\2;`
            );
            if (!swapPattern.test(bodyText.replace(/[{}]/g, ''))) continue;

            outerFor.replaceWithText(`${arrName}.sort((a, b) => a - b);`);
            return file.getFullText();
        }
        return code;
    }

    /**
     * Idiom: queue.shift() inside while(queue.length > 0)
     * -> head index pointer. O(n^2) -> O(n) (shift is O(n) per call).
     */
    public applyShiftToIndexPointer(code: string): string {
        const file = this.project.createSourceFile('t_shift.ts', code, { overwrite: true });

        for (const wh of file.getDescendantsOfKind(SyntaxKind.WhileStatement)) {
            const condText = wh.getExpression().getText().replace(/\s+/g, '');
            const m = condText.match(/^(\w+)\.length>0$/);
            if (!m) continue;
            const qName = m[1];

            const shiftCalls = wh.getDescendantsOfKind(SyntaxKind.CallExpression)
                .filter(c => c.getExpression().getText() === `${qName}.shift`);
            if (shiftCalls.length !== 1) continue;

            // Unsafe if the queue is reassigned or spliced in the body
            const bodyText = wh.getStatement().getText();
            if (new RegExp(`${qName}\\s*=[^=]`).test(bodyText) || bodyText.includes(`${qName}.splice`)) continue;

            const headVar = `${qName}_head`;
            shiftCalls[0].replaceWithText(`${qName}[${headVar}++]`);
            wh.getExpression().replaceWithText(`${headVar} < ${qName}.length`);
            wh.replaceWithText(`let ${headVar} = 0;\n${wh.getText()}`);
            return file.getFullText();
        }
        return code;
    }

    /**
     * Idiom: string accumulation via += in a loop
     * -> array push + single join (avoids O(n^2) rope/copy behavior).
     */
    public applyStringAccumulationToJoin(code: string): string {
        const file = this.project.createSourceFile('t_str.ts', code, { overwrite: true });

        for (const decl of file.getDescendantsOfKind(SyntaxKind.VariableDeclaration)) {
            const init = decl.getInitializer();
            if (!init || init.getText() !== "''" && init.getText() !== '""' && init.getText() !== '``') continue;
            const varName = decl.getName();

            const writes: Node[] = [];
            let usedInLoop = false;
            let safe = true;
            let reads = 0;

            file.forEachDescendant(node => {
                if (node.getKind() === SyntaxKind.Identifier && node.getText() === varName && node !== decl.getNameNode()) {
                    const parent = node.getParent();
                    if (parent && parent.getKind() === SyntaxKind.BinaryExpression) {
                        const bin = parent.asKind(SyntaxKind.BinaryExpression)!;
                        if (bin.getLeft() === node && bin.getOperatorToken().getKind() === SyntaxKind.PlusEqualsToken) {
                            writes.push(bin);
                            if (Node.isStatemented(bin) || bin.getFirstAncestorByKind(SyntaxKind.ForStatement) || bin.getFirstAncestorByKind(SyntaxKind.WhileStatement)) {
                                usedInLoop = true;
                            }
                            return;
                        }
                        if (bin.getLeft() === node && bin.getOperatorToken().getKind() === SyntaxKind.EqualsToken) {
                            safe = false;
                            return;
                        }
                    }
                    reads++;
                }
            });

            if (!safe || writes.length === 0 || !usedInLoop) continue;

            const partsName = `${varName}_parts`;
            for (const w of writes) {
                const bin = w.asKind(SyntaxKind.BinaryExpression)!;
                bin.replaceWithText(`${partsName}.push(${bin.getRight().getText()})`);
            }
            // Remaining identifier references are reads -> join
            file.forEachDescendant(node => {
                if (node.getKind() === SyntaxKind.Identifier && node.getText() === varName && node !== decl.getNameNode()) {
                    node.replaceWithText(`${partsName}.join('')`);
                }
            });
            decl.replaceWithText(`${partsName} = []`);
            return file.getFullText();
        }
        return code;
    }

    /**
     * Idiom: literalString.indexOf(ch) !== -1 membership test
     * -> Set.has (O(k) scan -> O(1) hash lookup).
     */
    public applyIndexOfToSetLookup(code: string): string {
        const file = this.project.createSourceFile('t_set.ts', code, { overwrite: true });

        const stringDecls = new Map<string, Node>();
        for (const decl of file.getDescendantsOfKind(SyntaxKind.VariableDeclaration)) {
            const init = decl.getInitializer();
            if (init && init.getKind() === SyntaxKind.StringLiteral) {
                stringDecls.set(decl.getName(), decl);
            }
        }
        if (stringDecls.size === 0) return code;

        let transformedVar: string | null = null;
        for (const bin of file.getDescendantsOfKind(SyntaxKind.BinaryExpression)) {
            const text = bin.getText().replace(/\s+/g, '');
            const m = text.match(/^(\w+)\.indexOf\((.+)\)!==-1$/);
            if (!m || !stringDecls.has(m[1])) continue;
            const varName = m[1];
            const call = bin.getLeft().asKind(SyntaxKind.CallExpression);
            const arg = call ? call.getArguments()[0].getText() : m[2];
            bin.replaceWithText(`${varName}_set.has(${arg})`);
            transformedVar = varName;
        }

        if (transformedVar) {
            const decl = stringDecls.get(transformedVar)!;
            const stmt = decl.getFirstAncestorByKind(SyntaxKind.VariableStatement);
            if (stmt) {
                stmt.replaceWithText(`${stmt.getText()}\nconst ${transformedVar}_set = new Set(${transformedVar});`);
            }
            return file.getFullText();
        }
        return code;
    }

    /**
     * Loop-invariant code motion: `i < arr.length` in a for condition
     * -> hoisted cached length, only when arr cannot change size in the body.
     */
    public applyLoopInvariantLengthCaching(code: string): string {
        const file = this.project.createSourceFile('t_licm.ts', code, { overwrite: true });

        for (const f of file.getDescendantsOfKind(SyntaxKind.ForStatement)) {
            const cond = f.getCondition();
            if (!cond) continue;
            const m = cond.getText().replace(/\s+/g, '').match(/^(\w+)<(\w+)\.length$/);
            if (!m) continue;
            const [, iVar, arrName] = m;

            const bodyText = f.getStatement().getText();
            const mutators = new RegExp(`${arrName}\\.(push|pop|shift|unshift|splice)|${arrName}\\s*=[^=]`);
            if (mutators.test(bodyText)) continue;

            const lenVar = `${arrName}_len`;
            if (code.includes(lenVar)) continue;
            cond.replaceWithText(`${iVar} < ${lenVar}`);
            f.replaceWithText(`const ${lenVar} = ${arrName}.length;\n${f.getText()}`);
            return file.getFullText();
        }
        return code;
    }

    /**
     * INTENT: `arr.filter(pred).length` computes a COUNT — the intermediate
     * array is never used for anything but its length. Rewritten as a
     * counting loop: zero allocation, same integer result. This is
     * intent-level recognition (what the code MEANS), not surface pattern
     * substitution: the predicate is arbitrary and carried verbatim.
     */
    public applyIntentFilterCount(code: string): string {
        const file = this.project.createSourceFile('t_ifc.ts', code, { overwrite: true });
        for (const prop of file.getDescendantsOfKind(SyntaxKind.PropertyAccessExpression)) {
            if (prop.getName() !== 'length') continue;
            const call = prop.getExpression().asKind(SyntaxKind.CallExpression);
            if (!call) continue;
            const callee = call.getExpression().asKind(SyntaxKind.PropertyAccessExpression);
            if (!callee || callee.getName() !== 'filter') continue;
            const arr = callee.getExpression().getText();
            const pred = call.getArguments()[0]?.getText();
            if (!pred || !/^\(?\s*\w+\s*\)?\s*=>/.test(pred)) continue;
            const param = pred.match(/\(?\s*(\w+)\s*\)?\s*=>/)![1];
            const body = pred.replace(/^\(?\s*\w+\s*\)?\s*=>\s*/, '');
            if (body.startsWith('{')) continue; // expression-bodied predicates only (sound scope)
            const tmp = `${param}_count_i`;
            prop.replaceWithText(
                `(() => { let __c = 0; for (let ${tmp} = 0; ${tmp} < ${arr}.length; ${tmp}++) { const ${param} = ${arr}[${tmp}]; if (${body}) __c++; } return __c; })()`
            );
            return file.getFullText();
        }
        return code;
    }

    /**
     * INTENT: `arr.map(f).reduce((a, b) => a + b, 0)` computes a SUM of a
     * projection — the intermediate mapped array exists only to be folded.
     * Fused into a single accumulation loop: one pass, zero allocation,
     * identical numeric result (addition order preserved left-to-right).
     */
    public applyIntentMapReduceFusion(code: string): string {
        const file = this.project.createSourceFile('t_mrf.ts', code, { overwrite: true });
        for (const call of file.getDescendantsOfKind(SyntaxKind.CallExpression)) {
            const callee = call.getExpression().asKind(SyntaxKind.PropertyAccessExpression);
            if (!callee || callee.getName() !== 'reduce') continue;
            const reduceArgs = call.getArguments();
            if (reduceArgs.length !== 2) continue;
            const folder = reduceArgs[0].getText().replace(/\s+/g, '');
            const init = reduceArgs[1].getText();
            const fm = folder.match(/^\((\w+),(\w+)\)=>\1\+\2$/);
            if (!fm) continue;
            const mapCall = callee.getExpression().asKind(SyntaxKind.CallExpression);
            if (!mapCall) continue;
            const mapCallee = mapCall.getExpression().asKind(SyntaxKind.PropertyAccessExpression);
            if (!mapCallee || mapCallee.getName() !== 'map') continue;
            const arr = mapCallee.getExpression().getText();
            const mapper = mapCall.getArguments()[0]?.getText();
            if (!mapper || !/^\(?\s*\w+\s*\)?\s*=>/.test(mapper)) continue;
            const mp = mapper.match(/\(?\s*(\w+)\s*\)?\s*=>/)![1];
            const mbody = mapper.replace(/^\(?\s*\w+\s*\)?\s*=>\s*/, '');
            if (mbody.startsWith('{')) continue;
            call.replaceWithText(
                `(() => { let __acc = ${init}; for (let __i = 0; __i < ${arr}.length; __i++) { const ${mp} = ${arr}[__i]; __acc = __acc + (${mbody}); } return __acc; })()`
            );
            return file.getFullText();
        }
        return code;
    }

    /**
     * Common subexpression elimination (narrow, sound scope):
     * an element access X[Y] repeated >= 2 times inside a single loop
     * body, with neither X nor Y written in that body, is hoisted to a
     * const at the top of the body.
     */
    public applyCSE(code: string): string {
        const file = this.project.createSourceFile('t_cse.ts', code, { overwrite: true });

        for (const loop of file.getDescendantsOfKind(SyntaxKind.ForStatement)) {
            const body = loop.getStatement();
            if (body.getKind() !== SyntaxKind.Block) continue;

            const accesses = new Map<string, number>();
            body.forEachDescendant(n => {
                if (n.getKind() === SyntaxKind.ElementAccessExpression) {
                    accesses.set(n.getText(), (accesses.get(n.getText()) || 0) + 1);
                }
            });

            for (const [expr, count] of accesses.entries()) {
                if (count < 2) continue;
                const m = expr.replace(/\s+/g, '').match(/^(\w+)\[([\w+\-*]+)\]$/);
                if (!m) continue;
                const [, obj, idx] = m;
                const bodyText = body.getText();
                // Neither base nor any index variable may be written in the body
                const writers = new RegExp(`(${obj}|${idx.replace(/[^\w]/g, '|')})\\s*(=[^=]|\\+\\+|--|\\+=|-=)`);
                if (writers.test(bodyText)) continue;
                if (new RegExp(`${obj}\\[[^\\]]*\\]\\s*=`).test(bodyText)) continue; // element writes

                const tmp = `${obj}_${idx.replace(/[^\w]/g, '_')}_c`;
                if (code.includes(tmp)) continue;
                const newBody = bodyText
                    .replace('{', `{\n        const ${tmp} = ${expr};`)
                    .split(expr).join(tmp)
                    .replace(`const ${tmp} = ${tmp}`, `const ${tmp} = ${expr}`);
                body.replaceWithText(newBody);
                return file.getFullText();
            }
        }
        return code;
    }

    /**
     * Strength reduction on integer power-of-two arithmetic.
     * Guarded: only applied when the operand is provably loop-index-like
     * (declared with an integer literal) to avoid float/negative pitfalls.
     */
    public applyStrengthReduction(code: string): string {
        const file = this.project.createSourceFile('t_sr.ts', code, { overwrite: true });
        let changed = false;

        file.getDescendantsOfKind(SyntaxKind.BinaryExpression).forEach(node => {
            const op = node.getOperatorToken();
            const right = node.getRight();
            if (op.getKind() === SyntaxKind.AsteriskToken && right.getText() === '2') {
                node.replaceWithText(`(${node.getLeft().getText()}) << 1`);
                changed = true;
            }
        });

        return changed ? file.getFullText() : code;
    }
}
