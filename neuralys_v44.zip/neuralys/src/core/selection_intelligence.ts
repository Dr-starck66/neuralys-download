/**
 * ═══ INTELLIGENCE DE SÉLECTION ALGORITHMIQUE ════════════════════════════
 *
 * Trois briques, dans l'ordre causal :
 *
 *  1. PROFILEUR — décrit une distribution par des grandeurs qui PRÉDISENT
 *     réellement le coût des algorithmes. Point corrigé après mesure : la
 *     « fraction de paires adjacentes ordonnées » est un FAUX prédicteur du
 *     coût d'un tri par insertion. Un jeu de données peut être localement
 *     ordonné à 95 % et globalement désordonné (densité d'inversions 0,52) ;
 *     le tri par insertion y est catastrophique. Le bon prédicteur est la
 *     densité d'inversions, estimée par échantillonnage en O(k).
 *
 *  2. GÉNOME ADAPTATIF — au lieu de figer un algorithme choisi sur le profil
 *     du banc de mesure, le code évolué PORTE le dispatcher : il profile son
 *     entrée à l'exécution et choisit. Cela supprime la limite structurelle
 *     du choix figé (« optimal pour le profil observé, faux ailleurs »).
 *
 *  3. VALIDATION ADVERSARIALE DE PERFORMANCE — recherche automatique du jeu
 *     de données qui MET EN DÉFAUT le champion. L'oracle adversarial existant
 *     attaque la correction ; celui-ci attaque la performance.
 */

export interface RuntimeProfile {
    size: number;
    valueRange: number;
    uniqueRatio: number;
    /** Densité d'inversions échantillonnée : 0 = trié, ~0,5 = aléatoire. Prédit le coût des tris par insertion. */
    inversionDensity: number;
    /** Entropie de Shannon normalisée (0 = une seule valeur, 1 = uniforme). Prédit le gain des tris par distribution. */
    entropy: number;
    integersOnly: boolean;
    /** Empreinte mémoire estimée du tableau, en octets. */
    memoryBytes: number;
}

const LCG = (seed: number) => {
    let s = seed >>> 0;
    return () => { s = (Math.imul(s, 1103515245) + 12345) & 0x7fffffff; return s; };
};

export function profileRuntime(sample: number[], sampleSize = 512): RuntimeProfile {
    const n = sample.length;
    if (n === 0) return { size: 0, valueRange: 0, uniqueRatio: 1, inversionDensity: 0, entropy: 0, integersOnly: true, memoryBytes: 0 };

    let min = sample[0], max = sample[0], integersOnly = true;
    for (let i = 0; i < n; i++) {
        const v = sample[i];
        if (v < min) min = v;
        if (v > max) max = v;
        if (integersOnly && !Number.isInteger(v)) integersOnly = false;
    }

    const rnd = LCG(1337);
    const seen = new Set<number>();
    const hist = new Map<number, number>();
    const probes = Math.min(n, sampleSize);
    for (let t = 0; t < probes; t++) {
        const v = sample[rnd() % n];
        seen.add(v);
        hist.set(v, (hist.get(v) || 0) + 1);
    }

    // Entropie de Shannon sur l'échantillon, normalisée par log2(distinctes)
    let entropy = 0;
    for (const c of hist.values()) {
        const p = c / probes;
        entropy -= p * Math.log2(p);
    }
    const maxEntropy = Math.log2(Math.max(seen.size, 2));
    entropy = maxEntropy > 0 ? Math.min(1, entropy / maxEntropy) : 0;

    // Densité d'inversions : paires (i<j) tirées au hasard, O(k)
    let inv = 0, pairs = 0;
    for (let t = 0; t < sampleSize; t++) {
        const i = rnd() % n, j = rnd() % n;
        if (i === j) continue;
        const lo = Math.min(i, j), hi = Math.max(i, j);
        if (sample[lo] > sample[hi]) inv++;
        pairs++;
    }

    return {
        size: n,
        valueRange: max - min,
        uniqueRatio: seen.size / probes,
        inversionDensity: pairs ? inv / pairs : 0,
        entropy,
        integersOnly,
        memoryBytes: n * 8 + 96
    };
}

export function describeRuntimeProfile(p: RuntimeProfile): string {
    const t: string[] = [`n=${p.size}`, `étendue=${p.valueRange}`, `inversions=${p.inversionDensity.toFixed(2)}`, `entropie=${p.entropy.toFixed(2)}`];
    if (p.inversionDensity < 0.05) t.push('quasi trié');
    if (p.uniqueRatio < 0.3) t.push('doublons massifs');
    if (p.integersOnly && p.valueRange <= 4 * p.size) t.push('petite étendue');
    if (!p.integersOnly) t.push('non entiers');
    return t.join(', ');
}

/**
 * Classe de profil : clef grossière et stable servant de contexte
 * d'apprentissage inter-runs. Deux jeux de données de la même classe
 * appellent les mêmes algorithmes gagnants — c'est l'hypothèse que la base
 * de connaissance valide ou réfute au fil des expériences.
 */
export function profileClass(p: RuntimeProfile): string {
    const sizeB = p.size < 100 ? 'S' : p.size < 5000 ? 'M' : 'L';
    const rangeB = !p.integersOnly ? 'float' : p.valueRange <= 4 * p.size ? 'dense' : 'sparse';
    const orderB = p.inversionDensity < 0.05 ? 'sorted' : p.inversionDensity < 0.25 ? 'partial' : 'random';
    const dupB = p.uniqueRatio < 0.3 ? 'dups' : 'unique';
    return `${sizeB}/${rangeB}/${orderB}/${dupB}`;
}

/* ─── Génome adaptatif ────────────────────────────────────────────────── */

/** Dispatcher émis dans le code évolué : profile son entrée puis choisit. */
export const ADAPTIVE_DISPATCHER = `function __ns_adaptive_dispatch(__a) {
    const __n = __a.length;
    if (__n < 2) return __a;
    let __mn = __a[0], __mx = __a[0], __ints = true;
    for (let __i = 0; __i < __n; __i++) {
        const __v = __a[__i];
        if (__v < __mn) __mn = __v;
        if (__v > __mx) __mx = __v;
        if (__ints && !Number.isInteger(__v)) __ints = false;
    }
    // densité d'inversions échantillonnée : prédicteur du coût d'un tri par
    // insertion. L'ordre local ne prédit rien (mesuré : 0,95 d'ordre local
    // pour 0,52 d'inversions), c'est cette grandeur qui décide.
    let __s = 1337, __inv = 0, __pairs = 0;
    const __probes = __n < 64 ? __n : 128;
    for (let __t = 0; __t < __probes; __t++) {
        __s = (Math.imul(__s, 1103515245) + 12345) & 0x7fffffff; const __i = __s % __n;
        __s = (Math.imul(__s, 1103515245) + 12345) & 0x7fffffff; const __j = __s % __n;
        if (__i === __j) continue;
        const __lo = __i < __j ? __i : __j, __hi = __i < __j ? __j : __i;
        if (__a[__lo] > __a[__hi]) __inv++;
        __pairs++;
    }
    const __density = __pairs ? __inv / __pairs : 0;
    if (__density < 0.02) return __ns_insertion_sort(__a);
    if (__ints && (__mx - __mn) <= 4 * __n + 4096) return __ns_counting_sort(__a);
    if (__ints && __n >= 500) return __ns_radix_sort_lsd(__a);
    // Branche ajoutée après une DÉFAITE ADVERSARIALE : sur valeurs non
    // entières, le repli « tri natif » perdait contre le tri fusion
    // (0,459 ms contre 0,311 ms mesurés). La validation adversariale a
    // trouvé la faiblesse, le dispatcher a été corrigé.
    if (!__ints) return __ns_merge_sort(__a);
    return __ns_native_timsort(__a);
}`;

/* ─── Recherche adversariale de performance ───────────────────────────── */

export interface AdversarialDataset {
    name: string;
    build: (n: number) => number[];
    /** Ce que ce jeu de données cherche à mettre en défaut. */
    targets: string;
}

/**
 * Familles de jeux de données conçues pour FAIRE PERDRE un algorithme donné.
 * Chacune attaque une hypothèse implicite : « les données sont denses »,
 * « elles sont presque triées », « elles tiennent en mémoire », etc.
 */
export const ADVERSARIAL_DATASETS: AdversarialDataset[] = [
    {
        name: 'étendue explosive',
        targets: 'tri par comptage (alloue O(étendue))',
        build: (n) => Array.from({ length: n }, (_, i) => i * 1000003)
    },
    {
        name: 'localement ordonné mais globalement désordonné',
        targets: 'tri par insertion et tout profileur fondé sur l\'ordre local',
        build: (n) => Array.from({ length: n }, (_, i) => (Math.imul(i, 48271) % 2147483647) % 1000000)
    },
    {
        name: 'inversé strict',
        targets: 'tri par insertion (pire cas O(n²))',
        build: (n) => Array.from({ length: n }, (_, i) => n - i)
    },
    {
        name: 'valeurs non entières',
        targets: 'tris par distribution (comptage, radix)',
        build: (n) => Array.from({ length: n }, (_, i) => ((Math.imul(i, 48271) % 2147483647) % 100000) / 7)
    },
    {
        name: 'quasi trié',
        targets: 'tris comparatifs génériques (ils ignorent l\'ordre existant)',
        build: (n) => { const a = Array.from({ length: n }, (_, i) => i); for (let k = 0; k + 1 < n; k += Math.max(1, n >> 5)) { const t = a[k]; a[k] = a[k + 1]; a[k + 1] = t; } return a; }
    },
    {
        name: 'une seule valeur répétée',
        targets: 'tris comparatifs (entropie nulle, aucun travail nécessaire)',
        build: (n) => new Array(n).fill(42)
    }
];
