import { Project, SyntaxKind, Node, SourceFile } from 'ts-morph';

/**
 * ═══ OPTIMISATION AU NIVEAU APPELANT ════════════════════════════════════
 *
 * Pourquoi cette classe de mutations existe.
 *
 * Mesure v39 : les règles visant des motifs naïfs ne s'appliquent à
 * pratiquement aucune fonction de bibliothèque (2 sur 499), parce que le code
 * de bibliothèque a déjà été optimisé par ses auteurs. Le gain applicatif réel
 * n'est pas DANS `orderBy` — il est dans le fait de l'appeler douze fois sur
 * des données inchangées.
 *
 * Étude de prévalence menée avant d'écrire la moindre règle (appels
 * strictement identiques répétés dans une même fonction, et appels dont tous
 * les arguments sont invariants dans une boucle) :
 *
 *   lodash        321 fn →  16 appels dupliqués,  10 invariants en boucle
 *   express        12 fn →   4 appels dupliqués,   0 invariant
 *   astring        11 fn →   1 appel dupliqué,     4 invariants
 *   acorn           8 fn →   0
 *   Neuralys/src  421 fn → 131 appels dupliqués,  86 invariants en boucle
 *
 * Le motif est environ dix fois plus dense dans du code applicatif que dans
 * du code de bibliothèque — y compris dans mon propre source, écrit sans
 * aucune intention de démontrer cette règle. C'est ce qui justifie la classe.
 *
 * CONDITION DE SÛRETÉ : un appel ne peut être hissé ou factorisé que si la
 * fonction appelée est PURE. La pureté n'est pas supposée ni déduite d'une
 * liste écrite à la main : elle est établie empiriquement par l'enregistreur
 * de charge (arguments comparés avant/après l'appel pour la non-mutation,
 * mêmes arguments → même résultat pour le déterminisme). Sans preuve
 * observée, la règle refuse de transformer.
 */

export interface PurityEvidence {
    /** Noms de fonctions observées pures pendant la charge enregistrée. */
    pure: Set<string>;
    /** Noms observés impurs — utile pour expliquer un refus. */
    impure: Set<string>;
}

export interface CallerMutation {
    strategy: 'hoist_invariant_call' | 'cse_pure_call';
    code: string;
    /** Appel concerné, pour l'explication. */
    callText: string;
    /** Nombre d'exécutions économisées par itération/occurrence. */
    savedOccurrences: number;
    rationale: string;
}

export interface DetectionSite {
    kind: 'hoist_invariant_call' | 'cse_pure_call';
    functionName: string;
    callText: string;
    occurrences: number;
    calleeName: string;
    purityKnown: boolean;
}

const PURE_BUILTINS = new Set([
    'Math.abs', 'Math.min', 'Math.max', 'Math.floor', 'Math.ceil', 'Math.round', 'Math.sqrt', 'Math.log2',
    'Object.keys', 'Object.values', 'Object.entries', 'Array.from', 'Array.isArray',
    'Number.isInteger', 'Number.isFinite', 'JSON.stringify', 'String.fromCharCode'
]);

/** Nom exploitable de la fonction appelée : `_.orderBy` → `orderBy`. */
export function calleeName(callText: string): string {
    const m = callText.match(/^([\w$.]+)\s*\(/);
    if (!m) return '';
    const parts = m[1].split('.');
    return parts[parts.length - 1];
}

function calleeFull(callText: string): string {
    const m = callText.match(/^([\w$.]+)\s*\(/);
    return m ? m[1] : '';
}

export class CallerOptimizer {
    private project = new Project({ useInMemoryFileSystem: true });

    constructor(private evidence: PurityEvidence = { pure: new Set(), impure: new Set() }) {}

    private isPure(callText: string): boolean {
        const full = calleeFull(callText);
        if (PURE_BUILTINS.has(full)) return true;
        const name = calleeName(callText);
        if (this.evidence.impure.has(name)) return false;
        return this.evidence.pure.has(name);
    }


    /**
     * Argument invariant : identifiant non réécrit, littéral, ou littéral
     * composite dont TOUS les éléments sont eux-mêmes des littéraux
     * (`['amount']`, `['desc']`). Ces expressions constantes sont
     * réallouées à chaque itération alors que leur valeur ne change pas —
     * c'est précisément le cas de `_.orderBy(rows, ['amount'], ['desc'])`.
     */
    private isConstantExpr(a: Node): boolean {
        if (Node.isStringLiteral(a) || Node.isNumericLiteral(a) || Node.isTrueLiteral(a) || Node.isFalseLiteral(a)) return true;
        if (Node.isArrayLiteralExpression(a)) return a.getElements().every(e => this.isConstantExpr(e));
        if (Node.isObjectLiteralExpression(a)) {
            return a.getProperties().every(pr => {
                const init = (pr as any).getInitializer?.();
                return !!init && this.isConstantExpr(init);
            });
        }
        return false;
    }

    private invariantArgs(args: Node[], scopeText: string): boolean {
        if (args.length === 0) return false;
        for (const a of args) {
            if (this.isConstantExpr(a)) continue;
            if (Node.isIdentifier(a) && !this.isWritten(a.getText(), scopeText)) continue;
            return false;
        }
        return true;
    }

    private uniqueName(sf: SourceFile, base: string): string {
        const used = new Set(sf.getDescendantsOfKind(SyntaxKind.Identifier).map(i => i.getText()));
        let i = 0, name = base;
        while (used.has(name)) name = `${base}_${i++}`;
        return name;
    }

    /** Un identifiant est-il écrit quelque part dans ce texte ? (conservateur) */
    private isWritten(id: string, text: string): boolean {
        return new RegExp(`\\b${id}\\s*(=[^=]|\\+\\+|--|\\+=|-=|\\*=|/=)`).test(text) ||
               new RegExp(`\\b${id}\\.(push|pop|shift|unshift|splice|sort|reverse|fill|set|delete|add|clear)\\s*\\(`).test(text);
    }

    /**
     * Détection seule (sans transformation) : sert à mesurer la prévalence
     * réelle sur un dépôt sans rien modifier.
     */
    public detect(code: string): DetectionSite[] {
        const sites: DetectionSite[] = [];
        let sf: SourceFile;
        try { sf = this.project.createSourceFile(`d_${Math.random().toString(36).slice(2)}.ts`, code, { overwrite: true }); }
        catch { return sites; }

        const containers: Node[] = [
            ...sf.getFunctions(),
            ...sf.getDescendantsOfKind(SyntaxKind.MethodDeclaration),
            ...sf.getDescendantsOfKind(SyntaxKind.ArrowFunction)
        ];
        for (const fn of containers) {
            const fnName = (fn as any).getName?.() || '(anonyme)';
            const fnText = fn.getText();

            // appels identiques répétés
            const byText = new Map<string, number>();
            for (const c of fn.getDescendantsOfKind(SyntaxKind.CallExpression)) {
                const t = c.getText().replace(/\s+/g, ' ').trim();
                if (t.length < 8 || t.length > 200) continue;
                byText.set(t, (byText.get(t) || 0) + 1);
            }
            for (const [t, n] of byText) {
                if (n < 2) continue;
                sites.push({ kind: 'cse_pure_call', functionName: fnName, callText: t, occurrences: n, calleeName: calleeName(t), purityKnown: this.isPure(t) });
            }

            // appels invariants dans une boucle
            for (const loop of [...fn.getDescendantsOfKind(SyntaxKind.ForStatement),
                                ...fn.getDescendantsOfKind(SyntaxKind.WhileStatement),
                                ...fn.getDescendantsOfKind(SyntaxKind.ForOfStatement)]) {
                const bodyText = (loop as any).getStatement?.()?.getText() ?? '';
                for (const c of loop.getDescendantsOfKind(SyntaxKind.CallExpression)) {
                    const t = c.getText().replace(/\s+/g, ' ').trim();
                    const args = c.getArguments();
                    if (t.length > 200) continue;
                    if (!this.invariantArgs(args, bodyText)) continue;
                    sites.push({ kind: 'hoist_invariant_call', functionName: fnName, callText: t, occurrences: 1, calleeName: calleeName(t), purityKnown: this.isPure(t) });
                }
            }
        }
        this.project.removeSourceFile(sf);
        return sites;
    }

    /**
     * Factorise les appels PURS strictement identiques d'une fonction :
     * l'appel est évalué une fois, le résultat réutilisé.
     */
    public applyCsePureCall(code: string): CallerMutation | null {
        let sf: SourceFile;
        try { sf = this.project.createSourceFile(`c_${Math.random().toString(36).slice(2)}.ts`, code, { overwrite: true }); }
        catch { return null; }

        for (const fn of sf.getFunctions()) {
            const body = fn.getBody();
            if (!body || !Node.isBlock(body)) continue;
            const fnText = fn.getText();

            const groups = new Map<string, Node[]>();
            for (const c of fn.getDescendantsOfKind(SyntaxKind.CallExpression)) {
                const t = c.getText().replace(/\s+/g, ' ').trim();
                if (t.length < 8 || t.length > 200) continue;
                (groups.get(t) || groups.set(t, []).get(t)!).push(c);
            }
            for (const [text, nodes] of groups) {
                if (nodes.length < 2 || !this.isPure(text)) continue;
                // aucun argument ne doit être réécrit dans la fonction
                const call = nodes[0].asKind(SyntaxKind.CallExpression)!;
                const idents = call.getArguments().filter(Node.isIdentifier).map(a => a.getText());
                if (idents.some(id => this.isWritten(id, fnText))) continue;
                // les occurrences doivent être des expressions, pas des cibles d'affectation
                const tmp = this.uniqueName(sf, `__cse_${calleeName(text)}`);
                const first = nodes[0];
                const stmt = first.getFirstAncestor(a => Node.isStatement(a) && Node.isBlock(a.getParent()!));
                if (!stmt) continue;
                for (const n of nodes) n.replaceWithText(tmp);
                stmt.replaceWithText(`const ${tmp} = ${text};\n    ${stmt.getText()}`);
                const out = sf.getFullText();
                this.project.removeSourceFile(sf);
                return {
                    strategy: 'cse_pure_call',
                    code: out,
                    callText: text,
                    savedOccurrences: nodes.length - 1,
                    rationale: `l'appel pur \`${text.slice(0, 60)}\` était évalué ${nodes.length} fois avec des arguments inchangés ; il l'est désormais une seule fois (pureté établie par observation de la charge réelle, pas supposée)`
                };
            }
        }
        this.project.removeSourceFile(sf);
        return null;
    }

    /** Hisse hors de la boucle un appel PUR dont tous les arguments sont invariants. */
    public applyHoistInvariantCall(code: string): CallerMutation | null {
        let sf: SourceFile;
        try { sf = this.project.createSourceFile(`h_${Math.random().toString(36).slice(2)}.ts`, code, { overwrite: true }); }
        catch { return null; }

        const loops = [
            ...sf.getDescendantsOfKind(SyntaxKind.ForStatement),
            ...sf.getDescendantsOfKind(SyntaxKind.WhileStatement),
            ...sf.getDescendantsOfKind(SyntaxKind.ForOfStatement)
        ];
        for (const loop of loops) {
            const bodyText = (loop as any).getStatement?.()?.getText() ?? '';
            for (const c of loop.getDescendantsOfKind(SyntaxKind.CallExpression)) {
                const text = c.getText().replace(/\s+/g, ' ').trim();
                if (text.length > 200 || !this.isPure(text)) continue;
                const args = c.getArguments();
                if (!this.invariantArgs(args, bodyText)) continue;
                const idents = args.filter(Node.isIdentifier).map(a => a.getText());
                // l'argument ne doit pas être la variable de boucle
                const loopVars = loop.getDescendantsOfKind(SyntaxKind.VariableDeclaration).map(v => v.getName());
                if (idents.some(id => loopVars.includes(id))) continue;

                const tmp = this.uniqueName(sf, `__hoisted_${calleeName(text)}`);
                c.replaceWithText(tmp);
                loop.replaceWithText(`{\n    const ${tmp} = ${text};\n    ${loop.getText()}\n}`);
                const out = sf.getFullText();
                this.project.removeSourceFile(sf);
                return {
                    strategy: 'hoist_invariant_call',
                    code: out,
                    callText: text,
                    savedOccurrences: -1,
                    rationale: `l'appel pur \`${text.slice(0, 60)}\` était réévalué à chaque itération alors que ses arguments ne changent pas dans la boucle ; il est hissé avant la boucle`
                };
            }
        }
        this.project.removeSourceFile(sf);
        return null;
    }

    public mutate(code: string): CallerMutation[] {
        const out: CallerMutation[] = [];
        const a = this.applyHoistInvariantCall(code);
        if (a) out.push(a);
        const b = this.applyCsePureCall(code);
        if (b) out.push(b);
        return out;
    }
}
