import { Project, SyntaxKind } from 'ts-morph';
import * as crypto from 'crypto';

/**
 * Semantic canonicalizer: detects trivially-equivalent variants BEFORE
 * benchmarking, so redundant measurements are never launched.
 * Normalization = alpha-renaming of all local identifiers (declaration
 * order) + whitespace/comment erasure. Two variants with the same
 * canonical hash are alpha-equivalent programs: same computation modulo
 * naming and layout — one benchmark result serves both.
 * This is a sound (never merges non-equivalent code) but incomplete
 * equivalence check; full semantic equivalence stays with the fuzzing
 * oracle downstream.
 */
export class Canonicalizer {
    private project = new Project({ useInMemoryFileSystem: true });

    public canonicalize(code: string): string {
        try {
            const file = this.project.createSourceFile('c.ts', code, { overwrite: true });
            const renames = new Map<string, string>();
            let counter = 0;

            // Collect local declarations in source order
            file.forEachDescendant(node => {
                if (node.getKind() === SyntaxKind.VariableDeclaration ||
                    node.getKind() === SyntaxKind.Parameter) {
                    const nameNode = (node as any).getNameNode?.();
                    if (nameNode && nameNode.getKind() === SyntaxKind.Identifier) {
                        const name = nameNode.getText();
                        if (!renames.has(name)) renames.set(name, `_v${counter++}`);
                    }
                }
            });

            let out = file.getFullText();
            // Apply alpha-renaming (longest names first to avoid prefix collisions)
            const ordered = [...renames.entries()].sort((a, b) => b[0].length - a[0].length);
            for (const [from, to] of ordered) {
                out = out.replace(new RegExp(`\\b${from.replace(/[$]/g, '\\$&')}\\b`, 'g'), to);
            }
            // Erase layout
            return out.replace(/\/\/[^\n]*|\/\*[\s\S]*?\*\//g, '').replace(/\s+/g, ' ').trim();
        } catch {
            return code.replace(/\s+/g, ' ').trim();
        }
    }

    public canonicalHash(code: string): string {
        return crypto.createHash('sha256').update(this.canonicalize(code)).digest('hex').slice(0, 16);
    }
}

/**
 * Structural code signature for cross-function genetic memory.
 * Functions sharing a signature share optimization opportunities, so
 * KB priors learned on one function transfer to structurally-similar
 * new functions the system has never seen.
 */
export function codeSignature(code: string): string {
    const flags: string[] = [];
    if (/for\s*\([^)]*\)\s*\{[^}]*for\s*\(/s.test(code)) flags.push('nested_loops');
    else if (/\bfor\s*\(|\bwhile\s*\(/.test(code)) flags.push('loop');
    if (/\w+\s*\+=\s*[^;]*['"`]|['"`][^;]*\+=/.test(code) || /let\s+\w+\s*=\s*''/.test(code)) flags.push('string_accum');
    if (/\.shift\(\)/.test(code)) flags.push('queue_shift');
    if (/\.indexOf\(/.test(code)) flags.push('membership_scan');
    if (/\.length/.test(code)) flags.push('length_access');
    if (/\w+\[\w+\]\s*>\s*\w+\[\w+\s*\+\s*1\]/.test(code)) flags.push('adjacent_compare');
    if (/\.push\(/.test(code)) flags.push('array_build');
    if (/\w+\[\w+([+\-*]\w+)?\]\s*[*+]/.test(code)) flags.push('indexed_arith');
    return flags.sort().join('|') || 'plain';
}
