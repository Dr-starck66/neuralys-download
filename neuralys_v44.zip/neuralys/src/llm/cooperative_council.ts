import { ClaudeMutator } from './claude_mutator';
import { MultiAgentMutator } from './llm_providers';

export interface CouncilProposal {
    role: string;
    provider: string;
    code: string;
    critique?: string;
    votes?: number;
}

const ROLES = [
    { role: 'performance_expert', focus: 'algorithmic complexity: replace O(n^2) patterns, use closed forms, better data structures' },
    { role: 'memory_expert', focus: 'allocation pressure: avoid intermediate arrays/strings, reuse buffers, reduce copies' },
    { role: 'compiler_expert', focus: 'JIT-friendliness: monomorphic shapes, avoid deopt triggers, hoist invariants' }
];

/**
 * Cooperative multi-LLM council (spec point 6). Flow:
 *   1. PROPOSE  - each role prompts every available provider for a
 *                 role-focused rewrite
 *   2. CRITIQUE - a critic model reviews each proposal for semantic risk
 *   3. VOTE     - a scorer ranks proposals; weighted votes select the
 *                 shortlist forwarded to the pipeline
 *   4. JUDGE    - the benchmark + fuzzing gate remain the ONLY final
 *                 arbiter; council output is candidates, never verdicts
 * Degrades to empty output (never fake proposals) when no LLM is available.
 */
export class CooperativeCouncil {
    private claude = new ClaudeMutator();
    private ensemble = new MultiAgentMutator();

    public async convene(code: string, maxShortlist: number = 3): Promise<CouncilProposal[]> {
        // 1. PROPOSE - role-focused prompts across the ensemble
        const proposals: CouncilProposal[] = [];
        for (const r of ROLES) {
            const rolePrompt = `You are a ${r.role.replace('_', ' ')}. Focus exclusively on: ${r.focus}.
Rewrite this TypeScript to run faster with identical observable behavior for any input. Keep the function name and signature.
Return ONLY valid TypeScript, no markdown, no comments.

${code}`;
            const out = await this.claude.mutateRaw(rolePrompt, 0);
            if (out && out.includes('function') && out !== code) {
                proposals.push({ role: r.role, provider: 'claude', code: out.replace(/```(ts|typescript|js|javascript)?\n?|```/g, '').trim() });
            }
            const others = await this.ensemble.proposeAll(code);
            for (const o of others.filter(o => o.provider !== 'claude')) {
                proposals.push({ role: r.role, provider: o.provider, code: o.code });
            }
        }
        if (proposals.length === 0) return [];

        // 2. CRITIQUE + 3. VOTE in one scoring pass per proposal
        for (const p of proposals) {
            const review = await this.claude.mutateRaw(
`You are a strict code reviewer. Rate this refactoring proposal for (a) semantic-equivalence risk and (b) expected speedup.
Reply with EXACTLY one line: SCORE:<0-10> RISK:<low|medium|high> <one-sentence critique>

Original:
${code}

Proposal:
${p.code}`, 0);
            if (review) {
                const m = review.match(/SCORE:\s*(\d+)/i);
                const risk = /RISK:\s*high/i.test(review) ? 0.3 : /RISK:\s*medium/i.test(review) ? 0.7 : 1.0;
                p.votes = m ? parseInt(m[1], 10) * risk : 0;
                p.critique = review.replace(/^.*?(SCORE:[^\n]*)/is, '$1').slice(0, 200);
            } else {
                p.votes = 5; // no critic available: neutral weight, benchmark decides
            }
        }

        // 4. Shortlist by weighted vote; benchmark downstream is final judge
        return proposals.sort((a, b) => (b.votes || 0) - (a.votes || 0)).slice(0, maxShortlist);
    }
}
