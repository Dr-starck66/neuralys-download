import Anthropic from '@anthropic-ai/sdk';

export type ClaudeAuthMode = 'subscription_agent_sdk' | 'api_key' | 'unavailable';

/**
 * Claude-powered architectural mutator.
 * Auth cascade:
 * 1. Claude Agent SDK — bills against the user's subscription Agent SDK
 *    monthly credit (Pro/Max/Team/Enterprise, since 2026-06-15). Requires
 *    a machine where `claude` CLI is authenticated (claude setup-token /
 *    claude login). No API key, no per-token billing.
 * 2. ANTHROPIC_API_KEY — direct Messages API, pay-as-you-go (only if the
 *    user explicitly sets it).
 * 3. unavailable — caller falls back to the symbolic engine.
 */
export class ClaudeMutator {
    private mode: ClaudeAuthMode = 'unavailable';
    private apiClient: Anthropic | null = null;
    private agentQuery: ((opts: any) => AsyncIterable<any>) | null = null;
    private initPromise: Promise<void>;

    constructor() {
        this.initPromise = this.init();
    }

    private async init(): Promise<void> {
        // Preferred: subscription-billed Agent SDK
        try {
            const sdk = await import('@anthropic-ai/claude-agent-sdk');
            if (typeof (sdk as any).query === 'function') {
                this.agentQuery = (sdk as any).query;
                this.mode = 'subscription_agent_sdk';
                return;
            }
        } catch { /* SDK not installed or CLI not present */ }

        // Explicit opt-in: pay-as-you-go API key
        if (process.env.ANTHROPIC_API_KEY) {
            this.apiClient = new Anthropic();
            this.mode = 'api_key';
        }
    }

    public async getMode(): Promise<ClaudeAuthMode> {
        await this.initPromise;
        return this.mode;
    }

    private buildPrompt(code: string): string {
        return `You are a high-performance compiler engineer.
Refactor the following TypeScript code to execute faster without changing its observable behavior for any input.
Apply algorithmic changes when possible (e.g. O(N^2) -> O(N log N) or O(N), closed-form formulas for arithmetic series).
Keep the same function name and signature.
Return ONLY valid TypeScript code, no markdown fences, no explanations.

Code:
${code}`;
    }

    private extractCode(text: string): string | null {
        const out = text.replace(/```(typescript|ts|javascript|js)?\n?|```\n?/g, '').trim();
        return out.length > 10 && out.includes('function') ? out : null;
    }

    /**
     * Raw single-turn completion (used by the prompt lab). Same auth
     * cascade and degradation semantics as mutate().
     */
    public async mutateRaw(fullPrompt: string, retries: number = 1): Promise<string | null> {
        return this.complete(fullPrompt, retries, false);
    }

    /**
     * Returns mutated code or null. Never throws: any auth/runtime failure
     * degrades to null so the caller's symbolic fallback takes over.
     */
    public async mutate(code: string, retries: number = 2): Promise<string | null> {
        return this.complete(this.buildPrompt(code), retries, true);
    }

    private async complete(prompt: string, retries: number, expectCode: boolean): Promise<string | null> {
        await this.initPromise;
        if (this.mode === 'unavailable') return null;

        for (let attempt = 0; attempt <= retries; attempt++) {
            try {
                if (this.mode === 'subscription_agent_sdk' && this.agentQuery) {
                    let text = '';
                    const stream = this.agentQuery({
                        prompt,
                        options: {
                            maxTurns: 1,
                            allowedTools: [] // pure generation, no tool use, default permissions
                        }
                    });
                    for await (const message of stream) {
                        if (message.type === 'assistant' && message.message?.content) {
                            for (const block of message.message.content) {
                                if (block.type === 'text') text += block.text;
                            }
                        }
                        if (message.type === 'result' && message.subtype !== 'success') {
                            throw new Error(`Agent SDK result: ${message.subtype}`);
                        }
                    }
                    const extracted = expectCode ? this.extractCode(text) : (text.trim() || null);
                    if (extracted) return extracted;
                }

                if (this.mode === 'api_key' && this.apiClient) {
                    const response = await this.apiClient.messages.create({
                        model: 'claude-sonnet-4-6',
                        max_tokens: 4000,
                        messages: [{ role: 'user', content: prompt }]
                    });
                    const text = response.content
                        .filter((b: any) => b.type === 'text')
                        .map((b: any) => b.text)
                        .join('');
                    const extracted = expectCode ? this.extractCode(text) : (text.trim() || null);
                    if (extracted) return extracted;
                }
            } catch (e: any) {
                // Auth errors are permanent for this process: disable and bail
                if (/not logged in|authentication|unauthorized|401/i.test(e.message || '')) {
                    console.warn(`[ClaudeMutator] ${this.mode} unavailable (${e.message}). Falling back to symbolic engine for this session. Run 'claude login' or 'claude setup-token' to enable subscription-billed mutations.`);
                    this.mode = 'unavailable';
                    return null;
                }
                if (attempt === retries) {
                    console.warn(`[ClaudeMutator] ${this.mode} failed after ${retries + 1} attempts: ${e.message}`);
                    return null;
                }
                await new Promise(r => setTimeout(r, 500 * (attempt + 1)));
            }
        }
        return null;
    }
}
