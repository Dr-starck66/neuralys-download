import { ClaudeMutator } from './claude_mutator';

export interface LLMProvider {
    name: string;
    available(): boolean;
    mutate(code: string): Promise<string | null>;
}

const PROMPT = (code: string) => `You are a high-performance compiler engineer.
Refactor the following TypeScript code to execute faster without changing its observable behavior for any input.
Apply algorithmic changes when possible (closed forms, better complexity classes).
Keep the same function name and signature.
Return ONLY valid TypeScript code, no markdown fences, no explanations.

Code:
${code}`;

function extractCode(text: string): string | null {
    const out = text.replace(/```(typescript|ts|javascript|js)?\n?|```\n?/g, '').trim();
    return out.length > 10 && out.includes('function') ? out : null;
}

/**
 * Generic adapter for OpenAI-compatible chat completion APIs.
 * Covers OpenAI, DeepSeek, Qwen (DashScope) and any compatible endpoint.
 */
class OpenAICompatibleProvider implements LLMProvider {
    constructor(
        public name: string,
        private baseUrl: string,
        private model: string,
        private keyEnv: string
    ) {}

    available(): boolean {
        return !!process.env[this.keyEnv];
    }

    async mutate(code: string): Promise<string | null> {
        try {
            const resp = await fetch(`${this.baseUrl}/chat/completions`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${process.env[this.keyEnv]}`
                },
                body: JSON.stringify({
                    model: this.model,
                    max_tokens: 4000,
                    messages: [{ role: 'user', content: PROMPT(code) }]
                })
            });
            if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
            const data: any = await resp.json();
            return extractCode(data.choices?.[0]?.message?.content || '');
        } catch (e: any) {
            console.warn(`[${this.name}] mutation failed: ${e.message}`);
            return null;
        }
    }
}

class GeminiProvider implements LLMProvider {
    name = 'gemini';
    available(): boolean { return !!process.env.GEMINI_API_KEY; }
    async mutate(code: string): Promise<string | null> {
        try {
            const resp = await fetch(
                `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-pro:generateContent?key=${process.env.GEMINI_API_KEY}`,
                {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ contents: [{ parts: [{ text: PROMPT(code) }] }] })
                }
            );
            if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
            const data: any = await resp.json();
            return extractCode(data.candidates?.[0]?.content?.parts?.[0]?.text || '');
        } catch (e: any) {
            console.warn(`[gemini] mutation failed: ${e.message}`);
            return null;
        }
    }
}

class ClaudeProvider implements LLMProvider {
    name = 'claude';
    private inner = new ClaudeMutator();
    available(): boolean { return true; } // resolves at call time (subscription or key)
    async mutate(code: string): Promise<string | null> { return this.inner.mutate(code); }
}

/**
 * Multi-agent LLM mutator (ensemble). Each configured provider proposes
 * its own mutation in parallel; every proposal is independently validated
 * downstream (fuzzing + benchmark). The KB records the provider per
 * mutation (strategy = llm:<provider>), so the UCB1 bandit learns which
 * model produces the best mutations for which code signatures.
 *
 * Configuration (all optional, graceful degradation):
 *   Claude   -> subscription Agent SDK credit or ANTHROPIC_API_KEY
 *   OpenAI   -> OPENAI_API_KEY
 *   Gemini   -> GEMINI_API_KEY
 *   DeepSeek -> DEEPSEEK_API_KEY
 *   Qwen     -> DASHSCOPE_API_KEY
 */
export class MultiAgentMutator {
    private providers: LLMProvider[] = [
        new ClaudeProvider(),
        new OpenAICompatibleProvider('openai', 'https://api.openai.com/v1', 'gpt-5.2', 'OPENAI_API_KEY'),
        new GeminiProvider(),
        new OpenAICompatibleProvider('deepseek', 'https://api.deepseek.com/v1', 'deepseek-reasoner', 'DEEPSEEK_API_KEY'),
        new OpenAICompatibleProvider('qwen', 'https://dashscope-intl.aliyuncs.com/compatible-mode/v1', 'qwen3-coder-plus', 'DASHSCOPE_API_KEY')
    ];

    public availableProviders(): string[] {
        return this.providers.filter(p => p.available()).map(p => p.name);
    }

    public async proposeAll(code: string): Promise<{ provider: string; code: string }[]> {
        const active = this.providers.filter(p => p.available());
        const proposals = await Promise.all(
            active.map(async p => ({ provider: p.name, code: await p.mutate(code) }))
        );
        return proposals.filter((p): p is { provider: string; code: string } => !!p.code && p.code !== code);
    }
}
