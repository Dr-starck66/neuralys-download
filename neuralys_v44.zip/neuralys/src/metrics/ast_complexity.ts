import * as ts from 'typescript';

export interface ASTMetrics {
    nodeCount: number;
    cyclomaticComplexity: number;
    functionCount: number;
    loc: number;
}

export function computeASTMetrics(code: string): ASTMetrics {
    const sourceFile = ts.createSourceFile(
        'temp.ts',
        code,
        ts.ScriptTarget.Latest,
        true
    );

    let nodeCount = 0;
    let cyclomaticComplexity = 1; // Base complexity is 1
    let functionCount = 0;
    
    // Simple LOC calculation (ignoring empty lines)
    const loc = code.split('\n').filter(line => line.trim().length > 0).length;

    function visit(node: ts.Node) {
        nodeCount++;

        switch (node.kind) {
            case ts.SyntaxKind.FunctionDeclaration:
            case ts.SyntaxKind.FunctionExpression:
            case ts.SyntaxKind.ArrowFunction:
            case ts.SyntaxKind.MethodDeclaration:
                functionCount++;
                break;
                
            case ts.SyntaxKind.IfStatement:
            case ts.SyntaxKind.ForStatement:
            case ts.SyntaxKind.ForInStatement:
            case ts.SyntaxKind.ForOfStatement:
            case ts.SyntaxKind.WhileStatement:
            case ts.SyntaxKind.DoStatement:
            case ts.SyntaxKind.CatchClause:
            case ts.SyntaxKind.ConditionalExpression:
            case ts.SyntaxKind.CaseClause:
                cyclomaticComplexity++;
                break;
            case ts.SyntaxKind.BinaryExpression:
                const binNode = node as ts.BinaryExpression;
                if (
                    binNode.operatorToken.kind === ts.SyntaxKind.AmpersandAmpersandToken ||
                    binNode.operatorToken.kind === ts.SyntaxKind.BarBarToken ||
                    binNode.operatorToken.kind === ts.SyntaxKind.QuestionQuestionToken
                ) {
                    cyclomaticComplexity++;
                }
                break;
        }

        ts.forEachChild(node, visit);
    }

    visit(sourceFile);

    return {
        nodeCount,
        cyclomaticComplexity,
        functionCount,
        loc
    };
}
