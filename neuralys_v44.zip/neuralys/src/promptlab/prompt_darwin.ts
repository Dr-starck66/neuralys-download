import { PromptMutator, PROMPT_STRATEGIES } from './prompt_mutator';
import { EvalRunner } from './eval_runner';
import { EvalDataset, PromptVariant } from './types';
import { KnowledgeBase } from '../memory/knowledge_base';
import { MetaPolicySelector } from '../core/selection_policies';
import { NSGA2, Candidate } from '../algorithms/nsga2';
import * as crypto from 'crypto';

export interface PromptExperimentResult {
    seed: PromptVariant;
    champion: PromptVariant;
    paretoFront: PromptVariant[];
    generations: { generation: number; bestQuality: number; bestCostUsdPer1k: number; tried: number }[];
    savingsPct: number;
    qualityDelta: number;
}

/**
 * Darwinian prompt optimization - same selection machinery as the code
 * engine (UCB1 + NSGA-II + persistent genetic memory), different genome.
 * Objectives (minimized): [1 - quality, costUsdPer1k, latencyMeanMs].
 * Anti-Goodhart: fitness runs on the train split only; the holdout split
 * is measured once on the final Pareto front and reported side by side.
 */
export class PromptDarwin {
    private mutator = new PromptMutator();

    constructor(private kb: KnowledgeBase, private runner: EvalRunner = new EvalRunner()) {}

    private signature(dataset: EvalDataset): string {
        return `prompt|${dataset.scorer}|n${dataset.train.length}`;
    }

    public async evolve(seedPrompt: string, dataset: EvalDataset, opts: { generations?: number; populationCap?: number } = {}): Promise<PromptExperimentResult> {
        const generations = opts.generations ?? 3;
        const cap = opts.populationCap ?? 6;
        const experimentId = `promptexp-${Date.now()}`;
        const signature = this.signature(dataset);
        this.kb.startExperiment(experimentId, dataset.name);

        const arms = PROMPT_STRATEGIES.map(s => s.name);
        const bandit = new MetaPolicySelector(this.kb, arms, 'PromptOptimization', signature);

        const seedMetrics = await this.runner.measure(seedPrompt, dataset);
        const seed: PromptVariant = { id: 'seed', prompt: seedPrompt, strategyLineage: [], metrics: seedMetrics };
        let population: PromptVariant[] = [seed];
        const tried = new Set<string>([seedPrompt]);
        const genReports: PromptExperimentResult['generations'] = [];

        for (let gen = 1; gen <= generations; gen++) {
            let triedCount = 0;
            const offspring: PromptVariant[] = [];
            bandit.beginGeneration();
            const ordered = bandit.rankArms().map(a => a.strategy);

            for (const parent of population.slice(0, 3)) {
                let produced = 0;
                for (const strategy of ordered) {
                    if (produced >= 2) break;
                    const mutated = await this.mutator.apply(strategy, parent.prompt, dataset);
                    if (!mutated || tried.has(mutated)) continue;
                    tried.add(mutated);
                    produced++; triedCount++;

                    const metrics = await this.runner.measure(mutated, dataset);
                    const variant: PromptVariant = {
                        id: `${parent.id}>${strategy}`, prompt: mutated,
                        strategyLineage: [...parent.strategyLineage, strategy], metrics
                    };
                    const better = metrics.quality > parent.metrics.quality ||
                        (metrics.quality >= parent.metrics.quality && metrics.costUsdPer1k < parent.metrics.costUsdPer1k);
                    const qualityDrop = metrics.quality < parent.metrics.quality - 0.1;

                    if (!qualityDrop) offspring.push(variant);
                    bandit.update(strategy, better, (parent.metrics.costUsdPer1k - metrics.costUsdPer1k) / Math.max(parent.metrics.costUsdPer1k, 1e-9) * 100);
                    this.kb.recordMutation({
                        experimentId, generation: gen, benchmarkId: dataset.name, category: 'PromptOptimization',
                        parentHash: KnowledgeBase.hashCode(parent.prompt),
                        variantHash: this.kb.storeArtifact(mutated),
                        strategy, accepted: better, rejectionReason: qualityDrop ? 'quality_regression' : null,
                        latencyMean: metrics.latencyMeanMs,
                        latencyImprovementPct: (parent.metrics.costUsdPer1k - metrics.costUsdPer1k) / Math.max(parent.metrics.costUsdPer1k, 1e-9) * 100,
                        memoryMb: null, complexity: metrics.promptTokens, pValue: null,
                        reasoning: PROMPT_STRATEGIES.find(s => s.name === strategy)?.describe || strategy,
                        signature
                    });
                }
            }

            population = this.select([...population, ...offspring], cap);
            const best = population.reduce((a, b) => b.metrics.quality > a.metrics.quality ||
                (b.metrics.quality === a.metrics.quality && b.metrics.costUsdPer1k < a.metrics.costUsdPer1k) ? b : a);
            genReports.push({ generation: gen, bestQuality: best.metrics.quality, bestCostUsdPer1k: best.metrics.costUsdPer1k, tried: triedCount });
        }

        // Holdout pass on final front only (anti-Goodhart)
        const front = this.paretoFront(population);
        for (const v of front) {
            v.metrics.holdoutQuality = await this.runner.measureHoldout(v.prompt, dataset);
        }
        const champion = front.reduce((a, b) => {
            const qa = a.metrics.holdoutQuality >= 0 ? a.metrics.holdoutQuality : a.metrics.quality;
            const qb = b.metrics.holdoutQuality >= 0 ? b.metrics.holdoutQuality : b.metrics.quality;
            return qb > qa || (qb === qa && b.metrics.costUsdPer1k < a.metrics.costUsdPer1k) ? b : a;
        });

        this.kb.finishExperiment(experimentId, generations);
        return {
            seed, champion, paretoFront: front, generations: genReports,
            savingsPct: (seed.metrics.costUsdPer1k - champion.metrics.costUsdPer1k) / Math.max(seed.metrics.costUsdPer1k, 1e-9) * 100,
            qualityDelta: champion.metrics.quality - seed.metrics.quality
        };
    }

    private toCandidates(pop: PromptVariant[]): Candidate[] {
        return pop.map((v, i) => ({
            id: String(i), branchName: v.id,
            objectives: [1 - v.metrics.quality, v.metrics.costUsdPer1k, v.metrics.latencyMeanMs],
            dominationCount: 0, dominatedSolutions: [], rank: -1, crowdingDistance: 0
        }));
    }

    private select(pop: PromptVariant[], cap: number): PromptVariant[] {
        const fronts = NSGA2.fastNonDominatedSort(this.toCandidates(pop));
        for (const f of fronts) NSGA2.assignCrowdingDistance(f);
        const out: PromptVariant[] = [];
        for (const front of fronts) {
            for (const c of [...front].sort((a, b) => b.crowdingDistance - a.crowdingDistance)) {
                if (out.length >= cap) return out;
                out.push(pop[Number(c.id)]);
            }
        }
        return out;
    }

    private paretoFront(pop: PromptVariant[]): PromptVariant[] {
        const fronts = NSGA2.fastNonDominatedSort(this.toCandidates(pop));
        return fronts[0].map(c => pop[Number(c.id)]);
    }
}
