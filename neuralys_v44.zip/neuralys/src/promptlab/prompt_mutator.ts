import { ClaudeMutator } from '../llm/claude_mutator';
import { EvalDataset } from './types';

export interface PromptMutationStrategy {
    name: string;
    kind: 'symbolic' | 'llm';
    describe: string;
}

export const PROMPT_STRATEGIES: PromptMutationStrategy[] = [
    { name: 'compress', kind: 'llm', describe: 'Réécrit le prompt au minimum de tokens sans perdre d\'instruction.' },
    { name: 'add_structure', kind: 'llm', describe: 'Impose une structure explicite (étapes, contraintes de format de sortie).' },
    { name: 'chain_of_thought', kind: 'llm', describe: 'Ajoute un raisonnement pas-à-pas avant la réponse finale.' },
    { name: 'strict_format', kind: 'llm', describe: 'Verrouille le format de sortie exact attendu par le scorer.' },
    { name: 'inject_fewshot', kind: 'symbolic', describe: 'Insère 2 exemples résolus tirés du train set.' },
    { name: 'strip_filler', kind: 'symbolic', describe: 'Supprime les mots de politesse/remplissage sans valeur instructionnelle.' }
];

const META = (strategy: string, instruction: string, prompt: string) => `You are a prompt engineering expert.
Rewrite the following prompt template. Objective: ${instruction}
Constraints:
- Preserve the {{input}} placeholder exactly.
- Preserve the task semantics: same expected outputs for the same inputs.
- Return ONLY the rewritten prompt template, no commentary, no markdown fences.

Prompt:
${prompt}`;

/**
 * Prompt variation engine. LLM rewrites go through the same subscription-
 * billed Claude path as code mutations; symbolic strategies work offline.
 * Every proposal is re-validated empirically by the eval runner - a bad
 * rewrite simply loses on the fitness landscape.
 */
export class PromptMutator {
    private claude = new ClaudeMutator();

    public async apply(strategyName: string, prompt: string, dataset: EvalDataset): Promise<string | null> {
        const strat = PROMPT_STRATEGIES.find(s => s.name === strategyName);
        if (!strat) return null;

        if (strat.kind === 'symbolic') {
            if (strategyName === 'inject_fewshot') {
                if (prompt.includes('Example 1:')) return null;
                const shots = dataset.train.slice(0, 2)
                    .map((e, i) => `Example ${i + 1}:\nInput: ${e.input}\nOutput: ${e.expected}`)
                    .join('\n\n');
                return `${shots}\n\n${prompt}`;
            }
            if (strategyName === 'strip_filler') {
                const out = prompt
                    .replace(/\b(please|kindly|s'il te plaît|merci de|veuillez|I would like you to|could you|pourrais-tu)\b/gi, '')
                    .replace(/[ \t]{2,}/g, ' ')
                    .replace(/\n{3,}/g, '\n\n')
                    .trim();
                return out !== prompt ? out : null;
            }
            return null;
        }

        const rewritten = await this.claude.mutateRaw(META(strategyName, strat.describe, prompt));
        if (!rewritten || !rewritten.includes('{{input}}') || rewritten === prompt) return null;
        return rewritten;
    }
}
