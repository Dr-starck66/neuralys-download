import { ClaudeMutator } from '../llm/claude_mutator';
import { EvalDataset, EvalExample, PromptMetrics, DEFAULT_PRICING, estimateTokens } from './types';

/**
 * Empirical fitness for prompts. Runs the prompt template against the
 * dataset via the subscription-billed Claude path, scores each output,
 * and derives the three commercial objectives: quality, $ cost, latency.
 * No mocking: if no LLM auth is available, run() throws - the prompt lab
 * cannot produce fake fitness.
 */
export class EvalRunner {
    private claude = new ClaudeMutator();

    constructor(private model: string = 'claude-sonnet-4-6', private concurrency: number = 3) {}

    private score(output: string, expected: string, scorer: EvalDataset['scorer']): number {
        const norm = (s: string) => s.trim().toLowerCase().replace(/\s+/g, ' ');
        switch (scorer) {
            case 'exact_match': return norm(output) === norm(expected) ? 1 : 0;
            case 'contains': return norm(output).includes(norm(expected)) ? 1 : 0;
            case 'regex': try { return new RegExp(expected, 'i').test(output) ? 1 : 0; } catch { return 0; }
            case 'numeric': {
                const a = parseFloat(output.replace(/[^\d.\-]/g, ''));
                const b = parseFloat(expected);
                return Number.isFinite(a) && Math.abs(a - b) < 1e-6 ? 1 : 0;
            }
        }
    }

    private async runOne(prompt: string, ex: EvalExample, scorer: EvalDataset['scorer']) {
        const filled = prompt.split('{{input}}').join(ex.input);
        const t0 = Date.now();
        const output = await this.claude.mutateRaw(filled, 0);
        const latency = Date.now() - t0;
        if (output === null) throw new Error('LLM unavailable: eval cannot run without a completion backend (claude login / ANTHROPIC_API_KEY).');
        return {
            score: this.score(output, ex.expected, scorer),
            latency,
            inTok: estimateTokens(filled),
            outTok: estimateTokens(output)
        };
    }

    public async run(prompt: string, examples: EvalExample[], scorer: EvalDataset['scorer']) {
        const results: { score: number; latency: number; inTok: number; outTok: number }[] = [];
        for (let i = 0; i < examples.length; i += this.concurrency) {
            const batch = examples.slice(i, i + this.concurrency);
            results.push(...await Promise.all(batch.map(ex => this.runOne(prompt, ex, scorer))));
        }
        const pricing = DEFAULT_PRICING[this.model] || DEFAULT_PRICING['claude-sonnet-4-6'];
        const meanIn = results.reduce((a, r) => a + r.inTok, 0) / results.length;
        const meanOut = results.reduce((a, r) => a + r.outTok, 0) / results.length;
        return {
            quality: results.reduce((a, r) => a + r.score, 0) / results.length,
            latencyMeanMs: results.reduce((a, r) => a + r.latency, 0) / results.length,
            costUsdPer1k: 1000 * (meanIn * pricing.inputPerMTok + meanOut * pricing.outputPerMTok) / 1e6
        };
    }

    public async measure(prompt: string, dataset: EvalDataset): Promise<PromptMetrics> {
        const train = await this.run(prompt, dataset.train, dataset.scorer);
        return {
            quality: train.quality,
            holdoutQuality: -1, // measured lazily for survivors only
            costUsdPer1k: train.costUsdPer1k,
            latencyMeanMs: train.latencyMeanMs,
            promptTokens: estimateTokens(prompt)
        };
    }

    public async measureHoldout(prompt: string, dataset: EvalDataset): Promise<number> {
        if (dataset.holdout.length === 0) return -1;
        return (await this.run(prompt, dataset.holdout, dataset.scorer)).quality;
    }
}
