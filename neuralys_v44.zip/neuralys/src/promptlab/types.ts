export interface EvalExample {
    input: string;
    expected: string;
}

export interface EvalDataset {
    name: string;
    scorer: 'exact_match' | 'contains' | 'regex' | 'numeric';
    train: EvalExample[];   // used for evolution fitness + few-shot injection
    holdout: EvalExample[]; // never seen by the loop; final anti-Goodhart report
}

export interface PromptMetrics {
    quality: number;        // 0..1 on train
    holdoutQuality: number; // 0..1, measured once for survivors
    costUsdPer1k: number;   // estimated $ per 1000 calls
    latencyMeanMs: number;
    promptTokens: number;
}

export interface PromptVariant {
    id: string;
    prompt: string;
    strategyLineage: string[];
    metrics: PromptMetrics;
}

export interface ModelPricing {
    inputPerMTok: number;
    outputPerMTok: number;
}

// Estimated pricing table (USD / million tokens) - override via config
export const DEFAULT_PRICING: Record<string, ModelPricing> = {
    'claude-sonnet-4-6': { inputPerMTok: 3, outputPerMTok: 15 },
    'claude-haiku-4-5-20251001': { inputPerMTok: 1, outputPerMTok: 5 }
};

export const estimateTokens = (text: string) => Math.ceil(text.length / 4);
