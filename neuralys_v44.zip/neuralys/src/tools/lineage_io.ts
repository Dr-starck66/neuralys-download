import { KnowledgeBase } from '../memory/knowledge_base';
import { DarwinDriver } from '../core/engine';
import { ASTMutator } from '../core/ast_mutator';
import { SandboxRunner } from '../validation/sandbox_runner';
import { AdvancedSemanticGuardian } from '../validation/semantic_guardian';

export interface LineageBundle {
    version: 1;
    rootHash: string;
    artifacts: Record<string, string>; // hash -> code
    edges: { parent: string; child: string; strategy: string; accepted: boolean; depth: number }[];
}

/**
 * Lineage portability + replay (spec: export/import/partage/replay).
 * Export: self-contained JSON bundle (all code artifacts + genetic edges).
 * Import: merges into the local KB (content-addressed, idempotent).
 * Replay: re-applies the recorded winning strategy sequence to the root
 * seed and RE-MEASURES it - reproducing a result, not trusting a record.
 */
export class LineageIO {
    constructor(private kb: KnowledgeBase) {}

    public export(rootHash: string): LineageBundle {
        const edges = this.kb.getDescendantTree(rootHash);
        const artifacts: Record<string, string> = {};
        const rootCode = this.kb.getArtifact(rootHash);
        if (!rootCode) throw new Error(`Unknown artifact ${rootHash}`);
        artifacts[rootHash] = rootCode;
        for (const e of edges) {
            const code = this.kb.getArtifact(e.child);
            if (code) artifacts[e.child] = code;
        }
        return { version: 1, rootHash, artifacts, edges };
    }

    public import(bundle: LineageBundle): { artifacts: number; edges: number } {
        if (bundle.version !== 1) throw new Error('Unsupported bundle version');
        let a = 0;
        for (const [hash, code] of Object.entries(bundle.artifacts)) {
            if (KnowledgeBase.hashCode(code) !== hash) throw new Error(`Integrity failure on ${hash}`);
            this.kb.storeArtifact(code); a++;
        }
        let e = 0;
        for (const edge of bundle.edges) {
            this.kb.recordMutation({
                experimentId: 'imported', generation: edge.depth, benchmarkId: 'imported',
                category: 'Imported', parentHash: edge.parent, variantHash: edge.child,
                strategy: edge.strategy, accepted: edge.accepted, rejectionReason: null,
                latencyMean: null, latencyImprovementPct: null, memoryMb: null,
                complexity: null, pValue: null, reasoning: 'imported lineage edge'
            }); e++;
        }
        return { artifacts: a, edges: e };
    }

    /**
     * Replays an accepted lineage: re-applies each recorded symbolic
     * strategy to the seed, re-validates equivalence, re-benchmarks, and
     * reports measured-now vs recorded-then. LLM strategies cannot be
     * deterministically replayed (stochastic operator); the recorded
     * child artifact is used verbatim for those steps and re-validated.
     */
    public async replay(seedHash: string): Promise<{ steps: { strategy: string; equivalent: boolean; latencyMs: number }[]; finalImprovementPct: number } > {
        const seedCode = this.kb.getArtifact(seedHash);
        if (!seedCode) throw new Error(`Unknown seed ${seedHash}`);
        const edges = this.kb.getDescendantTree(seedHash).filter(e => e.accepted);
        const ast = new ASTMutator();
        const runner = new SandboxRunner();
        const guardian = new AdvancedSemanticGuardian();
        const mean = (a: number[]) => a.reduce((x, y) => x + y, 0) / a.length;

        const seedLat = mean(runner.executeCodeBenchmark(seedCode, 15).map(s => s.latencyMs));
        let current = seedCode;
        const steps: { strategy: string; equivalent: boolean; latencyMs: number }[] = [];

        for (const edge of edges) {
            let next: string | null = null;
            const rule = ast.getRules().find(r => r.name === edge.strategy);
            if (rule) {
                try { next = rule.apply(current); } catch { next = null; }
            }
            if (!next || next === current) next = this.kb.getArtifact(edge.child); // stochastic operators: recorded artifact
            if (!next) continue;
            const verdict = await guardian.evaluateEquivalence(seedCode, next);
            const lat = mean(runner.executeCodeBenchmark(next, 15).map(s => s.latencyMs));
            steps.push({ strategy: edge.strategy, equivalent: verdict.passed, latencyMs: lat });
            if (verdict.passed) current = next;
        }
        const finalLat = mean(runner.executeCodeBenchmark(current, 15).map(s => s.latencyMs));
        return { steps, finalImprovementPct: (seedLat - finalLat) / seedLat * 100 };
    }

    /**
     * Time Machine: replays experiment #id under its recorded manifest and
     * compares the re-measured gain to the recorded one. Deterministic
     * layers reproduce exactly; hardware jitter is the expected residual.
     */
    public async replayExperiment(experimentId: string): Promise<{
        manifest: any; recordedImprovementPct: number | null;
        remeasuredImprovementPct: number; deltaPts: number | null;
        steps: { strategy: string; equivalent: boolean; latencyMs: number }[];
    }> {
        const exp = this.kb.getExperiment(experimentId);
        if (!exp) throw new Error(`Unknown experiment ${experimentId}`);
        const seedHash = exp.manifest.seedHash || this.kb.getExperimentSeedHash(experimentId);
        if (!seedHash) throw new Error('Experiment has no recorded seed');
        const r = await this.replay(seedHash);
        const recorded = exp.manifest.recordedImprovementPct ?? null;
        return {
            manifest: exp.manifest,
            recordedImprovementPct: recorded,
            remeasuredImprovementPct: r.finalImprovementPct,
            deltaPts: recorded === null ? null : r.finalImprovementPct - recorded,
            steps: r.steps
        };
    }

    /** ASCII genetic tree (observability without a UI). */
    public renderTree(rootHash: string): string {
        const edges = this.kb.getDescendantTree(rootHash);
        const children = new Map<string, typeof edges>();
        for (const e of edges) {
            if (!children.has(e.parent)) children.set(e.parent, []);
            children.get(e.parent)!.push(e);
        }
        const lines: string[] = [rootHash.slice(0, 12) + ' (seed)'];
        const walk = (hash: string, prefix: string) => {
            const kids = children.get(hash) || [];
            kids.forEach((k, i) => {
                const last = i === kids.length - 1;
                lines.push(`${prefix}${last ? '└─' : '├─'}[${k.strategy}]${k.accepted ? ' ✓ ' : ' ✗ '}${k.child.slice(0, 12)}`);
                if (!k.accepted) {
                    for (const ce of this.kb.getCounterexamplesForVariant(k.child)) {
                        lines.push(`${prefix}${last ? '   ' : '│  '}   └─ contre-exemple #${ce.id} ${ce.input_json.slice(0, 40)}`);
                    }
                }
                walk(k.child, prefix + (last ? '   ' : '│  '));
            });
        };
        walk(rootHash, '');
        return lines.join('\n');
    }
}
