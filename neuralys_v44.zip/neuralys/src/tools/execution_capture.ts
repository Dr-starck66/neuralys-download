import { Project, SyntaxKind, Node } from 'ts-morph';

/**
 * ═══ CAPTURE D'EXÉCUTION UNIVERSELLE ════════════════════════════════════
 *
 * Constat qui motive cette architecture (évaluation v42, 15 dépôts) :
 * **0,9 % [0,4 ; 2,1] des fonctions de production sont exécutables** par le
 * harnais synthétique. Ni la génération, ni la preuve, ni la mesure ne
 * limitent le système — c'est l'exécutabilité.
 *
 * Cause racine : le harnais SYNTHÉTISE les entrées à partir d'une hypothèse
 * de forme (`f(number[]) → valeur`). Toute fonction qui n'y entre pas est
 * écartée : arité multiple, méthodes de classe, closures, async, callbacks,
 * dépendances internes.
 *
 * Renversement : on n'invente plus les entrées, on **capture les exécutions
 * réelles**. L'instrumentation est faite au niveau de l'AST — pas seulement
 * sur la surface exportée — de sorte que les fonctions internes, les
 * méthodes, les fonctions fléchées et les fonctions asynchrones sont
 * enregistrées de la même manière.
 *
 * Le rejeu devient l'oracle principal ; le fuzzing synthétique redevient un
 * simple filet de sécurité.
 *
 * Enveloppe utilisée :
 *     function f(a, b) { CORPS }
 *   → function f(a, b) { return __NR.rec('id', this, arguments, () => { CORPS }); }
 *
 * Une fonction fléchée hérite lexicalement de `this`, `arguments` et `super`
 * de la fonction englobante : le corps conserve donc exactement sa sémantique.
 * `return` à l'intérieur du corps retourne depuis la flèche, dont la valeur
 * est renvoyée par `rec` — la valeur de retour est préservée.
 */

export interface InstrumentationStats {
    total: number;
    instrumented: number;
    skipped: Record<string, number>;
}

export interface CapturedCall {
    args: unknown[];
    argsAfter: unknown[];
    thisBefore: unknown;
    thisAfter: unknown;
    result: unknown;
    threw: string | null;
    ms: number;
}

export interface CapturedFunction {
    id: string;            // fichier#nom
    file: string;
    name: string;
    kind: 'function' | 'method' | 'arrow' | 'async' | 'unknown';
    calls: CapturedCall[];
    totalCalls: number;
    totalMs: number;
    mutatesArgs: boolean;
    mutatesThis: boolean;
    deterministic: boolean;
}

/** Runtime d'enregistrement injecté dans le processus instrumenté. */
export const RECORDER_RUNTIME = `
(function () {
  if (globalThis.__NR) return;
  try { globalThis.__NR_FS = require('fs'); }
  catch (e) { import('node:fs').then(function (m) { globalThis.__NR_FS = m.default || m; }, function () {}); }
  var MAX = 25;
  var store = new Map();
  function clone(v, depth) {
    depth = depth || 0;
    if (depth > 6) return '__NR_DEEP__';
    if (v === null || v === undefined) return v;
    var t = typeof v;
    if (t === 'number' || t === 'string' || t === 'boolean') return v;
    if (t === 'function') return '__NR_FN__';
    if (t === 'symbol' || t === 'bigint') return String(v);
    try {
      if (Array.isArray(v)) {
        if (v.length > 5000) return '__NR_BIG__';
        var a = [];
        for (var i = 0; i < v.length; i++) a.push(clone(v[i], depth + 1));
        return a;
      }
      if (v instanceof Date) return { __NR_DATE__: v.getTime() };
      if (v instanceof RegExp) return { __NR_RE__: String(v) };
      if (v instanceof Map || v instanceof Set) return '__NR_COLLECTION__';
      if (v.constructor && v.constructor.name && v.constructor.name !== 'Object') {
        var o2 = { __NR_CLASS__: v.constructor.name };
        var ks = Object.keys(v).slice(0, 40);
        for (var k2 = 0; k2 < ks.length; k2++) o2[ks[k2]] = clone(v[ks[k2]], depth + 1);
        return o2;
      }
      var o = {};
      var keys = Object.keys(v);
      if (keys.length > 200) return '__NR_WIDE__';
      for (var j = 0; j < keys.length; j++) o[keys[j]] = clone(v[keys[j]], depth + 1);
      return o;
    } catch (e) { return '__NR_UNSERIALIZABLE__'; }
  }
  function entry(id, kind) {
    var e = store.get(id);
    if (!e) { e = { id: id, kind: kind, calls: [], totalCalls: 0, totalMs: 0, mutatesArgs: false, mutatesThis: false, deterministic: true, seen: new Map() }; store.set(id, e); }
    return e;
  }
  function finish(e, before, thisBefore, argsArr, thisArg, out, threw, t0) {
    var ms = Number(process.hrtime.bigint() - t0) / 1e6;
    var after = [];
    for (var i = 0; i < argsArr.length; i++) after.push(clone(argsArr[i]));
    var thisAfter = (thisArg === globalThis || thisArg === undefined) ? undefined : clone(thisArg);
    if (JSON.stringify(before) !== JSON.stringify(after)) e.mutatesArgs = true;
    if (JSON.stringify(thisBefore) !== JSON.stringify(thisAfter)) e.mutatesThis = true;
    var res = clone(out);
    if (!threw) {
      try {
        var key = JSON.stringify([before, thisBefore]);
        if (key && key.length < 60000) {
          var prev = e.seen.get(key);
          var ser = JSON.stringify(res);
          if (prev !== undefined && prev !== ser) e.deterministic = false;
          else if (prev === undefined && e.seen.size < 120) e.seen.set(key, ser);
        }
      } catch (x) {}
    }
    e.totalCalls++;
    e.totalMs += ms;
    if (e.calls.length < MAX) {
      e.calls.push({ args: before, argsAfter: after, thisBefore: thisBefore, thisAfter: thisAfter, result: res, threw: threw, ms: ms });
    }
  }
  globalThis.__NR = {
    rec: function (id, kind, thisArg, argsArr, thunk) {
      var e = entry(id, kind);
      var before = [];
      for (var i = 0; i < argsArr.length; i++) before.push(clone(argsArr[i]));
      var thisBefore = (thisArg === globalThis || thisArg === undefined) ? undefined : clone(thisArg);
      var t0 = process.hrtime.bigint();
      var out, threw = null, err = null;
      try { out = thunk(); }
      catch (ex) { threw = (ex && ex.constructor && ex.constructor.name) || 'Error'; err = ex; }
      finish(e, before, thisBefore, argsArr, thisArg, out, threw, t0);
      if (err) throw err;
      return out;
    },
    recAsync: function (id, kind, thisArg, argsArr, thunk) {
      var e = entry(id, kind);
      var before = [];
      for (var i = 0; i < argsArr.length; i++) before.push(clone(argsArr[i]));
      var thisBefore = (thisArg === globalThis || thisArg === undefined) ? undefined : clone(thisArg);
      var t0 = process.hrtime.bigint();
      return Promise.resolve().then(thunk).then(
        function (out) { finish(e, before, thisBefore, argsArr, thisArg, out, null, t0); return out; },
        function (ex) {
          finish(e, before, thisBefore, argsArr, thisArg, undefined, (ex && ex.constructor && ex.constructor.name) || 'Error', t0);
          throw ex;
        }
      );
    },
    dumpToFile: function (file) {
      // require n'existe pas en module ES : fs est resolu par import
      // dynamique des le chargement, et utilise au moment du vidage.
      try {
        var f = globalThis.__NR_FS;
        if (f) { f.writeFileSync(file, JSON.stringify(globalThis.__NR.dump())); }
      } catch (e) {}
    },
    dump: function () {
      var out = [];
      store.forEach(function (e) {
        out.push({ id: e.id, kind: e.kind, calls: e.calls, totalCalls: e.totalCalls, totalMs: e.totalMs,
                   mutatesArgs: e.mutatesArgs, mutatesThis: e.mutatesThis, deterministic: e.deterministic });
      });
      return out;
    }
  };
})();
// Vidage automatique en fin de processus : indispensable quand ce sont les
// tests du projet qui pilotent l'exécution — nous ne contrôlons pas leur
// point de sortie.
if (typeof process !== 'undefined' && process.env && process.env.NEURALYS_DUMP) {
  process.on('exit', function () {
    globalThis.__NR.dumpToFile(process.env.NEURALYS_DUMP + '.' + process.pid + '.json');
  });
}
`;

/**
 * Instrumente un fichier source : toute fonction dotée d'un corps de bloc est
 * enveloppée. Les cas non couverts sont COMPTÉS, jamais silencieux — c'est ce
 * comptage qui donne la borne supérieure honnête de la couverture.
 */
export class ExecutionInstrumenter {
    private project = new Project({ useInMemoryFileSystem: true });

    public instrument(code: string, fileId: string): { code: string; stats: InstrumentationStats } {
        const stats: InstrumentationStats = { total: 0, instrumented: 0, skipped: {} };
        const skip = (why: string) => { stats.skipped[why] = (stats.skipped[why] || 0) + 1; };

        let sf;
        try { sf = this.project.createSourceFile(`i_${Math.random().toString(36).slice(2)}.ts`, code, { overwrite: true }); }
        catch { skip('fichier non parsable'); return { code, stats }; }

        type Target = { node: Node; name: string; kind: CapturedFunction['kind']; isArrow: boolean; isAsync: boolean };
        const targets: Target[] = [];

        // Descendants et non getFunctions() : une fonction déclarée à
        // l'intérieur d'une autre est du code de production comme les autres.
        for (const fn of sf.getDescendantsOfKind(SyntaxKind.FunctionDeclaration)) {
            targets.push({ node: fn, name: fn.getName() || '(anonyme)', kind: 'function', isArrow: false, isAsync: fn.isAsync() });
        }
        for (const m of sf.getDescendantsOfKind(SyntaxKind.MethodDeclaration)) {
            const cls = m.getFirstAncestorByKind(SyntaxKind.ClassDeclaration);
            targets.push({ node: m, name: `${cls?.getName() || 'Class'}.${m.getName()}`, kind: 'method', isArrow: false, isAsync: m.isAsync() });
        }
        for (const fe of sf.getDescendantsOfKind(SyntaxKind.FunctionExpression)) {
            const parent = fe.getParent();
            const name = Node.isVariableDeclaration(parent) ? parent.getName()
                : Node.isPropertyAssignment(parent) ? parent.getName() : '(expr)';
            targets.push({ node: fe, name, kind: 'function', isArrow: false, isAsync: fe.isAsync() });
        }
        for (const ar of sf.getDescendantsOfKind(SyntaxKind.ArrowFunction)) {
            const parent = ar.getParent();
            const name = Node.isVariableDeclaration(parent) ? parent.getName()
                : Node.isPropertyAssignment(parent) ? parent.getName() : '(flèche)';
            targets.push({ node: ar, name, kind: 'arrow', isArrow: true, isAsync: ar.isAsync() });
        }

        // Traitement des plus profonds d'abord : réécrire un parent invaliderait
        // les nœuds enfants déjà collectés.
        targets.sort((a, b) => b.node.getStart() - a.node.getStart());

        for (const t of targets) {
            stats.total++;
            const fn: any = t.node;
            if (fn.isGenerator && fn.isGenerator()) { skip('générateur (yield non enveloppable)'); continue; }

            let body = fn.getBody?.();
            if (!body) { skip('sans corps'); continue; }

            // Flèche à corps d'expression : on reconstruit la flèche complète
            // (setBodyText ne s'applique pas à un corps d'expression).
            if (t.isArrow && !Node.isBlock(body)) {
                const params = fn.getParameters();
                if (params.some((p: any) => p.isRestParameter() || !Node.isIdentifier(p.getNameNode()))) {
                    skip('flèche à paramètres complexes'); continue;
                }
                const names = params.map((p: any) => p.getName());
                const id0 = `${fileId}#${t.name}`;
                const call0 = t.isAsync ? '__NR.recAsync' : '__NR.rec';
                const thunk0 = t.isAsync ? `async () => (${body.getText()})` : `() => (${body.getText()})`;
                const header = `${t.isAsync ? 'async ' : ''}(${names.join(', ')})`;
                try {
                    fn.replaceWithText(`${header} => ${call0}(${JSON.stringify(id0)}, ${JSON.stringify(t.isAsync ? 'async' : 'arrow')}, undefined, [${names.join(', ')}], ${thunk0})`);
                    stats.instrumented++;
                } catch { skip('flèche à expression non convertible'); }
                continue;
            }
            if (!body || !Node.isBlock(body)) { skip('corps non bloc'); continue; }

            // Liste d'arguments : `arguments` pour les fonctions classiques
            // (gère reste et déstructuration), liste explicite pour les flèches.
            let argsExpr: string;
            if (!t.isArrow) argsExpr = 'arguments';
            else {
                const params = fn.getParameters();
                if (params.some((p: any) => p.isRestParameter() || !Node.isIdentifier(p.getNameNode()))) {
                    skip('flèche à paramètres complexes'); continue;
                }
                argsExpr = `[${params.map((p: any) => p.getName()).join(', ')}]`;
            }

            const inner = body.getText().replace(/^\{|\}$/g, '');
            const id = `${fileId}#${t.name}`;
            const thisExpr = t.isArrow ? 'undefined' : 'this';
            const call = t.isAsync ? '__NR.recAsync' : '__NR.rec';
            const thunk = t.isAsync ? `async () => {${inner}}` : `() => {${inner}}`;
            try {
                fn.setBodyText(`return ${call}(${JSON.stringify(id)}, ${JSON.stringify(t.isAsync ? 'async' : t.kind)}, ${thisExpr}, ${argsExpr}, ${thunk});`);
                stats.instrumented++;
            } catch (e: any) {
                skip('réécriture impossible');
            }
        }

        const out = sf.getFullText();
        this.project.removeSourceFile(sf);
        // Garde-fou : le résultat doit rester parsable, sinon on renonce.
        try { this.project.createSourceFile('chk.ts', out, { overwrite: true }); }
        catch { return { code, stats: { total: stats.total, instrumented: 0, skipped: { 'résultat non parsable': stats.total } } }; }
        return { code: out, stats };
    }
}

/** Un appel est rejouable si aucune valeur n'a été remplacée par un marqueur. */
export function isReplayableCall(c: CapturedCall): boolean {
    const bad = (v: unknown): boolean => {
        if (typeof v === 'string' && v.startsWith('__NR_')) return true;
        if (Array.isArray(v)) return v.some(bad);
        if (v && typeof v === 'object') return Object.values(v as object).some(bad);
        return false;
    };
    return !bad(c.args) && !bad(c.result) && !bad(c.thisBefore);
}

/* ─── Exécution instrumentée d'un paquet réel ─────────────────────────── */

import * as fs from 'fs';
import * as path from 'path';
import * as os from 'os';
import { spawnSync } from 'child_process';

export interface CaptureReport {
    package: string;
    filesInstrumented: number;
    functionsFound: number;
    functionsInstrumented: number;
    skipped: Record<string, number>;
    captured: CapturedFunction[];
    /** Fonctions avec au moins un appel rejouable — le KPI. */
    functionsReplayable: number;
    /** Fonctions déclarées dans les fichiers réellement chargés à l'exécution. */
    functionsInLoadedFiles: number;
    /** Nombre de fonctions instrumentées par fichier — sert au dénominateur ci-dessus. */
    perFile: Record<string, number>;
    error?: string;
}

export class ExecutionCapture {
    private instrumenter = new ExecutionInstrumenter();

    /**
     * Copie le paquet, instrumente chaque fichier, exécute un scénario réel,
     * puis récupère les exécutions capturées. Le paquet installé n'est jamais
     * modifié.
     */
    public capture(packageDir: string, driverPath: string, pkgName: string, timeoutMs = 180_000): CaptureReport {
        const report: CaptureReport = {
            package: pkgName, filesInstrumented: 0, functionsFound: 0, functionsInstrumented: 0,
            skipped: {}, captured: [], functionsReplayable: 0, functionsInLoadedFiles: 0, perFile: {}
        };
        const ws = fs.mkdtempSync(path.join(os.tmpdir(), 'neuralys_cap_'));
        const dest = path.join(ws, path.basename(packageDir));
        fs.cpSync(packageDir, dest, { recursive: true });

        const walk = (dir: string, acc: string[] = [], depth = 0): string[] => {
            if (depth > 6) return acc;
            for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
                if (e.name === 'node_modules' || e.name.startsWith('.')) continue;
                const p = path.join(dir, e.name);
                if (e.isDirectory()) walk(p, acc, depth + 1);
                else if (/\.(js|cjs)$/.test(e.name) && !/\.min\./.test(e.name)) acc.push(p);
            }
            return acc;
        };

        for (const file of walk(dest)) {
            let text: string;
            try { text = fs.readFileSync(file, 'utf-8'); } catch { continue; }
            if (text.length > 2_000_000) continue;
            const rel = path.relative(dest, file);
            const { code, stats } = this.instrumenter.instrument(text, rel);
            report.functionsFound += stats.total;
            report.functionsInstrumented += stats.instrumented;
            for (const [k, v] of Object.entries(stats.skipped)) report.skipped[k] = (report.skipped[k] || 0) + v;
            if (stats.instrumented > 0) {
                fs.writeFileSync(file, code);
                report.filesInstrumented++;
                report.perFile[rel] = stats.instrumented;
            }
        }

        // Les dépendances soeurs doivent se résoudre depuis la copie :
        // un lien vers le node_modules du projet suffit et évite de dupliquer
        // des centaines de mégaoctets.
        try {
            const realNM = path.resolve('node_modules');
            if (fs.existsSync(realNM)) fs.symlinkSync(realNM, path.join(ws, 'node_modules'), 'dir');
        } catch { /* lien déjà présent ou non supporté */ }

        // Point d'entrée résolu explicitement : requérir un FICHIER contourne
        // le champ `exports` du package.json, qui bloque sinon la copie.
        let entryPath = dest;
        try {
            const pj = JSON.parse(fs.readFileSync(path.join(dest, 'package.json'), 'utf-8'));
            // `exports` prime sur `main` dans les paquets récents ; requérir un
            // chemin de fichier absolu ne déclenche pas la résolution `exports`,
            // il faut donc l'extraire nous-mêmes.
            let fromExports: string | null = null;
            const ex = pj.exports;
            if (typeof ex === 'string') fromExports = ex;
            else if (ex && typeof ex === 'object') {
                const dot = ex['.'] ?? ex;
                if (typeof dot === 'string') fromExports = dot;
                else if (dot && typeof dot === 'object') {
                    fromExports = dot.require || dot.default || dot.node ||
                        Object.values(dot).find(v => typeof v === 'string') as string || null;
                    if (fromExports && typeof fromExports === 'object') fromExports = null;
                }
            }
            const main = fromExports || pj.main || 'index.js';
            const cand = path.join(dest, main);
            if (fs.existsSync(cand)) entryPath = cand;
            else if (fs.existsSync(cand + '.js')) entryPath = cand + '.js';
            else if (fs.existsSync(path.join(dest, 'index.js'))) entryPath = path.join(dest, 'index.js');
        } catch {
            if (fs.existsSync(path.join(dest, 'index.js'))) entryPath = path.join(dest, 'index.js');
        }

        const outFile = path.join(ws, 'capture.json');
        const harness = `
${RECORDER_RUNTIME}
try { require(${JSON.stringify(path.resolve(driverPath))}); }
catch (e) { console.error('[driver]', e && e.message); }
require('fs').writeFileSync(${JSON.stringify(outFile)}, JSON.stringify(globalThis.__NR.dump()));
`;
        const harnessFile = path.join(ws, 'harness.cjs');
        fs.writeFileSync(harnessFile, harness);
        const res = spawnSync('node', [harnessFile], {
            timeout: timeoutMs, encoding: 'utf-8', maxBuffer: 128 * 1024 * 1024,
            env: { ...process.env, NEURALYS_PKG: entryPath, NEURALYS_PKG_DIR: dest }
        });

        if (fs.existsSync(outFile)) {
            const raw = JSON.parse(fs.readFileSync(outFile, 'utf-8'));
            report.captured = raw.map((r: any) => ({
                id: r.id, file: r.id.split('#')[0], name: r.id.split('#')[1] || '?', kind: r.kind,
                calls: r.calls, totalCalls: r.totalCalls, totalMs: r.totalMs,
                mutatesArgs: r.mutatesArgs, mutatesThis: r.mutatesThis, deterministic: r.deterministic
            }));
            report.functionsReplayable = report.captured.filter(f => f.calls.some(isReplayableCall)).length;
            // Un fichier est considéré chargé si au moins une de ses fonctions
            // s'est exécutée. Dénominateur plus juste que « tout le paquet »,
            // qui inclut des bundles jamais requis.
            const loaded = new Set(report.captured.map(f => f.file));
            report.functionsInLoadedFiles = Object.entries(report.perFile)
                .filter(([f]) => loaded.has(f)).reduce((a, [, n]) => a + n, 0);
            if (report.captured.length === 0 && res.stderr) report.error = res.stderr.slice(0, 200);
        } else {
            report.error = (res.stderr || 'aucune capture produite').slice(0, 300);
        }
        fs.rmSync(ws, { recursive: true, force: true });
        return report;
    }
}
