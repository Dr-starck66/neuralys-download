import * as fs from 'fs';
import * as path from 'path';
import * as os from 'os';
import { spawnSync } from 'child_process';
import { Project, SyntaxKind } from 'ts-morph';
import { ASTMutator } from '../core/ast_mutator';
import { AlgorithmSpace, profileInputs } from '../core/algorithm_space';
import { RecordedCall, isReplayable } from './workload_analyzer';
import { CallerOptimizer, PurityEvidence } from '../core/caller_optimizer';

/**
 * ═══ ÉVOLUTION D'UN PROJET RÉEL ═════════════════════════════════════════
 *
 * Différence essentielle avec le harnais synthétique : la fonction mutée
 * n'est PAS exécutée hors contexte. Le paquet entier est copié dans un
 * espace de travail, le fichier de la fonction y est réécrit, puis un
 * processus enfant charge le paquet depuis cet espace et rejoue le corpus
 * d'appels enregistré. Les dépendances internes (`require('./_baseSlice')`)
 * fonctionnent donc réellement — c'est ce qui rend l'évolution possible sur
 * du code de production plutôt que sur des fonctions isolées.
 *
 * Preuve d'équivalence : mêmes sorties que celles OBSERVÉES en production,
 * sur les entrées OBSERVÉES en production. Aucune synthèse, aucune hypothèse
 * de type ou d'arité.
 */

export interface CandidateOutcome {
    strategy: string;
    equivalent: boolean;
    checked: number;
    baselineMs: number | null;
    candidateMs: number | null;
    improvementPct: number | null;
    error?: string;
}

export interface FunctionEvolution {
    functionName: string;
    file: string;
    candidates: CandidateOutcome[];
    accepted: CandidateOutcome | null;
}

export class ProjectEvolver {
    private ast = new ASTMutator();
    private algo = new AlgorithmSpace();
    private project = new Project({ useInMemoryFileSystem: false, skipAddingFilesFromTsConfig: true });

    /**
     * @param purity pureté ÉTABLIE PAR OBSERVATION de la charge réelle.
     * Sans cette preuve, les règles au niveau appelant refusent de
     * transformer : hisser un appel impur changerait le comportement.
     */
    constructor(private packageDir: string, private purity: PurityEvidence = { pure: new Set(), impure: new Set() }) {}

    /** Copie isolée du paquet : aucune mutation ne touche l'installation réelle. */
    private makeWorkspace(): string {
        const ws = fs.mkdtempSync(path.join(os.tmpdir(), 'neuralys_ws_'));
        const dest = path.join(ws, path.basename(this.packageDir));
        fs.cpSync(this.packageDir, dest, { recursive: true });
        return dest;
    }

    /** Localise le fichier et la déclaration de la fonction cible. */
    public locate(fnName: string): { file: string; source: string } | null {
        const direct = path.join(this.packageDir, `${fnName}.js`);
        const files = fs.existsSync(direct)
            ? [direct]
            : fs.readdirSync(this.packageDir).filter(f => f.endsWith('.js')).map(f => path.join(this.packageDir, f));
        for (const file of files) {
            const text = fs.readFileSync(file, 'utf-8');
            if (!new RegExp(`function\\s+${fnName}\\s*\\(`).test(text)) continue;
            const sf = this.project.createSourceFile(`__loc_${Date.now()}_${Math.random().toString(36).slice(2)}.js`, text, { overwrite: true });
            const fn = sf.getFunctions().find(f => f.getName() === fnName);
            // Le texte doit être lu AVANT de retirer le fichier du projet :
            // ts-morph invalide les nœuds dès que leur source disparaît.
            const source = fn ? fn.getText() : null;
            this.project.removeSourceFile(sf);
            if (source) return { file, source };
        }
        return null;
    }

    /** Génère les variantes candidates pour une source de fonction donnée. */
    public candidates(source: string): { strategy: string; code: string }[] {
        const out: { strategy: string; code: string }[] = [];
        for (const rule of this.ast.getRules()) {
            try {
                const mutated = rule.apply(source);
                if (mutated && mutated !== source) out.push({ strategy: rule.name, code: mutated });
            } catch { /* règle non applicable */ }
        }
        try {
            for (const c of this.algo.generate(source, profileInputs([[1, 2, 3]]))) {
                out.push({ strategy: c.strategy, code: c.code });
            }
        } catch { /* aucune intention algorithmique reconnue */ }
        // Optimisations au niveau APPELANT : c'est là que se trouve le gain
        // applicatif réel, pas dans les internes de bibliothèque.
        try {
            for (const m of new CallerOptimizer(this.purity).mutate(source)) {
                out.push({ strategy: m.strategy, code: m.code });
            }
        } catch { /* aucun site appelant */ }
        return out;
    }

    /**
     * Rejoue le corpus contre le paquet chargé depuis l'espace de travail.
     * Retourne les sorties et le temps total — exécuté en processus enfant
     * pour que le cache de modules soit propre à chaque variante.
     */
    private replayInWorkspace(workspacePkg: string, fnName: string, calls: RecordedCall[], samples: number):
        { ok: boolean; outputs: string[]; times: number[]; error?: string } {
        const corpusFile = path.join(os.tmpdir(), `neuralys_corpus_${Date.now()}_${Math.random().toString(36).slice(2)}.json`);
        fs.writeFileSync(corpusFile, JSON.stringify(calls.filter(isReplayable).map(c => c.args)));
        const script = `
const pkg = require(${JSON.stringify(workspacePkg)});
const corpus = require(${JSON.stringify(corpusFile)});
const fn = pkg[${JSON.stringify(fnName)}];
if (typeof fn !== 'function') { console.log(JSON.stringify({ ok: false, error: 'fonction absente des exports' })); process.exit(0); }
const clone = (v) => JSON.parse(JSON.stringify(v));
const outputs = [];
try {
  for (const args of corpus) outputs.push(JSON.stringify(fn(...clone(args))));
} catch (e) { console.log(JSON.stringify({ ok: false, error: 'exception au rejeu: ' + e.message })); process.exit(0); }
for (let w = 0; w < 5; w++) for (const args of corpus) { try { fn(...clone(args)); } catch (e) {} }
const times = [];
for (let s = 0; s < ${samples}; s++) {
  const fresh = corpus.map(clone);
  const t0 = process.hrtime.bigint();
  for (const args of fresh) { try { fn(...args); } catch (e) {} }
  times.push(Number(process.hrtime.bigint() - t0) / 1e6);
}
console.log(JSON.stringify({ ok: true, outputs, times }));
`;
        const scriptFile = path.join(os.tmpdir(), `neuralys_replay_${Date.now()}_${Math.random().toString(36).slice(2)}.cjs`);
        fs.writeFileSync(scriptFile, script);
        const res = spawnSync('node', [scriptFile], { encoding: 'utf-8', timeout: 120000, maxBuffer: 64 * 1024 * 1024 });
        fs.unlinkSync(scriptFile);
        fs.unlinkSync(corpusFile);
        try {
            return JSON.parse((res.stdout || '').trim().split('\n').pop() || '{}');
        } catch {
            return { ok: false, outputs: [], times: [], error: (res.stderr || 'sortie illisible').slice(0, 200) };
        }
    }

    public evolveFunction(fnName: string, calls: RecordedCall[], samples = 9): FunctionEvolution {
        const located = this.locate(fnName);
        if (!located) return { functionName: fnName, file: '(introuvable)', candidates: [], accepted: null };

        const workspace = this.makeWorkspace();
        const relFile = path.relative(this.packageDir, located.file);
        const wsFile = path.join(workspace, relFile);
        const originalFileText = fs.readFileSync(wsFile, 'utf-8');

        const baseline = this.replayInWorkspace(workspace, fnName, calls, samples);
        const outcomes: CandidateOutcome[] = [];

        if (!baseline.ok) {
            fs.rmSync(path.dirname(workspace), { recursive: true, force: true });
            return { functionName: fnName, file: relFile, candidates: [{ strategy: '(référence)', equivalent: false, checked: 0, baselineMs: null, candidateMs: null, improvementPct: null, error: baseline.error }], accepted: null };
        }
        const mean = (a: number[]) => a.reduce((x, y) => x + y, 0) / a.length;
        const baseMs = Math.min(...baseline.times);

        for (const cand of this.candidates(located.source)) {
            try {
                fs.writeFileSync(wsFile, originalFileText.replace(located.source, cand.code));
                const r = this.replayInWorkspace(workspace, fnName, calls, samples);
                if (!r.ok) {
                    outcomes.push({ strategy: cand.strategy, equivalent: false, checked: 0, baselineMs: baseMs, candidateMs: null, improvementPct: null, error: r.error });
                    continue;
                }
                const equivalent = r.outputs.length === baseline.outputs.length &&
                    r.outputs.every((o, i) => o === baseline.outputs[i]);
                const candMs = Math.min(...r.times);
                outcomes.push({
                    strategy: cand.strategy,
                    equivalent,
                    checked: baseline.outputs.length,
                    baselineMs: baseMs,
                    candidateMs: candMs,
                    improvementPct: equivalent ? (baseMs - candMs) / baseMs * 100 : null
                });
            } catch (e: any) {
                outcomes.push({ strategy: cand.strategy, equivalent: false, checked: 0, baselineMs: baseMs, candidateMs: null, improvementPct: null, error: e.message });
            } finally {
                fs.writeFileSync(wsFile, originalFileText);
            }
        }

        fs.rmSync(path.dirname(workspace), { recursive: true, force: true });
        const viable = outcomes.filter(o => o.equivalent && (o.improvementPct ?? 0) > 2)
            .sort((a, b) => (b.improvementPct ?? 0) - (a.improvementPct ?? 0));
        return { functionName: fnName, file: relFile, candidates: outcomes, accepted: viable[0] || null };
    }
}
