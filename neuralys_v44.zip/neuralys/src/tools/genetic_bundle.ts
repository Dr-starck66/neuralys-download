import * as crypto from 'crypto';
import { LineageIO, LineageBundle } from './lineage_io';
import { KnowledgeBase } from '../memory/knowledge_base';

export interface SignedBundle {
    bundle: LineageBundle;
    manifest: {
        publisher: string;
        createdAt: string;
        contentSha256: string;
        signature: string | null;
        publicKey: string | null;
    };
}

/**
 * Marketplace substrate (technique, pas la place de marché elle-même) :
 * bundles de lignées distribuables, signés et vérifiables.
 * - contentSha256 : intégrité du contenu
 * - signature Ed25519 optionnelle : authenticité de l'éditeur
 * L'importateur vérifie les deux AVANT tout merge ; les artefacts restent
 * en plus individuellement vérifiés par hash à l'intérieur du merge.
 * Le paiement/hébergement d'une place de marché est une infrastructure
 * métier hors du périmètre de ce moteur.
 */
export class GeneticBundle {
    constructor(private kb: KnowledgeBase) {}

    public static generateKeypair(): { publicKey: string; privateKey: string } {
        const { publicKey, privateKey } = crypto.generateKeyPairSync('ed25519');
        return {
            publicKey: publicKey.export({ type: 'spki', format: 'pem' }).toString(),
            privateKey: privateKey.export({ type: 'pkcs8', format: 'pem' }).toString()
        };
    }

    public publish(rootHash: string, publisher: string, privateKeyPem?: string, publicKeyPem?: string): SignedBundle {
        const bundle = new LineageIO(this.kb).export(rootHash);
        const content = JSON.stringify(bundle);
        const contentSha256 = crypto.createHash('sha256').update(content).digest('hex');
        let signature: string | null = null;
        if (privateKeyPem) {
            signature = crypto.sign(null, Buffer.from(contentSha256), privateKeyPem).toString('base64');
        }
        return {
            bundle,
            manifest: { publisher, createdAt: new Date().toISOString(), contentSha256, signature, publicKey: publicKeyPem || null }
        };
    }

    public verify(signed: SignedBundle): { integrity: boolean; authentic: boolean | null } {
        const contentSha256 = crypto.createHash('sha256').update(JSON.stringify(signed.bundle)).digest('hex');
        const integrity = contentSha256 === signed.manifest.contentSha256;
        let authentic: boolean | null = null;
        if (signed.manifest.signature && signed.manifest.publicKey) {
            try {
                authentic = crypto.verify(null, Buffer.from(signed.manifest.contentSha256),
                    signed.manifest.publicKey, Buffer.from(signed.manifest.signature, 'base64'));
            } catch { authentic = false; }
        }
        return { integrity, authentic };
    }

    public install(signed: SignedBundle): { artifacts: number; edges: number } {
        const v = this.verify(signed);
        if (!v.integrity) throw new Error('Bundle rejeté : intégrité invalide');
        if (v.authentic === false) throw new Error('Bundle rejeté : signature invalide');
        return new LineageIO(this.kb).import(signed.bundle);
    }
}
