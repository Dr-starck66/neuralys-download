import PDFDocument from 'pdfkit';
import * as fs from 'fs';
import * as ss from 'simple-statistics';
import { KnowledgeBase } from '../memory/knowledge_base';
import { SandboxRunner } from '../validation/sandbox_runner';
import { Explainer } from './explainer';

/**
 * Publication-grade report (mode publication scientifique).
 * Methodology: seed and champion are RE-MEASURED fresh (n=30 calibrated
 * samples each) rather than read from historical records - the PDF
 * reports what the reader could reproduce, not what was once observed.
 * Statistics: mean, sd, Welch t-test p-value, 95% CI of the difference,
 * Cohen's d effect size. Distributions rendered as dot strips.
 */
export class PublicationReport {
    constructor(private kb: KnowledgeBase) {}

    private measure(code: string, n: number = 30): number[] {
        return new SandboxRunner().executeCodeBenchmark(code, n).map(s => s.latencyMs);
    }

    private stats(a: number[], b: number[]) {
        const ma = ss.mean(a), mb = ss.mean(b);
        const sa = ss.sampleStandardDeviation(a), sb = ss.sampleStandardDeviation(b);
        const t = ss.tTestTwoSample(a, b, 0) || 0;
        const p = Math.max(1e-12, ss.cumulativeStdNormalProbability(-Math.abs(t)) * 2);
        const pooled = Math.sqrt((sa * sa + sb * sb) / 2);
        const d = pooled > 0 ? (ma - mb) / pooled : 0;
        const se = Math.sqrt(sa * sa / a.length + sb * sb / b.length);
        const ci: [number, number] = [ma - mb - 1.96 * se, ma - mb + 1.96 * se];
        return { ma, mb, sa, sb, p, d, ci, gainPct: (ma - mb) / ma * 100 };
    }

    public async generate(experimentId: string, outPath: string): Promise<string> {
        const exp = this.kb.getExperiment(experimentId);
        if (!exp) throw new Error(`Unknown experiment ${experimentId}`);
        const seedHash = exp.manifest.seedHash || this.kb.getExperimentSeedHash(experimentId);
        const seedCode = this.kb.getArtifact(seedHash);
        if (!seedCode) throw new Error('Seed artifact missing');

        // Champion = accepted descendant with best recorded gain
        const db = (this.kb as any).db;
        const champ = db.prepare(`
            SELECT variant_hash, strategy FROM mutations
            WHERE experiment_id = ? AND accepted = 1
            ORDER BY latency_improvement_pct DESC LIMIT 1`).get(experimentId) as any;
        if (!champ) throw new Error('No accepted mutation in this experiment');
        const champCode = this.kb.getArtifact(champ.variant_hash)!;
        const lineage = this.kb.getAncestry(champ.variant_hash).map(e => e.strategy);

        const a = this.measure(seedCode), b = this.measure(champCode);
        const st = this.stats(a, b);
        const explanation = new Explainer().explain(seedCode, champCode, lineage, st.gainPct);

        const doc = new PDFDocument({ margin: 50 });
        doc.pipe(fs.createWriteStream(outPath));
        doc.fontSize(18).text('Neuralys — Rapport de validation scientifique', { align: 'center' });
        doc.moveDown(0.3).fontSize(9).fillColor('#555')
            .text(`Expérience ${experimentId} · ${exp.target} · ${new Date().toISOString()}`, { align: 'center' });
        doc.moveDown().fillColor('#000');

        doc.fontSize(12).text('Méthodologie', { underline: true }).fontSize(9).moveDown(0.2);
        doc.text(`Ré-mesure indépendante au moment de la génération du rapport : n=${a.length} échantillons calibrés (≥2 ms par répétition amortie, warmup JIT exclu) par variante, entrées mélangées déterministes identiques. Équivalence comportementale vérifiée par fuzzing différentiel (familles structurées + corpus de contre-exemples). Environnement : ${exp.manifest.environment?.platform || 'n/a'}, Node ${exp.manifest.environment?.node || 'n/a'}.`);
        doc.moveDown();

        doc.fontSize(12).text('Résultats', { underline: true }).fontSize(9).moveDown(0.2);
        const rows = [
            ['', 'Seed', 'Champion'],
            ['Moyenne (ms)', st.ma.toFixed(4), st.mb.toFixed(4)],
            ['Écart-type (ms)', st.sa.toFixed(4), st.sb.toFixed(4)],
            ['n', String(a.length), String(b.length)]
        ];
        const x0 = doc.x, colW = 140;
        rows.forEach((r, i) => {
            r.forEach((c, j) => doc.text(c, x0 + j * colW, doc.y + (j === 0 ? 0 : -11), { width: colW, continued: false }));
            if (i === 0) doc.moveTo(x0, doc.y + 2).lineTo(x0 + colW * 3, doc.y + 2).stroke('#999');
        });
        doc.moveDown();
        doc.text(`Gain : ${st.gainPct.toFixed(1)}%   |   Welch t-test : p = ${st.p.toExponential(2)}   |   Cohen's d = ${st.d.toFixed(2)} (${Math.abs(st.d) > 0.8 ? 'effet large' : Math.abs(st.d) > 0.5 ? 'effet moyen' : 'effet faible'})`);
        doc.text(`IC 95% de la différence de latence : [${st.ci[0].toFixed(4)} ; ${st.ci[1].toFixed(4)}] ms`);
        doc.moveDown();

        // Dot-strip distributions
        doc.fontSize(12).text('Distributions de latence', { underline: true }).moveDown(0.4);
        const plotX = doc.x, plotW = 440, allVals = [...a, ...b];
        const min = Math.min(...allVals), max = Math.max(...allVals), span = Math.max(max - min, 1e-9);
        const strip = (vals: number[], label: string, color: string) => {
            const y = doc.y;
            doc.fontSize(8).fillColor('#333').text(label, plotX, y);
            for (const v of vals) {
                doc.circle(plotX + 60 + ((v - min) / span) * (plotW - 60), y + 4, 2).fill(color);
            }
            doc.moveDown(1.2);
        };
        strip(a, 'Seed', '#c0392b');
        strip(b, 'Champion', '#27ae60');
        doc.fillColor('#000').moveDown();

        doc.fontSize(12).text('Explication mécanistique', { underline: true }).fontSize(9).moveDown(0.2);
        doc.text(explanation);
        doc.moveDown();
        doc.fontSize(12).text('Lignée génétique', { underline: true }).fontSize(9).moveDown(0.2);
        doc.text(lineage.join('  →  ') || '(seed)');
        doc.moveDown();
        doc.fontSize(7).fillColor('#777').text(
            `Reproductibilité : manifest d'expérience persisté (graines déterministes, config moteur, environnement). Artefacts adressés par SHA-256 : seed ${seedHash.slice(0, 16)}, champion ${champ.variant_hash.slice(0, 16)}.`);
        doc.end();
        await new Promise(r => setTimeout(r, 400)); // flush stream
        return outPath;
    }
}
