import { KnowledgeBase } from '../memory/knowledge_base';

export interface ProvenanceStep {
    depth: number;
    parentHash: string;
    variantHash: string;
    strategy: string;
    accepted: boolean;
    why: string;
    measuredGainPct: number | null;
    pValue: number | null;
    priorRejections: { count: number; reasons: string[] };
    counterexamplesKnown: number;
}

/**
 * "git blame" of evolution (provenance complète). For any variant,
 * reconstructs the full causal chain from the seed: which mutation, on
 * which parent, why it was accepted (measured gain + p-value + reasoning),
 * how many earlier attempts of the SAME strategy on the SAME signature
 * were rejected and for which reasons, and how many counterexamples the
 * equivalence oracle held over it at the time.
 * Everything is read from the KB - no reconstruction, no guesses.
 */
export class Provenance {
    constructor(private kb: KnowledgeBase) {}

    public blame(variantHash: string): ProvenanceStep[] {
        const db = (this.kb as any).db;
        const chain = this.kb.getAncestry(variantHash);
        return chain.map(edge => {
            const rec = db.prepare(
                'SELECT * FROM mutations WHERE parent_hash = ? AND variant_hash = ? ORDER BY id DESC LIMIT 1'
            ).get(edge.parent, edge.child) as any;
            const rejections = db.prepare(`
                SELECT rejection_reason, COUNT(*) as c FROM mutations
                WHERE strategy = ? AND signature = ? AND accepted = 0 AND id < ?
                GROUP BY rejection_reason`).all(rec.strategy, rec.signature, rec.id) as any[];
            const ces = db.prepare('SELECT COUNT(*) as c FROM counterexamples WHERE signature = ? AND id <= (SELECT MAX(id) FROM counterexamples) ')
                .get(rec.signature) as any;
            return {
                depth: edge.depth,
                parentHash: edge.parent,
                variantHash: edge.child,
                strategy: rec.strategy,
                accepted: !!rec.accepted,
                why: rec.reasoning,
                measuredGainPct: rec.latency_improvement_pct,
                pValue: rec.p_value,
                priorRejections: {
                    count: rejections.reduce((a, r) => a + r.c, 0),
                    reasons: rejections.map(r => `${r.rejection_reason || 'performance'} (x${r.c})`)
                },
                counterexamplesKnown: ces?.c || 0
            };
        });
    }

    public render(variantHash: string): string {
        const steps = this.blame(variantHash);
        if (steps.length === 0) return `${variantHash}: artefact racine (seed) — aucune mutation en amont.`;
        const lines: string[] = [`Provenance de ${variantHash.slice(0, 12)} (${steps.length} mutation(s))`];
        for (const s of steps) {
            lines.push(
                `\n[profondeur ${s.depth}] ${s.parentHash.slice(0, 10)} → ${s.variantHash.slice(0, 10)}`,
                `  mutation   : ${s.strategy}`,
                `  mécanisme  : ${s.why}`,
                `  verdict    : ${s.accepted ? 'ACCEPTÉE' : 'rejetée'}` +
                (s.measuredGainPct !== null ? ` — gain mesuré ${s.measuredGainPct.toFixed(1)}%` : '') +
                (s.pValue !== null ? `, p=${s.pValue.toFixed(4)}` : ''),
                `  historique : ${s.priorRejections.count} tentative(s) antérieure(s) de cette stratégie rejetée(s)` +
                (s.priorRejections.reasons.length ? ` [${s.priorRejections.reasons.join(', ')}]` : ''),
                `  oracle     : ${s.counterexamplesKnown} contre-exemple(s) connus sur cette signature au moment du verdict`
            );
        }
        return lines.join('\n');
    }
}
