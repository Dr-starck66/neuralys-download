import * as fs from 'fs';
import * as path from 'path';
import * as os from 'os';
import { spawnSync } from 'child_process';
import { ExecutionInstrumenter, RECORDER_RUNTIME, CapturedFunction, isReplayableCall } from './execution_capture';
import { ASTMutator } from '../core/ast_mutator';
import { CallerOptimizer, PurityEvidence } from '../core/caller_optimizer';
import { Project } from 'ts-morph';

/**
 * ═══ VALIDATION EXTERNE PAR LA CI DU PROJET ═════════════════════════════
 *
 * Le KPI change de nature. Ce n'est plus « combien de pour cent de gain »,
 * c'est : **une mutation survit-elle à la suite de tests écrite par les
 * auteurs du projet ?** Une amélioration qui casse un seul test n'existe pas.
 *
 * Pipeline, entièrement automatique :
 *   1. découverte du lanceur de tests depuis package.json
 *   2. exécution de référence (la suite doit être verte avant tout)
 *   3. instrumentation des sources, PUIS exécution des tests du projet :
 *      ce sont eux qui produisent la base de rejeu — pas un scénario écrit
 *      par nous. La suite doit rester verte sous instrumentation, sinon
 *      l'instrumentation est déclarée non fiable pour ce dépôt.
 *   4. points chauds classés par temps mesuré pendant les tests
 *   5. génération de candidats, preuve d'équivalence par rejeu
 *   6. **ré-exécution de la suite complète** avec la mutation en place
 *   7. mesure de performance, puis branche Git et rapport
 */

export interface TestRunner {
    command: string;
    args: string[];
    framework: string;
    raw: string;
}

export interface SuiteResult {
    ok: boolean;
    passed: number;
    failed: number;
    durationMs: number;
    output: string;
}

export interface MutationOutcome {
    file: string;
    fn: string;
    strategy: string;
    /** 'prouvé' | 'réfuté' | 'non concluant' (fonction non isolable). */
    replayVerdict: 'prouvé' | 'réfuté' | 'non concluant';
    replayProven: boolean;
    replayChecked: number;
    suitePassed: boolean;
    suiteDetail: string;
    improvementPct: number | null;
    accepted: boolean;
}

export interface RepoValidation {
    repo: string;
    runner: TestRunner | null;
    baseline: SuiteResult | null;
    instrumentedSuite: SuiteResult | null;
    functionsInstrumented: number;
    functionsCaptured: number;
    functionsReplayable: number;
    hotspots: { id: string; calls: number; ms: number }[];
    mutations: MutationOutcome[];
    survivingMutations: number;
    pullRequestBranch: string | null;
    notes: string[];
}

export class CIValidator {
    private instrumenter = new ExecutionInstrumenter();
    private ast = new ASTMutator();
    private project = new Project({ useInMemoryFileSystem: true });

    constructor(private purity: PurityEvidence = { pure: new Set(), impure: new Set() }) {}

    /** Découvre le lanceur réel, en écartant les étapes de lint/build. */
    public discoverRunner(repoDir: string): TestRunner | null {
        let pkg: any;
        try { pkg = JSON.parse(fs.readFileSync(path.join(repoDir, 'package.json'), 'utf-8')); } catch { return null; }
        const raw: string = pkg.scripts?.test || '';
        if (!raw) return null;
        // Une commande composée n'est pas exécutée telle quelle : le lint ou le
        // build échouent pour des raisons sans rapport avec la sémantique.
        const parts = raw.split('&&').map(s => s.trim());
        const testPart = parts.find(p => /mocha|jest|tap\b|node --test|vitest|ava/.test(p)) || parts[parts.length - 1];
        const m = testPart.match(/(mocha|jest|tap|vitest|ava)/);
        if (m) {
            const idx = testPart.indexOf(m[1]);
            const rest = testPart.slice(idx).split(/\s+/);
            return { command: 'npx', args: rest, framework: m[1], raw };
        }
        if (/node --test/.test(testPart)) {
            const rest = testPart.replace(/^.*?node /, '').split(/\s+/).filter(Boolean);
            return { command: 'node', args: rest, framework: 'node:test', raw };
        }
        return null;
    }

    public runSuite(repoDir: string, runner: TestRunner, env: Record<string, string> = {}, timeoutMs = 300_000): SuiteResult {
        const t0 = Date.now();
        const res = spawnSync(runner.command, runner.args, {
            cwd: repoDir, encoding: 'utf-8', timeout: timeoutMs,
            maxBuffer: 64 * 1024 * 1024, shell: true,
            env: { ...process.env, ...env }
        });
        const out = ((res.stdout || '') + '\n' + (res.stderr || '')).slice(-6000);
        const passMatch = out.match(/# pass (\d+)/) || out.match(/(\d+) passing/);
        const failMatch = out.match(/# fail (\d+)/) || out.match(/(\d+) failing/);
        return {
            ok: res.status === 0,
            passed: passMatch ? parseInt(passMatch[1], 10) : 0,
            failed: failMatch ? parseInt(failMatch[1], 10) : (res.status === 0 ? 0 : 1),
            durationMs: Date.now() - t0,
            output: out
        };
    }

    private sourceFiles(repoDir: string, subdirs: string[]): string[] {
        const out: string[] = [];
        for (const sub of subdirs) {
            const dir = path.join(repoDir, sub);
            if (!fs.existsSync(dir)) continue;
            const walk = (d: string, depth = 0) => {
                if (depth > 4) return;
                for (const e of fs.readdirSync(d, { withFileTypes: true })) {
                    if (e.name === 'node_modules' || e.name.startsWith('.')) continue;
                    const p = path.join(d, e.name);
                    if (e.isDirectory()) walk(p, depth + 1);
                    else if (/\.(js|mjs|cjs)$/.test(e.name) && !/\.(min|test|spec|d)\./.test(e.name)) out.push(p);
                }
            };
            walk(dir);
        }
        return out;
    }

    /**
     * Instrumente les sources, exécute LA SUITE DE TESTS DU PROJET, récupère
     * la base de rejeu, puis restaure les sources. Les tests eux-mêmes sont la
     * charge : c'est le levier identifié en v43 comme dominant.
     */
    public captureViaTests(repoDir: string, runner: TestRunner, subdirs: string[]):
        { captured: CapturedFunction[]; instrumented: number; suite: SuiteResult; restored: boolean } {
        const files = this.sourceFiles(repoDir, subdirs);
        const backups = new Map<string, string>();
        let instrumented = 0;
        for (const f of files) {
            const text = fs.readFileSync(f, 'utf-8');
            if (text.length > 400_000) continue;
            const rel = path.relative(repoDir, f);
            const { code, stats } = this.instrumenter.instrument(text, rel);
            if (stats.instrumented === 0) continue;
            backups.set(f, text);
            fs.writeFileSync(f, RECORDER_RUNTIME + '\n' + code);
            instrumented += stats.instrumented;
        }
        const dumpPrefix = path.join(os.tmpdir(), `nr_dump_${Date.now()}_${Math.random().toString(36).slice(2)}`);
        const suite = this.runSuite(repoDir, runner, { NEURALYS_DUMP: dumpPrefix });

        // Fusion des vidages : certains lanceurs (node --test) exécutent un
        // processus par fichier de test, chacun produisant sa propre capture.
        const merged = new Map<string, CapturedFunction>();
        const dir = path.dirname(dumpPrefix), base = path.basename(dumpPrefix);
        for (const f of fs.readdirSync(dir).filter(x => x.startsWith(base))) {
            const full = path.join(dir, f);
            try {
                for (const r of JSON.parse(fs.readFileSync(full, 'utf-8'))) {
                    const cur = merged.get(r.id);
                    if (!cur) {
                        merged.set(r.id, {
                            id: r.id, file: r.id.split('#')[0], name: r.id.split('#')[1] || '?', kind: r.kind,
                            calls: r.calls, totalCalls: r.totalCalls, totalMs: r.totalMs,
                            mutatesArgs: r.mutatesArgs, mutatesThis: r.mutatesThis, deterministic: r.deterministic
                        });
                    } else {
                        cur.totalCalls += r.totalCalls;
                        cur.totalMs += r.totalMs;
                        cur.mutatesArgs = cur.mutatesArgs || r.mutatesArgs;
                        cur.mutatesThis = cur.mutatesThis || r.mutatesThis;
                        cur.deterministic = cur.deterministic && r.deterministic;
                        for (const c of r.calls) if (cur.calls.length < 40) cur.calls.push(c);
                    }
                }
            } catch { /* vidage partiel */ }
            try { fs.unlinkSync(full); } catch { /* déjà supprimé */ }
        }
        const captured: CapturedFunction[] = [...merged.values()];
        for (const [f, text] of backups) fs.writeFileSync(f, text);
        return { captured, instrumented, suite, restored: true };
    }

    /** Rejeu : mêmes sorties que celles observées pendant les tests du projet. */
    /**
     * Rejeu isolé : PRÉ-FILTRE, pas verdict final. Une fonction qui dépend de
     * son module (expression régulière, table, import) ne peut pas être
     * évaluée hors contexte — l'issue est alors « non concluant », et c'est la
     * suite de tests du projet, oracle plus fort, qui tranche ensuite.
     * Seule une divergence AVÉRÉE bloque la mutation.
     */
    public replayProof(fnSource: string, fnName: string, calls: CapturedFunction['calls']):
        { verdict: 'prouvé' | 'réfuté' | 'non concluant'; checked: number } {
        const usable = calls.filter(isReplayableCall).filter(c => c.threw === null);
        if (usable.length === 0) return { verdict: 'non concluant', checked: 0 };
        let fn: Function;
        try { fn = new Function(`"use strict"; ${fnSource}; return ${fnName};`)(); }
        catch { return { verdict: 'non concluant', checked: 0 }; }
        let compared = 0;
        for (const c of usable) {
            let out: unknown, crashed = false;
            try { out = fn(...JSON.parse(JSON.stringify(c.args))); }
            catch { crashed = true; }
            // Une exception ici signale presque toujours une dépendance de
            // module manquante, pas une divergence sémantique.
            if (crashed) return { verdict: 'non concluant', checked: compared };
            compared++;
            if (JSON.stringify(out) !== JSON.stringify(c.result)) return { verdict: 'réfuté', checked: compared };
        }
        return { verdict: 'prouvé', checked: compared };
    }

    public candidates(source: string): { strategy: string; code: string }[] {
        const out: { strategy: string; code: string }[] = [];
        for (const rule of this.ast.getRules()) {
            try { const m = rule.apply(source); if (m && m !== source) out.push({ strategy: rule.name, code: m }); }
            catch { /* inapplicable */ }
        }
        try { for (const m of new CallerOptimizer(this.purity).mutate(source)) out.push({ strategy: m.strategy, code: m.code }); }
        catch { /* aucun site */ }
        return out;
    }

    private findFunction(fileText: string, name: string): string | null {
        try {
            const sf = this.project.createSourceFile(`f_${Math.random().toString(36).slice(2)}.ts`, fileText, { overwrite: true });
            const fn = sf.getFunctions().find(f => f.getName() === name);
            const src = fn ? fn.getText() : null;
            this.project.removeSourceFile(sf);
            return src;
        } catch { return null; }
    }

    /**
     * Mesure PAR FONCTION, dans son module réel, en rejouant le corpus capturé.
     * La durée de la suite de tests serait un proxy inutilisable : elle est
     * dominée par le démarrage du processus et le chargement des fichiers, la
     * fonction mutée n'y pèse que quelques microsecondes. Mesurer la suite
     * donnerait du bruit (observé : de −6,3 % à +4,7 % sans rapport avec la
     * mutation). On mesure donc l'appel lui-même, sur les arguments réellement
     * observés pendant les tests.
     */
    private benchInModule(repoDir: string, fnName: string, calls: CapturedFunction['calls'], samples = 5): number | null {
        const usable = calls.filter(isReplayableCall).filter(c => c.threw === null).slice(0, 25);
        if (usable.length === 0) return null;
        const corpus = path.join(os.tmpdir(), `nr_bench_${Date.now()}_${Math.random().toString(36).slice(2)}.json`);
        fs.writeFileSync(corpus, JSON.stringify(usable.map(c => c.args)));
        const script = `
import { readFileSync } from 'node:fs';
const corpus = JSON.parse(readFileSync(${JSON.stringify(corpus)}, 'utf-8'));
const mod = await import(${JSON.stringify(path.join(repoDir, 'index.js'))});
const fn = mod[${JSON.stringify(fnName)}] || (mod.default && mod.default[${JSON.stringify(fnName)}]);
if (typeof fn !== 'function') { console.log('NA'); process.exit(0); }
const clone = (v) => JSON.parse(JSON.stringify(v));
for (let w = 0; w < 40; w++) for (const a of corpus) { try { fn(...clone(a)); } catch {} }
let best = Infinity;
for (let s = 0; s < ${samples}; s++) {
  const fresh = corpus.map(clone);
  const t0 = process.hrtime.bigint();
  for (let r = 0; r < 60; r++) for (const a of fresh) { try { fn(...a); } catch {} }
  best = Math.min(best, Number(process.hrtime.bigint() - t0) / 1e6 / (60 * fresh.length));
}
console.log(String(best));
`;
        const f = path.join(os.tmpdir(), `nr_bench_${Date.now()}_${Math.random().toString(36).slice(2)}.mjs`);
        fs.writeFileSync(f, script);
        const res = spawnSync('node', [f], { cwd: repoDir, encoding: 'utf-8', timeout: 120000 });
        try { fs.unlinkSync(f); fs.unlinkSync(corpus); } catch { /* déjà nettoyé */ }
        const out = (res.stdout || '').trim().split('\n').pop() || '';
        const val = parseFloat(out);
        return Number.isFinite(val) ? val : null;
    }

    public async validate(repoName: string, repoDir: string, subdirs = ['src', 'lib', '.']): Promise<RepoValidation> {
        const v: RepoValidation = {
            repo: repoName, runner: null, baseline: null, instrumentedSuite: null,
            functionsInstrumented: 0, functionsCaptured: 0, functionsReplayable: 0,
            hotspots: [], mutations: [], survivingMutations: 0, pullRequestBranch: null, notes: []
        };

        v.runner = this.discoverRunner(repoDir);
        if (!v.runner) { v.notes.push('lanceur de tests non reconnu'); return v; }

        v.baseline = this.runSuite(repoDir, v.runner);
        if (!v.baseline.ok) { v.notes.push(`suite rouge avant toute intervention (${v.baseline.failed} échecs) — dépôt écarté`); return v; }

        const cap = this.captureViaTests(repoDir, v.runner, subdirs);
        v.functionsInstrumented = cap.instrumented;
        v.instrumentedSuite = cap.suite;
        v.functionsCaptured = cap.captured.length;
        v.functionsReplayable = cap.captured.filter(f => f.calls.some(isReplayableCall)).length;
        if (!cap.suite.ok) v.notes.push('la suite échoue SOUS instrumentation — capture jugée non fiable pour ce dépôt');

        v.hotspots = cap.captured
            .map(f => ({ id: f.id, calls: f.totalCalls, ms: f.totalMs }))
            .sort((a, b) => b.ms - a.ms).slice(0, 15);

        for (const h of v.hotspots) {
            const [rel, fnName] = h.id.split('#');
            const abs = path.join(repoDir, rel);
            if (!fs.existsSync(abs) || !fnName) continue;
            const original = fs.readFileSync(abs, 'utf-8');
            const fnSource = this.findFunction(original, fnName);
            if (!fnSource) continue;
            const rec = cap.captured.find(f => f.id === h.id)!;

            for (const cand of this.candidates(fnSource)) {
                const proof = this.replayProof(cand.code, fnName, rec.calls);
                const outcome: MutationOutcome = {
                    file: rel, fn: fnName, strategy: cand.strategy,
                    replayVerdict: proof.verdict,
                    replayProven: proof.verdict === 'prouvé', replayChecked: proof.checked,
                    suitePassed: false, suiteDetail: '', improvementPct: null, accepted: false
                };
                // Seule une réfutation bloque : le pré-filtre ne peut pas
                // disqualifier une mutation qu'il n'a pas su évaluer.
                if (proof.verdict === 'réfuté') { v.mutations.push(outcome); continue; }

                // LE test : la suite complète du projet, mutation en place
                try {
                    fs.writeFileSync(abs, original.replace(fnSource, cand.code));
                    const after = this.runSuite(repoDir, v.runner!);
                    outcome.suitePassed = after.ok && after.failed === 0 && after.passed >= v.baseline!.passed;
                    outcome.suiteDetail = `${after.passed} réussis / ${after.failed} échoués (référence : ${v.baseline!.passed})`;
                    if (outcome.suitePassed) {
                        const withMut = this.benchInModule(repoDir, fnName, rec.calls);
                        fs.writeFileSync(abs, original);
                        const base = this.benchInModule(repoDir, fnName, rec.calls);
                        outcome.improvementPct = (withMut !== null && base !== null && base > 0)
                            ? (base - withMut) / base * 100 : null;
                        v.survivingMutations++;
                        // Survivre à la CI prouve la CORRECTION, pas la
                        // performance. Deux des mutations survivantes se sont
                        // révélées être des régressions (−11,6 % et −4,0 %) :
                        // l'acceptation exige donc les deux preuves.
                        outcome.accepted = outcome.improvementPct !== null && outcome.improvementPct > 2;
                    }
                } catch (e: any) {
                    outcome.suiteDetail = `erreur : ${e.message.slice(0, 80)}`;
                } finally {
                    fs.writeFileSync(abs, original);
                }
                v.mutations.push(outcome);
            }
        }
        return v;
    }
}
