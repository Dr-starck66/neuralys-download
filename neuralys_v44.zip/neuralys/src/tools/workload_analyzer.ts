import * as fs from 'fs';
import * as path from 'path';
import * as os from 'os';
import { spawnSync } from 'child_process';

/**
 * ═══ ÉVOLUTION PILOTÉE PAR LA CHARGE RÉELLE ═════════════════════════════
 *
 * Pourquoi cette architecture remplace la précédente.
 *
 * Mesure préalable sur cinq projets réels (lodash, acorn, astring, express,
 * et le code de Neuralys lui-même) : **4 fonctions éligibles sur 784, soit
 * 0,5 %**. Les blocages dominants, dans l'ordre :
 *   1. arité ≠ 1        (lodash : 147 fonctions à 2 arguments, 84 à 3)
 *   2. appels externes   (143 : la fonction appelle d'autres fonctions du module)
 *   3. méthodes de classe (astring : 61, Neuralys : 146)
 *
 * Ces trois blocages ont une cause unique : le harnais SYNTHÉTISE les entrées
 * à partir d'une hypothèse de type (`f(number[]) → valeur`). Toute fonction
 * qui n'entre pas dans ce moule est écartée.
 *
 * L'architecture correcte inverse la dépendance : au lieu de deviner les
 * entrées, on les ENREGISTRE pendant que le projet s'exécute réellement.
 * Un corpus d'appels observés (arguments, résultat) fournit d'un coup :
 *   • la charge de benchmark — distribution réelle, aucune hypothèse ;
 *   • l'oracle d'équivalence — entrées réelles et sorties attendues réelles ;
 *   • le profil de fréquence — le nombre d'appels observés EST la mesure
 *     d'importance, pas une heuristique statique.
 *
 * Les quatre blocages disparaissent ensemble : l'arité est celle des appels
 * observés, les types sont ceux des valeurs observées, les appels externes
 * fonctionnent puisque la fonction s'exécute dans son module réel, et une
 * méthode de classe est un appel comme un autre (le receveur est enregistré).
 */

export interface RecordedCall {
    args: unknown[];
    result: unknown;
    threw: string | null;
    durationMs: number;
}

export interface FunctionRecording {
    name: string;
    calls: RecordedCall[];
    totalCalls: number;      // appels observés (peut dépasser le nombre conservé)
    totalSelfMs: number;
    meanSelfMs: number;
    /** Aucun argument observé n'a été modifié par l'appel. */
    observedNonMutating: boolean;
    /** Mêmes arguments observés → toujours même résultat. */
    observedDeterministic: boolean;
    /** Conjonction des deux : condition nécessaire pour hisser ou factoriser un appel. */
    observedPure: boolean;
}

export interface HotspotReport {
    module: string;
    driver: string;
    functions: FunctionRecording[];
    /** Part du temps total passée dans chaque fonction — le vrai classement. */
    ranked: { name: string; calls: number; totalMs: number; shareOfTotal: number }[];
    totalMs: number;
}

const MAX_CALLS_PER_FN = 60;
const MAX_ARG_BYTES = 4_000_000;

/** Clone défensif : les arguments peuvent être mutés après l'appel. */
function safeClone(v: unknown): unknown {
    try {
        const json = JSON.stringify(v);
        if (json === undefined) return undefined;
        if (json.length > MAX_ARG_BYTES) return '__NEURALYS_TOO_LARGE__';
        return JSON.parse(json);
    } catch {
        return '__NEURALYS_UNSERIALIZABLE__';
    }
}

export function isReplayable(call: RecordedCall): boolean {
    const bad = (v: unknown): boolean =>
        v === '__NEURALYS_TOO_LARGE__' || v === '__NEURALYS_UNSERIALIZABLE__' ||
        typeof v === 'function' || (typeof v === 'object' && v !== null && Object.keys(v as object).length === 0 && !Array.isArray(v));
    return !call.args.some(bad) && !bad(call.result) && call.threw === null;
}

/**
 * Enregistre les appels aux fonctions exportées d'un module CommonJS pendant
 * l'exécution d'un scénario réel (driver). L'instrumentation est un
 * enveloppement de la table d'exports : aucun code source n'est modifié, le
 * module s'exécute avec ses vraies dépendances.
 */
export class CallRecorder {
    /**
     * @param modulePath module CommonJS à instrumenter (chemin résolu par require)
     * @param driverPath script qui exerce réellement le module
     */
    public record(modulePath: string, driverPath: string, timeoutMs = 120_000): HotspotReport {
        const outFile = path.join(os.tmpdir(), `neuralys_rec_${Date.now()}.json`);
        const harness = `
const path = require('path');
const target = require(${JSON.stringify(modulePath)});
const recordings = new Map();
const MAX = ${MAX_CALLS_PER_FN};

function clone(v) {
  try {
    const j = JSON.stringify(v);
    if (j === undefined) return undefined;
    if (j.length > ${MAX_ARG_BYTES}) return '__NEURALYS_TOO_LARGE__';
    return JSON.parse(j);
  } catch (e) { return '__NEURALYS_UNSERIALIZABLE__'; }
}

function wrap(obj, name, fn) {
  return function (...args) {
    const rec = recordings.get(name) || { name, calls: [], totalCalls: 0, totalSelfMs: 0, mutating: false, nondet: false, seen: new Map() };
    recordings.set(name, rec);
    // État des arguments AVANT l'appel : c'est la comparaison avant/après qui
    // établit empiriquement la non-mutation. Sans cette preuve, aucun appel
    // ne pourra être hissé ni factorisé.
    const before = args.map(clone);
    const t0 = process.hrtime.bigint();
    let result, threw = null;
    try { result = fn.apply(this, args); }
    catch (e) { threw = (e && e.constructor && e.constructor.name) || 'Error'; }
    const dt = Number(process.hrtime.bigint() - t0) / 1e6;
    const after = args.map(clone);
    if (JSON.stringify(before) !== JSON.stringify(after)) rec.mutating = true;
    if (!threw) {
      const key = JSON.stringify(before);
      if (key !== undefined && key.length < 100000) {
        const prev = rec.seen.get(key);
        const out = JSON.stringify(clone(result));
        if (prev !== undefined && prev !== out) rec.nondet = true;
        else if (prev === undefined && rec.seen.size < 200) rec.seen.set(key, out);
      }
    }
    rec.totalCalls++;
    rec.totalSelfMs += dt;
    if (rec.calls.length < MAX) {
      rec.calls.push({ args: before, result: clone(result), threw, durationMs: dt });
    }
    if (threw) throw Object.assign(new Error('replayed'), { name: threw });
    return result;
  };
}

for (const key of Object.keys(target)) {
  const v = target[key];
  if (typeof v === 'function') {
    try { target[key] = wrap(target, key, v); } catch (e) { /* propriété non inscriptible */ }
  }
}

const t0 = process.hrtime.bigint();
try { require(${JSON.stringify(driverPath)}); }
catch (e) { console.error('[driver]', e && e.message); }
const totalMs = Number(process.hrtime.bigint() - t0) / 1e6;

const functions = [...recordings.values()].map(r => ({
  name: r.name, calls: r.calls, totalCalls: r.totalCalls,
  totalSelfMs: r.totalSelfMs, meanSelfMs: r.totalCalls ? r.totalSelfMs / r.totalCalls : 0,
  observedNonMutating: !r.mutating,
  observedDeterministic: !r.nondet,
  observedPure: !r.mutating && !r.nondet
}));
require('fs').writeFileSync(${JSON.stringify(outFile)}, JSON.stringify({ functions, totalMs }));
`;
        const harnessFile = path.join(os.tmpdir(), `neuralys_harness_${Date.now()}.cjs`);
        fs.writeFileSync(harnessFile, harness);
        const res = spawnSync('node', [harnessFile], { timeout: timeoutMs, encoding: 'utf-8' });
        fs.unlinkSync(harnessFile);

        if (!fs.existsSync(outFile)) {
            throw new Error(`Enregistrement impossible: ${(res.stderr || '').slice(0, 300)}`);
        }
        const raw = JSON.parse(fs.readFileSync(outFile, 'utf-8'));
        fs.unlinkSync(outFile);

        const functions: FunctionRecording[] = raw.functions;
        const totalMs = functions.reduce((a, f) => a + f.totalSelfMs, 0) || raw.totalMs || 1;
        const ranked = functions
            .map(f => ({ name: f.name, calls: f.totalCalls, totalMs: f.totalSelfMs, shareOfTotal: f.totalSelfMs / totalMs }))
            .sort((a, b) => b.totalMs - a.totalMs);

        return { module: modulePath, driver: driverPath, functions, ranked, totalMs };
    }
}

/**
 * Oracle et banc de mesure fondés sur la charge enregistrée.
 * Équivalence = mêmes sorties sur les appels RÉELLEMENT observés.
 * Mesure = temps de rejeu de ces mêmes appels.
 * Aucune synthèse d'entrées, donc aucune hypothèse de type.
 */
export class WorkloadOracle {
    public replayEquivalence(fnSource: string, fnName: string, calls: RecordedCall[]):
        { equivalent: boolean; checked: number; counterexample?: unknown[] } {
        const replayable = calls.filter(isReplayable);
        if (replayable.length === 0) return { equivalent: false, checked: 0 };
        let fn: Function;
        try {
            fn = new Function(`"use strict"; ${fnSource}; return ${fnName};`)();
        } catch {
            return { equivalent: false, checked: 0 };
        }
        for (const c of replayable) {
            let out: unknown;
            try { out = fn(...JSON.parse(JSON.stringify(c.args))); }
            catch { return { equivalent: false, checked: replayable.length, counterexample: c.args }; }
            if (JSON.stringify(out) !== JSON.stringify(c.result)) {
                return { equivalent: false, checked: replayable.length, counterexample: c.args };
            }
        }
        return { equivalent: true, checked: replayable.length };
    }

    public replayBenchmark(fnSource: string, fnName: string, calls: RecordedCall[], samples = 15): number[] {
        const replayable = calls.filter(isReplayable);
        const fn = new Function(`"use strict"; ${fnSource}; return ${fnName};`)();
        const payloads = replayable.map(c => JSON.parse(JSON.stringify(c.args)));
        for (let w = 0; w < 30; w++) for (const p of payloads) { try { fn(...JSON.parse(JSON.stringify(p))); } catch { /* ignoré */ } }
        const out: number[] = [];
        for (let s = 0; s < samples; s++) {
            const fresh = payloads.map(p => JSON.parse(JSON.stringify(p)));
            const t0 = process.hrtime.bigint();
            for (const p of fresh) { try { fn(...p); } catch { /* ignoré */ } }
            out.push(Number(process.hrtime.bigint() - t0) / 1e6 / Math.max(fresh.length, 1));
        }
        return out;
    }
}
