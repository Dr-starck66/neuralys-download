import { Project, SyntaxKind } from 'ts-morph';
import { ClaudeMutator } from '../llm/claude_mutator';

const MECHANISMS: Record<string, string> = {
    sort_idiom_recognition: "la double boucle de comparaison-échange adjacente (O(n²)) calcule exactement un tri croissant ; elle est remplacée par le TimSort natif du moteur (O(n log n)), mathématiquement équivalent pour des nombres",
    shift_to_index_pointer: "Array.shift() recopie tous les éléments restants à chaque appel (O(n) par défilement) ; un pointeur de tête lit le même élément en O(1) sans jamais déplacer le tableau",
    string_accumulation_to_join: "chaque `+=` sur une chaîne peut recopier l'accumulé ; pousser les fragments dans un tableau puis les joindre une seule fois produit la même chaîne avec une seule concaténation finale",
    indexof_to_set_lookup: "indexOf parcourt la chaîne à chaque test d'appartenance (O(k)) ; un Set pré-construit répond en O(1) par hachage, avec le même résultat booléen",
    loop_invariant_length_caching: "`.length` est relu à chaque itération alors que le tableau ne change pas de taille dans la boucle : sa valeur est invariante, donc hissée hors de la condition",
    common_subexpression_elimination: "le même accès élément est évalué plusieurs fois par itération ; il est calculé une fois et réutilisé — équivalence garantie car ni le tableau ni l'indice ne sont modifiés dans le corps",
    strength_reduction: "la multiplication entière par 2 est remplacée par un décalage de bit, opération identique sur les entiers",
    crossover_rule_union: "croisement génétique : les transformations gagnantes de deux lignées parentes sont composées sur le même code"
};

/**
 * Explication automatique. Deux niveaux, jamais de fiction :
 * 1. Mécanistique (déterministe) : le POURQUOI de chaque règle
 *    (invariant préservé) + les faits structurels mesurés sur le diff
 *    (boucles supprimées, delta de complexité cyclomatique, delta de
 *    taille). Toujours disponible.
 * 2. Narratif (optionnel) : reformulation par Claude, uniquement si un
 *    backend LLM est authentifié — sinon le niveau 1 est la réponse.
 */
export class Explainer {
    private project = new Project({ useInMemoryFileSystem: true });
    private claude = new ClaudeMutator();

    private structuralFacts(before: string, after: string) {
        const count = (code: string, kind: SyntaxKind) =>
            this.project.createSourceFile('x.ts', code, { overwrite: true }).getDescendantsOfKind(kind).length;
        const loops = (c: string) => count(c, SyntaxKind.ForStatement) + count(c, SyntaxKind.WhileStatement);
        const cx = (c: string) => (c.match(/\b(if|for|while|case|&&|\|\|)\b/g) || []).length + 1;
        return {
            loopsBefore: loops(before), loopsAfter: loops(after),
            complexityDelta: cx(after) - cx(before),
            sizeDelta: after.replace(/\s+/g, '').length - before.replace(/\s+/g, '').length
        };
    }

    public explain(before: string, after: string, lineage: string[], gainPct: number): string {
        const f = this.structuralFacts(before, after);
        const parts: string[] = [];
        for (const gene of lineage) {
            const base = gene.startsWith('llm:')
                ? `réécriture architecturale proposée par le modèle ${gene.slice(4)}, validée par fuzzing différentiel (l'équivalence est prouvée empiriquement, pas déclarée)`
                : MECHANISMS[gene] || gene;
            parts.push(`— ${gene} : ${base}.`);
        }
        const facts: string[] = [];
        if (f.loopsBefore > f.loopsAfter) facts.push(`${f.loopsBefore - f.loopsAfter} boucle(s) supprimée(s)`);
        if (f.complexityDelta !== 0) facts.push(`complexité cyclomatique ${f.complexityDelta > 0 ? '+' : ''}${f.complexityDelta}`);
        if (f.sizeDelta !== 0) facts.push(`taille ${f.sizeDelta > 0 ? '+' : ''}${f.sizeDelta} caractères`);
        return [
            `Gain mesuré : ${gainPct >= 0 ? '+' : ''}${gainPct.toFixed(1)}% de latence.`,
            ...parts,
            facts.length ? `Effets structurels : ${facts.join(', ')}.` : '',
            `L'équivalence comportementale est vérifiée par fuzzing différentiel (familles structurées + contre-exemples historiques) avant toute acceptation.`
        ].filter(Boolean).join('\n');
    }

    /** Narrative layer - only when an LLM backend is authenticated. */
    public async explainNarrative(before: string, after: string, lineage: string[], gainPct: number): Promise<string> {
        const mechanistic = this.explain(before, after, lineage, gainPct);
        const out = await this.claude.mutateRaw(
`Tu es un ingénieur compilateur. Reformule cette explication technique en 3 phrases claires pour un développeur, en français, sans rien inventer au-delà des faits fournis:\n\n${mechanistic}\n\nAvant:\n${before}\n\nAprès:\n${after}`, 0);
        return out || mechanistic;
    }
}
