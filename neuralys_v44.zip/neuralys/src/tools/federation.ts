import { KnowledgeBase } from '../memory/knowledge_base';

export interface FederationDelta {
    since: string;
    artifacts: Record<string, string>;
    mutations: any[];
    counterexamples: { signature: string; input_json: string; source_strategy: string }[];
}

/**
 * Federated evolution (network effect). Pull-based delta sync over the
 * REST API: a node pulls every mutation, artifact and counterexample a
 * peer recorded since a timestamp and merges them into its local KB.
 * Strategy priors and survival rates need no transfer - they are SQL
 * views over mutations, so they recompute locally after merge. Merge is
 * idempotent (content-addressed artifacts, UNIQUE counterexamples,
 * mutation dedup by (experiment, parent, child, strategy)).
 */
export class FederationSync {
    constructor(private kb: KnowledgeBase) {}

    public exportDelta(sinceIso: string): FederationDelta {
        const db = (this.kb as any).db;
        const mutations = db.prepare('SELECT * FROM mutations WHERE created_at > ? ORDER BY id').all(sinceIso);
        const counterexamples = db.prepare('SELECT signature, input_json, source_strategy FROM counterexamples WHERE created_at > ?').all(sinceIso);
        const artifacts: Record<string, string> = {};
        for (const m of mutations) {
            for (const h of [m.parent_hash, m.variant_hash]) {
                if (!artifacts[h]) {
                    const code = this.kb.getArtifact(h);
                    if (code) artifacts[h] = code;
                }
            }
        }
        return { since: sinceIso, artifacts, mutations, counterexamples };
    }

    public merge(delta: FederationDelta): { artifacts: number; mutations: number; counterexamples: number } {
        const db = (this.kb as any).db;
        let a = 0, m = 0, c = 0;
        for (const [hash, code] of Object.entries(delta.artifacts)) {
            if (KnowledgeBase.hashCode(code) !== hash) continue; // integrity: reject tampered artifacts
            this.kb.storeArtifact(code); a++;
        }
        const exists = db.prepare('SELECT 1 FROM mutations WHERE experiment_id=? AND parent_hash=? AND variant_hash=? AND strategy=?');
        for (const mu of delta.mutations) {
            if (exists.get(mu.experiment_id, mu.parent_hash, mu.variant_hash, mu.strategy)) continue;
            this.kb.recordMutation({
                experimentId: mu.experiment_id, generation: mu.generation, benchmarkId: mu.benchmark_id,
                category: mu.category, parentHash: mu.parent_hash, variantHash: mu.variant_hash,
                strategy: mu.strategy, accepted: !!mu.accepted, rejectionReason: mu.rejection_reason,
                latencyMean: mu.latency_mean, latencyImprovementPct: mu.latency_improvement_pct,
                memoryMb: mu.memory_mb, complexity: mu.complexity, pValue: mu.p_value,
                reasoning: mu.reasoning, signature: mu.signature, language: mu.language
            }); m++;
        }
        for (const ce of delta.counterexamples) {
            try { this.kb.storeCounterexample(ce.signature, JSON.parse(ce.input_json), ce.source_strategy); c++; } catch { /* skip */ }
        }
        return { artifacts: a, mutations: m, counterexamples: c };
    }

    /** Pull from a peer node's API and merge. */
    public async syncFromPeer(peerUrl: string, sinceIso: string = '1970-01-01') {
        const resp = await fetch(`${peerUrl}/federation/delta?since=${encodeURIComponent(sinceIso)}`);
        if (!resp.ok) throw new Error(`peer sync failed: HTTP ${resp.status}`);
        return this.merge(await resp.json() as FederationDelta);
    }
}
