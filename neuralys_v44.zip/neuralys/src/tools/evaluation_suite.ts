import * as fs from 'fs';
import * as path from 'path';
import { Project, SyntaxKind, Node } from 'ts-morph';
import { ASTMutator } from '../core/ast_mutator';
import { AlgorithmSpace, profileInputs } from '../core/algorithm_space';
import { CallerOptimizer, PurityEvidence } from '../core/caller_optimizer';
import { AdvancedSemanticGuardian } from '../validation/semantic_guardian';
import { SandboxRunner } from '../validation/sandbox_runner';

/**
 * ═══ CADRE D'ÉVALUATION REPRODUCTIBLE ═══════════════════════════════════
 *
 * Question scientifique : Neuralys améliore-t-il du logiciel de production,
 * de façon répétée, sur des bases de code sans lien entre elles ?
 *
 * Le protocole ne cherche pas à faire gagner le système. Il mesure, dépôt par
 * dépôt, ce qui se produit réellement à chaque étape du pipeline, et agrège
 * avec des intervalles de confiance. Un dépôt où rien n'est possible compte
 * autant qu'un dépôt où quelque chose l'est.
 *
 * Trois entonnoirs successifs, mesurés séparément parce qu'ils échouent pour
 * des raisons différentes :
 *   1. ANALYSABLE   — la fonction est parsée et inventoriée
 *   2. ÉVALUABLE    — le harnais peut l'exécuter (arité, types, autonomie)
 *   3. MUTABLE      — au moins un candidat est généré
 * Puis seulement : prouvé équivalent, mesuré, accepté.
 */

export interface RepoResult {
    repo: string;
    filesScanned: number;
    functionsAnalyzed: number;
    /** Fonctions contenant boucle ou récursion — points chauds potentiels. */
    hotspotsDetected: number;
    /** Fonctions que le harnais peut réellement exécuter. */
    functionsEvaluable: number;
    mutationsAttempted: number;
    /** Mutations effectivement soumises à l'oracle (fonction évaluable). */
    mutationsTested: number;
    mutationsProven: number;
    mutationsRejectedSemantic: number;
    mutationsRejectedPerformance: number;
    oracleFailures: number;
    mutationsAccepted: number;
    improvements: number[];      // gains en % des mutations acceptées
    /** Détail des mutations retenues — preuve concrète, pas seulement un compteur. */
    accepted: { fn: string; strategy: string; gainPct: number }[];
    pullRequests: number;
    errors: string[];
}

export interface AggregateResult {
    repos: RepoResult[];
    totals: {
        repos: number;
        functionsAnalyzed: number;
        hotspotsDetected: number;
        functionsEvaluable: number;
        mutationsAttempted: number;
        mutationsTested: number;
        mutationsProven: number;
        mutationsAccepted: number;
        oracleFailures: number;
        pullRequests: number;
    };
    rates: {
        evaluableRate: Proportion;
        mutationRate: Proportion;
        proofSuccessRate: Proportion;
        acceptanceRate: Proportion;
        reposWithAtLeastOneAcceptance: Proportion;
    };
    meanImprovementPct: { mean: number; ci95: [number, number]; n: number } | null;
    verdict: string;
}

export interface Proportion {
    successes: number;
    trials: number;
    rate: number;
    /** Intervalle de Wilson à 95 % — valide même pour 0 succès, contrairement à Wald. */
    ci95: [number, number];
}

/** Intervalle de Wilson : correct quand la proportion vaut 0 ou 1. */
export function wilson(successes: number, trials: number): Proportion {
    if (trials === 0) return { successes, trials, rate: 0, ci95: [0, 0] };
    const z = 1.959963985;
    const p = successes / trials;
    const denom = 1 + z * z / trials;
    const centre = p + z * z / (2 * trials);
    const margin = z * Math.sqrt(p * (1 - p) / trials + z * z / (4 * trials * trials));
    return {
        successes, trials, rate: p,
        ci95: [Math.max(0, (centre - margin) / denom), Math.min(1, (centre + margin) / denom)]
    };
}

/** IC 95 % par bootstrap percentile — aucune hypothèse de normalité. */
export function bootstrapCI(values: number[], iterations = 4000, seed = 20260726): { mean: number; ci95: [number, number]; n: number } {
    const n = values.length;
    const mean = values.reduce((a, b) => a + b, 0) / n;
    let s = seed >>> 0;
    const rnd = () => { s = (Math.imul(s, 1103515245) + 12345) & 0x7fffffff; return s / 0x7fffffff; };
    const means: number[] = [];
    for (let it = 0; it < iterations; it++) {
        let acc = 0;
        for (let i = 0; i < n; i++) acc += values[Math.floor(rnd() * n)];
        means.push(acc / n);
    }
    means.sort((a, b) => a - b);
    return { mean, ci95: [means[Math.floor(0.025 * iterations)], means[Math.floor(0.975 * iterations)]], n };
}

export class EvaluationSuite {
    private ast = new ASTMutator();
    private algo = new AlgorithmSpace();
    private guardian = new AdvancedSemanticGuardian();
    private runner = new SandboxRunner();
    private project = new Project({ useInMemoryFileSystem: true });

    constructor(private purity: PurityEvidence = { pure: new Set(), impure: new Set() }) {}

    private files(dir: string, acc: string[] = [], depth = 0): string[] {
        if (depth > 6) return acc;
        let entries: fs.Dirent[];
        try { entries = fs.readdirSync(dir, { withFileTypes: true }); } catch { return acc; }
        for (const e of entries) {
            if (e.name === 'node_modules' || e.name.startsWith('.')) continue;
            const p = path.join(dir, e.name);
            if (e.isDirectory()) this.files(p, acc, depth + 1);
            else if (/\.(js|mjs|cjs)$/.test(e.name) && !/\.(min|test|spec)\./.test(e.name)) acc.push(p);
        }
        return acc;
    }

    /**
     * Une fonction est ÉVALUABLE si le harnais peut l'exécuter isolément :
     * un paramètre, aucune dépendance externe non modélisée, corps sans état.
     * Ce filtre est la limite dominante mesurée depuis la v31 — il est donc
     * compté explicitement plutôt que caché dans un taux global.
     */
    private isEvaluable(source: string, name: string): boolean {
        if (!new RegExp(`function\\s+${name}\\s*\\(\\s*\\w+\\s*\\)`).test(source)) return false;
        if (/\bthis\b|\bawait\b|\brequire\(|\bprocess\.|\bconsole\.|\bnew\s+[A-Z]/.test(source)) return false;
        const externalCall = /(?<![.\w])([a-z_]\w*)\s*\(/g;
        const allowed = new Set(['if', 'for', 'while', 'switch', 'return', 'typeof', 'catch', 'function', name]);
        let m: RegExpExecArray | null;
        while ((m = externalCall.exec(source)) !== null) {
            if (!allowed.has(m[1])) return false;
        }
        return true;
    }

    public async evaluateRepo(repo: string, dir: string, maxFiles = 400): Promise<RepoResult> {
        const r: RepoResult = {
            repo, filesScanned: 0, functionsAnalyzed: 0, hotspotsDetected: 0, functionsEvaluable: 0,
            mutationsAttempted: 0, mutationsTested: 0, mutationsProven: 0, mutationsRejectedSemantic: 0,
            mutationsRejectedPerformance: 0, oracleFailures: 0, mutationsAccepted: 0,
            improvements: [], accepted: [], pullRequests: 0, errors: []
        };
        const caller = new CallerOptimizer(this.purity);
        const mean = (a: number[]) => a.reduce((x, y) => x + y, 0) / a.length;

        for (const file of this.files(dir).slice(0, maxFiles)) {
            let text: string;
            try { text = fs.readFileSync(file, 'utf-8'); } catch { continue; }
            if (text.length > 400_000) continue;
            r.filesScanned++;
            let sf;
            try { sf = this.project.createSourceFile('e.js', text, { overwrite: true }); } catch { continue; }

            for (const fn of sf.getFunctions()) {
                const name = fn.getName();
                if (!name) continue;
                const source = fn.getText();
                r.functionsAnalyzed++;
                if (/\bfor\s*\(|\bwhile\s*\(|\bdo\s*\{/.test(source) || new RegExp(`\\b${name}\\s*\\(`).test(source.slice(source.indexOf('{')))) {
                    r.hotspotsDetected++;
                }

                // Candidats : règles AST + espace algorithmique + niveau appelant
                const candidates: { strategy: string; code: string }[] = [];
                for (const rule of this.ast.getRules()) {
                    try { const m = rule.apply(source); if (m && m !== source) candidates.push({ strategy: rule.name, code: m }); } catch { /* inapplicable */ }
                }
                try { for (const c of this.algo.generate(source, profileInputs([[1, 2, 3]]))) candidates.push({ strategy: c.strategy, code: c.code }); } catch { /* pas d'intention */ }
                try { for (const c of caller.mutate(source)) candidates.push({ strategy: c.strategy, code: c.code }); } catch { /* pas de site */ }

                if (candidates.length === 0) continue;
                r.mutationsAttempted += candidates.length;

                const evaluable = this.isEvaluable(source, name);
                if (!evaluable) continue;
                r.functionsEvaluable++;

                // Harnais : la fonction est renommée pour le banc de mesure
                const harnessed = source.replace(new RegExp(`function\\s+${name}\\b`), 'function processPayload');
                let baseline: number[];
                try {
                    const s = this.runner.executeCodeBenchmark(harnessed, 12);
                    if (s.some(x => x.testPassRate === 0)) continue;
                    baseline = s.map(x => x.latencyMs);
                } catch { continue; }

                for (const cand of candidates) {
                    r.mutationsTested++;
                    const mutated = cand.code.replace(new RegExp(`function\\s+${name}\\b`), 'function processPayload');
                    let verdict;
                    try { verdict = await this.guardian.evaluateEquivalence(harnessed, mutated); }
                    catch (e: any) { r.errors.push(`${name}/${cand.strategy}: ${e.message.slice(0, 60)}`); continue; }

                    if (!verdict.passed) {
                        r.mutationsRejectedSemantic++;
                        if (verdict.counterexample !== undefined) r.oracleFailures++;
                        continue;
                    }
                    r.mutationsProven++;
                    let lat: number[];
                    try { lat = this.runner.executeCodeBenchmark(mutated, 12).map(x => x.latencyMs); }
                    catch { continue; }
                    const gain = (mean(baseline) - mean(lat)) / mean(baseline) * 100;
                    if (gain > 2) {
                        r.mutationsAccepted++; r.improvements.push(gain); r.pullRequests++;
                        r.accepted.push({ fn: name, strategy: cand.strategy, gainPct: gain });
                    }
                    else r.mutationsRejectedPerformance++;
                }
            }
            this.project.removeSourceFile(sf);
        }
        return r;
    }

    public aggregate(repos: RepoResult[]): AggregateResult {
        const sum = (f: (r: RepoResult) => number) => repos.reduce((a, r) => a + f(r), 0);
        const totals = {
            repos: repos.length,
            functionsAnalyzed: sum(r => r.functionsAnalyzed),
            hotspotsDetected: sum(r => r.hotspotsDetected),
            functionsEvaluable: sum(r => r.functionsEvaluable),
            mutationsAttempted: sum(r => r.mutationsAttempted),
            mutationsTested: sum(r => r.mutationsTested),
            mutationsProven: sum(r => r.mutationsProven),
            mutationsAccepted: sum(r => r.mutationsAccepted),
            oracleFailures: sum(r => r.oracleFailures),
            pullRequests: sum(r => r.pullRequests)
        };
        const allImprovements = repos.flatMap(r => r.improvements);
        const reposWithAcceptance = repos.filter(r => r.mutationsAccepted > 0).length;

        const rates = {
            evaluableRate: wilson(totals.functionsEvaluable, totals.functionsAnalyzed),
            mutationRate: wilson(totals.mutationsAttempted, totals.functionsAnalyzed),
            // Dénominateur = mutations réellement soumises à l'oracle. Utiliser
            // « tentées » sous-estimerait le taux : la majorité des candidats
            // portent sur des fonctions que le harnais ne peut pas exécuter,
            // elles n'ont jamais eu l'occasion d'être réfutées.
            proofSuccessRate: wilson(totals.mutationsProven, Math.max(totals.mutationsTested, 0)),
            acceptanceRate: wilson(totals.mutationsAccepted, Math.max(totals.mutationsProven, 0)),
            reposWithAtLeastOneAcceptance: wilson(reposWithAcceptance, repos.length)
        };

        const rr = rates.reposWithAtLeastOneAcceptance;
        const verdict = reposWithAcceptance === 0
            ? `NON. Aucun des ${repos.length} dépôts n'a reçu de mutation acceptée. Borne supérieure à 95 % du taux de dépôts améliorables : ${(rr.ci95[1] * 100).toFixed(1)} %.`
            : `Améliorations sur ${reposWithAcceptance}/${repos.length} dépôts (IC 95 % : ${(rr.ci95[0] * 100).toFixed(1)}–${(rr.ci95[1] * 100).toFixed(1)} %).`;

        return {
            repos, totals, rates,
            meanImprovementPct: allImprovements.length >= 2 ? bootstrapCI(allImprovements) : null,
            verdict
        };
    }
}
