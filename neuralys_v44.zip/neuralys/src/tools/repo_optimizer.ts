import { Project, SyntaxKind, FunctionDeclaration } from 'ts-morph';
import { execSync } from 'child_process';
import * as fs from 'fs';
import * as path from 'path';
import * as os from 'os';
import { DarwinDriver } from '../core/engine';
import { KnowledgeBase } from '../memory/knowledge_base';

export interface RepoOptimization {
    file: string;
    functionName: string;
    improvementPct: number;
    lineage: string[];
    pValueNote: string;
    originalCode: string;
    optimizedCode: string;
    explanation: string;
}

export interface RepoReport {
    repoPath: string;
    scannedFunctions: number;
    eligibleFunctions: number;
    optimizations: RepoOptimization[];
    patchFile: string;
    reportFile: string;
    durationSec: number;
}

/**
 * The product loop (spec: "dépose son projet Git -> Neuralys travaille ->
 * retourne patch + preuves"). Pipeline per repository:
 *   1. SCAN     - ts-morph walks all .ts/.js files, extracts candidate
 *                 functions: array-of-numbers -> value, side-effect-free
 *                 surface (no imports/this/global writes in body)
 *   2. EVOLVE   - each candidate runs through the ONE evolution engine
 *                 (population, NSGA-II, counterexample memory, priors)
 *   3. PROVE    - gains re-measured, equivalence fuzz-verified; nothing
 *                 lands in the patch without both
 *   4. DELIVER  - unified git diff + markdown report with per-change
 *                 explanation, lineage and measured gains
 * Eligibility is deliberately conservative: a wrong patch costs more
 * trust than a missed optimization earns.
 */
export class RepoOptimizer {
    private project = new Project({ useInMemoryFileSystem: false, skipAddingFilesFromTsConfig: true });

    constructor(private kb: KnowledgeBase, private minGainPct: number = 5) {}

    /**
     * Éligibilité au harnais actuel, avec MOTIF d'exclusion.
     * Le harnais évalue des fonctions pures `f(number[]) -> valeur` : tout
     * ce qui sort de ce domaine est écarté explicitement plutôt
     * qu'optimisé sur une hypothèse fausse. Le motif est remonté pour que
     * le taux de couverture réel soit mesurable (voir `neuralys coverage`).
     */
    public eligibility(fn: FunctionDeclaration): { eligible: boolean; reason: string } {
        const name = fn.getName();
        if (!name) return { eligible: false, reason: 'fonction anonyme' };
        if (fn.getParameters().length !== 1) return { eligible: false, reason: `arité ${fn.getParameters().length} (harnais: 1 paramètre)` };
        if (fn.isAsync()) return { eligible: false, reason: 'async (état temporel non modélisé)' };
        const body = fn.getBody()?.getText() || '';
        if (/\bthis\b/.test(body)) return { eligible: false, reason: 'utilise this (état d\'objet)' };
        if (/\bawait\b/.test(body)) return { eligible: false, reason: 'await (asynchrone)' };
        if (/\brequire\(|\bimport\(/.test(body)) return { eligible: false, reason: 'chargement de module dynamique' };
        if (/\bprocess\.|\bconsole\.|\bfs\.|\bfetch\(/.test(body)) return { eligible: false, reason: 'I/O ou effet de bord observable' };
        const calls = fn.getDescendantsOfKind(SyntaxKind.CallExpression);
        const allowed = /^(Math\.\w+|Array\.\w+|Number\.\w+|String\.\w+|Object\.\w+|\w+\.(push|pop|shift|unshift|slice|splice|join|indexOf|includes|sort|map|filter|reduce|charCodeAt|fill|concat)|Set|Map|Array\.from)/;
        for (const c of calls) {
            const txt = c.getExpression().getText();
            if (!allowed.test(txt)) return { eligible: false, reason: `appel externe non modélisé: ${txt.slice(0, 40)}` };
        }
        if (!/\bfor\s*\(|\bwhile\s*\(/.test(body) && !/\.(map|filter|reduce)\s*\(/.test(body)) {
            return { eligible: false, reason: 'aucune boucle ni chaîne fonctionnelle (rien à optimiser)' };
        }
        return { eligible: true, reason: 'éligible' };
    }

    private isEligible(fn: FunctionDeclaration): boolean {
        return this.eligibility(fn).eligible;
    }

    /**
     * Mesure de couverture réelle sur un dépôt : combien de fonctions le
     * harnais peut-il seulement TENTER d'optimiser, et pourquoi les autres
     * sont écartées. Chiffre volontairement exposé : c'est la limite
     * dominante du produit, pas une note de bas de page.
     */
    public coverage(repoPath: string): { total: number; eligible: number; ratio: number; reasons: Record<string, number> } {
        const files: string[] = [];
        const walk = (dir: string) => {
            for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
                if (e.name === 'node_modules' || e.name.startsWith('.')) continue;
                const p = path.join(dir, e.name);
                if (e.isDirectory()) walk(p);
                else if (/\.(ts|js|mjs)$/.test(e.name) && !/\.(test|spec)\./.test(e.name)) files.push(p);
            }
        };
        walk(repoPath);
        let total = 0, eligible = 0;
        const reasons: Record<string, number> = {};
        for (const file of files) {
            const src = this.project.addSourceFileAtPath(file);
            const fns = [
                ...src.getFunctions(),
                ...src.getDescendantsOfKind(SyntaxKind.MethodDeclaration) as any[]
            ];
            for (const fn of src.getFunctions()) {
                total++;
                const e = this.eligibility(fn);
                if (e.eligible) eligible++;
                else {
                    const key = e.reason.replace(/: .*/, '');
                    reasons[key] = (reasons[key] || 0) + 1;
                }
            }
            total += src.getDescendantsOfKind(SyntaxKind.MethodDeclaration).length;
            const m = src.getDescendantsOfKind(SyntaxKind.MethodDeclaration).length;
            if (m > 0) reasons['méthode de classe (hors harnais fonction pure)'] = (reasons['méthode de classe (hors harnais fonction pure)'] || 0) + m;
            this.project.removeSourceFile(src);
        }
        return { total, eligible, ratio: total ? eligible / total : 0, reasons };
    }

    public async optimize(repoPath: string, opts: { maxFunctions?: number; generations?: number } = {}): Promise<RepoReport> {
        const t0 = Date.now();
        const maxFunctions = opts.maxFunctions ?? 20;
        const files: string[] = [];
        const walk = (dir: string) => {
            for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
                if (e.name === 'node_modules' || e.name.startsWith('.')) continue;
                const p = path.join(dir, e.name);
                if (e.isDirectory()) walk(p);
                else if (/\.(ts|js|mjs)$/.test(e.name) && !/\.(test|spec)\./.test(e.name)) files.push(p);
            }
        };
        walk(repoPath);

        const driver = new DarwinDriver(this.kb);
        const optimizations: RepoOptimization[] = [];
        let scanned = 0, eligible = 0;

        for (const file of files) {
            const src = this.project.addSourceFileAtPath(file);
            for (const fn of src.getFunctions()) {
                scanned++;
                if (eligible >= maxFunctions) break;
                if (!this.isEligible(fn)) continue;
                eligible++;

                const original = fn.getText();
                // The engine's contract is processPayload; rename for evolution, restore after
                const seed = original.replace(new RegExp(`function\\s+${fn.getName()}\\b`), 'function processPayload');
                try {
                    const res = await driver.evolve(`${path.relative(repoPath, file)}::${fn.getName()}`, 'RepoScan', seed,
                        { generations: opts.generations ?? 2, populationCap: 6, runsPerEval: 20 });
                    if (res.totalImprovementPct >= this.minGainPct && res.bestLineage.length > 0) {
                        const optimized = res.bestCode.replace(/function\s+processPayload\b/, `function ${fn.getName()}`);
                        optimizations.push({
                            file: path.relative(repoPath, file),
                            functionName: fn.getName()!,
                            improvementPct: res.totalImprovementPct,
                            lineage: res.bestLineage,
                            pValueNote: 'accepted under Welch t-test p<0.05 per generation',
                            originalCode: original,
                            optimizedCode: optimized,
                            explanation: res.bestLineage.map(l => `- ${l}`).join('\n')
                        });
                    }
                } catch { /* function not benchmarkable under the harness: skip, never guess */ }
            }
            this.project.removeSourceFile(src);
        }

        // Apply optimizations to working copies, produce a unified git diff
        const patched = new Map<string, string>();
        for (const o of optimizations) {
            const abs = path.join(repoPath, o.file);
            const current = patched.get(abs) ?? fs.readFileSync(abs, 'utf-8');
            patched.set(abs, current.replace(o.originalCode, o.optimizedCode));
        }
        // Standard unified diff with explicit a/<rel> b/<rel> labels:
        // git-apply-compatible, no path surgery.
        let patch = '';
        for (const [abs, content] of patched.entries()) {
            const relFile = path.relative(repoPath, abs);
            const tmp = path.join(os.tmpdir(), `neuralys_patched_${Date.now()}_${path.basename(abs)}`);
            fs.writeFileSync(tmp, content);
            try {
                execSync(`diff -u --label "a/${relFile}" --label "b/${relFile}" "${abs}" "${tmp}"`, { encoding: 'utf-8' });
            } catch (e: any) { patch += e.stdout || ''; } // diff exits 1 when files differ
            fs.unlinkSync(tmp);
        }

        const patchFile = path.join(repoPath, 'neuralys.patch');
        fs.writeFileSync(patchFile, patch);

        const reportFile = path.join(repoPath, 'NEURALYS_REPORT.md');
        fs.writeFileSync(reportFile, [
            '# Neuralys — Rapport d\'optimisation',
            `Repo: ${repoPath}`,
            `Fonctions scannées: ${scanned} | éligibles: ${eligible} | optimisées: ${optimizations.length}`,
            `Critère d'acceptation: équivalence par fuzzing différentiel + gain ≥ ${this.minGainPct}% (t-test de Welch p<0.05)`,
            '',
            ...optimizations.map(o => [
                `## ${o.file} :: ${o.functionName} — +${o.improvementPct.toFixed(1)}%`,
                `Lignée: ${o.lineage.join(' → ')}`,
                `Preuve: ${o.pValueNote}`,
                'Transformations:', o.explanation, ''
            ].join('\n'))
        ].join('\n'));

        return {
            repoPath, scannedFunctions: scanned, eligibleFunctions: eligible,
            optimizations, patchFile, reportFile,
            durationSec: (Date.now() - t0) / 1000
        };
    }
}
