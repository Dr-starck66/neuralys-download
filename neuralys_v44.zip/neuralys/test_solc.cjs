const solc = require('solc');
const input = {
  language: 'Solidity',
  sources: {
    'Contract.sol': {
      content: `contract Counter {
    uint256 public count;
    function increment() public {
        count += 1;
    }
}`
    }
  },
  settings: {
    outputSelection: {
      '*': {
        '*': ['evm.gasEstimates']
      }
    }
  }
};
console.log(JSON.stringify(JSON.parse(solc.compile(JSON.stringify(input))).contracts, null, 2));
