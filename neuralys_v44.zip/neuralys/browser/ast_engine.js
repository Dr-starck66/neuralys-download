/* ═══ MOTEUR DE MUTATION PAR AST (navigateur) ═══════════════════════════════
   Remplace les expressions régulières par un vrai pipeline compilateur :
       code source → acorn.parse → parcours/réécriture de nœuds → astring.generate
   Conséquences directes :
   - immunité au style : commentaires, sauts de ligne, noms de variables et
     placement des accolades n'ont plus aucun effet sur le déclenchement ;
   - sécurité des portées : les temporaires sont générés à partir de tous les
     identifiants réellement présents dans la fonction (aucun shadowing) ;
   - validité syntaxique par construction : la sortie est régénérée depuis un
     arbre, jamais recollée à la main ;
   - détection d'intention structurelle : on reconnaît un appel de méthode
     `.filter(cb).length` comme un nœud MemberExpression sur CallExpression,
     et on extrait le corps du callback de manière déterministe.
   Aucun réseau : acorn et astring sont embarqués dans le worker.
═══════════════════════════════════════════════════════════════════════════ */

const AST_OPTS = { ecmaVersion: 2022, allowReturnOutsideFunction: true };

function parseCode(code) {
  return acorn.parse(code, AST_OPTS);
}

function gen(node) {
  return astring.generate(node);
}

/* Parcours générique : visite chaque nœud avec son parent et la clé qui l'y
   rattache, ce qui permet de remplacer un nœud in situ. */
function walk(node, visit, parent = null, key = null, index = null) {
  if (!node || typeof node.type !== "string") return;
  visit(node, parent, key, index);
  for (const k of Object.keys(node)) {
    if (k === "type" || k === "start" || k === "end" || k === "loc") continue;
    const v = node[k];
    if (Array.isArray(v)) {
      for (let i = 0; i < v.length; i++) if (v[i] && typeof v[i].type === "string") walk(v[i], visit, node, k, i);
    } else if (v && typeof v.type === "string") {
      walk(v, visit, node, k, null);
    }
  }
}

function replaceNode(parent, key, index, newNode) {
  if (index === null) parent[key] = newNode;
  else parent[key][index] = newNode;
}

/* Noms temporaires garantis uniques : on collecte TOUS les identifiants de
   l'arbre avant d'en fabriquer un nouveau (le point faible n°1 des regex). */
function uniqueName(ast, base) {
  const used = new Set();
  walk(ast, (n) => { if (n.type === "Identifier") used.add(n.name); });
  let i = 0, name = base;
  while (used.has(name)) name = base + "_" + i++;
  return name;
}

const src = (node) => gen(node);
const idNode = (name) => ({ type: "Identifier", name });
const num = (value) => ({ type: "Literal", value, raw: String(value) });
/* Fabrique un sous-arbre à partir d'une expression source : la construction
   manuelle de nœuds est verbeuse, le parsing d'un fragment reste structurel. */
const expr = (code) => parseCode("(" + code + ")").body[0].expression;
const stmts = (code) => parseCode(code).body;

/* ─── Règles ─────────────────────────────────────────────────────────────── */

/* Idiome tri à bulles : double boucle avec comparaison d'éléments adjacents et
   échange par temporaire. Reconnu sur la STRUCTURE, donc insensible aux noms
   de variables (i/j/k/idx) et au formatage. */
function ruleSortIdiom(ast) {
  let changed = false;
  walk(ast, (node, parent, key, index) => {
    if (changed || node.type !== "ForStatement") return;
    const inners = [];
    walk(node, (n) => { if (n !== node && n.type === "ForStatement") inners.push(n); });
    if (inners.length !== 1) return;
    const inner = inners[0];

    let ifs = [];
    walk(inner, (n) => { if (n.type === "IfStatement") ifs.push(n); });
    if (ifs.length !== 1) return;
    const test = ifs[0].test;
    if (test.type !== "BinaryExpression" || test.operator !== ">") return;
    const L = test.left, R = test.right;
    if (L.type !== "MemberExpression" || !L.computed) return;
    if (R.type !== "MemberExpression" || !R.computed) return;
    if (L.object.type !== "Identifier" || R.object.type !== "Identifier") return;
    if (L.object.name !== R.object.name) return;
    const arrName = L.object.name;
    // gauche: a[j] ; droite: a[j+1]
    if (L.property.type !== "Identifier") return;
    const idxName = L.property.name;
    if (R.property.type !== "BinaryExpression" || R.property.operator !== "+") return;
    if (R.property.left.type !== "Identifier" || R.property.left.name !== idxName) return;
    if (R.property.right.type !== "Literal" || R.property.right.value !== 1) return;

    // corps: échange par temporaire (3 affectations, quel que soit le nom du temporaire)
    const body = ifs[0].consequent.type === "BlockStatement" ? ifs[0].consequent.body : [ifs[0].consequent];
    const flat = body.filter((s) => s.type !== "EmptyStatement");
    if (flat.length !== 3) return;
    const texts = flat.map((s) => src(s).replace(/\s+/g, ""));
    const tmpDecl = texts[0].match(/^(?:const|let|var)(\w+)=/);
    if (!tmpDecl) return;
    const tmp = tmpDecl[1];
    const okSwap =
      texts[0] === `${tmpDecl[0]}${arrName}[${idxName}];` &&
      texts[1] === `${arrName}[${idxName}]=${arrName}[${idxName}+1];` &&
      texts[2] === `${arrName}[${idxName}+1]=${tmp};`;
    if (!okSwap) return;

    // Portées sûres jusque dans le comparateur généré : les paramètres ne
    // peuvent pas masquer un identifiant existant (ici, le tableau lui-même
    // peut s'appeler `a`).
    const cmpL = uniqueName(ast, "__x");
    const cmpR = uniqueName(ast, "__y");
    replaceNode(parent, key, index, {
      type: "ExpressionStatement",
      expression: expr(`${arrName}.sort((${cmpL}, ${cmpR}) => ${cmpL} - ${cmpR})`),
    });
    changed = true;
  });
  return changed;
}

/* File consommée par shift() dans une boucle while : remplacée par un pointeur
   de tête. Refusée si la file est réassignée ou splicée dans le corps. */
function ruleShiftToPointer(ast) {
  let changed = false;
  walk(ast, (node, parent, key, index) => {
    if (changed || node.type !== "WhileStatement") return;
    const t = node.test;
    if (t.type !== "BinaryExpression" || t.operator !== ">") return;
    if (t.right.type !== "Literal" || t.right.value !== 0) return;
    if (t.left.type !== "MemberExpression" || t.left.computed) return;
    if (t.left.property.name !== "length" || t.left.object.type !== "Identifier") return;
    const q = t.left.object.name;

    const shiftCalls = [];
    let unsafe = false;
    walk(node.body, (n, p, k, i) => {
      if (n.type === "CallExpression" && n.callee.type === "MemberExpression" &&
          n.callee.object.type === "Identifier" && n.callee.object.name === q) {
        if (n.callee.property.name === "shift") shiftCalls.push({ n, p, k, i });
        if (n.callee.property.name === "splice") unsafe = true;
      }
      if (n.type === "AssignmentExpression" && n.left.type === "Identifier" && n.left.name === q) unsafe = true;
    });
    if (unsafe || shiftCalls.length !== 1) return;

    const head = uniqueName(ast, q + "_head");
    const c = shiftCalls[0];
    replaceNode(c.p, c.k, c.i, expr(`${q}[${head}++]`));
    node.test = expr(`${head} < ${q}.length`);
    replaceNode(parent, key, index, {
      type: "BlockStatement",
      body: [stmts(`let ${head} = 0;`)[0], node],
    });
    changed = true;
  });
  return changed;
}

/* Accumulation de chaîne par += dans une boucle → tableau + join unique. */
function ruleStringToJoin(ast) {
  let changed = false;
  walk(ast, (decl) => {
    if (changed || decl.type !== "VariableDeclarator") return;
    if (!decl.init || decl.init.type !== "Literal" || decl.init.value !== "") return;
    if (decl.id.type !== "Identifier") return;
    const v = decl.id.name;

    const writes = [];
    let unsafe = false, inLoop = false;
    const loopStack = [];
    const scan = (node, parent, key, index) => {
      if (node.type === "AssignmentExpression" && node.left.type === "Identifier" && node.left.name === v) {
        if (node.operator === "+=") writes.push({ node, parent, key, index });
        else unsafe = true;
      }
    };
    walk(ast, scan);
    walk(ast, (n) => {
      if (n.type === "ForStatement" || n.type === "WhileStatement" || n.type === "ForOfStatement") {
        walk(n, (m) => {
          if (m.type === "AssignmentExpression" && m.left.type === "Identifier" && m.left.name === v && m.operator === "+=") inLoop = true;
        });
      }
    });
    if (unsafe || writes.length === 0 || !inLoop) return;

    const parts = uniqueName(ast, v + "_parts");
    for (const w of writes) {
      replaceNode(w.parent, w.key, w.index, {
        type: "CallExpression", optional: false,
        callee: { type: "MemberExpression", computed: false, optional: false, object: idNode(parts), property: idNode("push") },
        arguments: [w.node.right],
      });
    }
    // toutes les autres références deviennent des lectures → join
    walk(ast, (n, p, k, i) => {
      if (n.type === "Identifier" && n.name === v && p && !(p.type === "MemberExpression" && p.property === n)) {
        replaceNode(p, k, i, expr(`${parts}.join('')`));
      }
    });
    decl.id = idNode(parts);
    decl.init = { type: "ArrayExpression", elements: [] };
    changed = true;
  });
  return changed;
}

/* Test d'appartenance sur littéral chaîne via indexOf → Set.has. */
function ruleIndexOfToSet(ast) {
  let changed = false;
  const stringConsts = new Map();
  walk(ast, (n) => {
    if (n.type === "VariableDeclarator" && n.id.type === "Identifier" &&
        n.init && n.init.type === "Literal" && typeof n.init.value === "string") {
      stringConsts.set(n.id.name, n);
    }
  });
  if (stringConsts.size === 0) return false;

  let target = null;
  walk(ast, (node, parent, key, index) => {
    if (node.type !== "BinaryExpression") return;
    if (node.operator !== "!==" && node.operator !== "!=") return;
    if (node.right.type !== "UnaryExpression" || node.right.operator !== "-" ||
        node.right.argument.type !== "Literal" || node.right.argument.value !== 1) return;
    const call = node.left;
    if (call.type !== "CallExpression" || call.callee.type !== "MemberExpression") return;
    if (call.callee.property.name !== "indexOf" || call.callee.object.type !== "Identifier") return;
    const name = call.callee.object.name;
    if (!stringConsts.has(name)) return;
    target = name;
    replaceNode(parent, key, index, {
      type: "CallExpression", optional: false,
      callee: { type: "MemberExpression", computed: false, optional: false, object: idNode(name + "_set"), property: idNode("has") },
      arguments: [call.arguments[0]],
    });
    changed = true;
  });

  if (changed && target) {
    const setName = target + "_set";
    walk(ast, (n, p, k) => {
      if (n.type === "VariableDeclaration" && p && Array.isArray(p[k])) {
        const holds = n.declarations.some((d) => d.id.type === "Identifier" && d.id.name === target);
        if (!holds) return;
        const idx = p[k].indexOf(n);
        if (idx >= 0) p[k].splice(idx + 1, 0, stmts(`const ${setName} = new Set(${target});`)[0]);
      }
    });
  }
  return changed;
}

/* Hissage de `.length` invariant hors de la condition de boucle. */
function ruleLengthCaching(ast) {
  let changed = false;
  walk(ast, (node, parent, key, index) => {
    if (changed || node.type !== "ForStatement" || !node.test) return;
    const t = node.test;
    if (t.type !== "BinaryExpression" || (t.operator !== "<" && t.operator !== "<=")) return;
    if (t.left.type !== "Identifier") return;
    if (t.right.type !== "MemberExpression" || t.right.computed) return;
    if (t.right.property.name !== "length" || t.right.object.type !== "Identifier") return;
    const arr = t.right.object.name;

    let mutated = false;
    walk(node.body, (n) => {
      if (n.type === "CallExpression" && n.callee.type === "MemberExpression" &&
          n.callee.object.type === "Identifier" && n.callee.object.name === arr &&
          ["push", "pop", "shift", "unshift", "splice"].includes(n.callee.property.name)) mutated = true;
      if (n.type === "AssignmentExpression" && n.left.type === "Identifier" && n.left.name === arr) mutated = true;
    });
    if (mutated) return;

    const lenVar = uniqueName(ast, arr + "_len");
    node.test = { type: "BinaryExpression", operator: t.operator, left: t.left, right: idNode(lenVar) };
    replaceNode(parent, key, index, {
      type: "BlockStatement",
      body: [stmts(`const ${lenVar} = ${arr}.length;`)[0], node],
    });
    changed = true;
  });
  return changed;
}

/* INTENTION : `x.filter(pred).length` calcule un COMPTAGE — le tableau
   intermédiaire n'existe que pour sa longueur. Reconnu comme MemberExpression
   `.length` sur CallExpression `.filter`, avec extraction déterministe du
   corps du callback (flèche à corps expression ou à corps bloc). */
function ruleIntentFilterCount(ast) {
  let changed = false;
  walk(ast, (node, parent, key, index) => {
    if (changed || node.type !== "MemberExpression" || node.computed) return;
    if (node.property.name !== "length") return;
    const call = node.object;
    if (call.type !== "CallExpression" || call.callee.type !== "MemberExpression") return;
    if (call.callee.property.name !== "filter") return;
    const cb = call.arguments[0];
    if (!cb || (cb.type !== "ArrowFunctionExpression" && cb.type !== "FunctionExpression")) return;
    if (cb.params.length < 1 || cb.params[0].type !== "Identifier") return;

    const arrSrc = src(call.callee.object);
    const param = cb.params[0].name;
    const c = uniqueName(ast, "__count");
    const i = uniqueName(ast, "__i");
    const predicate = cb.body.type === "BlockStatement"
      ? `(() => { ${src(cb.body).slice(1, -1)} })()`
      : src(cb.body);

    replaceNode(parent, key, index, expr(
      `(() => { let ${c} = 0; const __src = ${arrSrc}; for (let ${i} = 0; ${i} < __src.length; ${i}++) { const ${param} = __src[${i}]; if (${predicate}) ${c}++; } return ${c}; })()`
    ));
    changed = true;
  });
  return changed;
}

/* INTENTION : `x.map(f).reduce((a, b) => a + b, init)` calcule une SOMME DE
   PROJECTION — le tableau intermédiaire n'existe que pour être replié. */
function ruleIntentMapReduce(ast) {
  let changed = false;
  walk(ast, (node, parent, key, index) => {
    if (changed || node.type !== "CallExpression") return;
    if (node.callee.type !== "MemberExpression" || node.callee.property.name !== "reduce") return;
    if (node.arguments.length !== 2) return;
    const folder = node.arguments[0];
    if (folder.type !== "ArrowFunctionExpression" || folder.params.length !== 2) return;
    const b = folder.body;
    if (b.type !== "BinaryExpression" || b.operator !== "+") return;
    const [pa, pb] = folder.params.map((p) => p.type === "Identifier" ? p.name : null);
    if (!pa || !pb) return;
    if (!(b.left.type === "Identifier" && b.left.name === pa && b.right.type === "Identifier" && b.right.name === pb)) return;

    const mapCall = node.callee.object;
    if (mapCall.type !== "CallExpression" || mapCall.callee.type !== "MemberExpression") return;
    if (mapCall.callee.property.name !== "map") return;
    const mapper = mapCall.arguments[0];
    if (!mapper || mapper.type !== "ArrowFunctionExpression" || mapper.params.length < 1) return;
    if (mapper.params[0].type !== "Identifier" || mapper.body.type === "BlockStatement") return;

    const arrSrc = src(mapCall.callee.object);
    const param = mapper.params[0].name;
    const acc = uniqueName(ast, "__acc");
    const i = uniqueName(ast, "__i");
    replaceNode(parent, key, index, expr(
      `(() => { let ${acc} = ${src(node.arguments[1])}; const __src = ${arrSrc}; for (let ${i} = 0; ${i} < __src.length; ${i}++) { const ${param} = __src[${i}]; ${acc} = ${acc} + (${src(mapper.body)}); } return ${acc}; })()`
    ));
    changed = true;
  });
  return changed;
}

/* Bornage des boucles par instrumentation AST.
   Utilisé quand l'environnement interdit les Workers : une boucle infinie ne
   peut plus figer l'onglet, elle lève une exception au-delà d'un budget
   d'itérations. Seed et mutation sont instrumentés à l'identique, donc les
   comparaisons de latence restent valides (le surcoût est commun). */
function instrumentLoops(code, limit) {
  limit = limit || 20000000;
  let ast;
  try { ast = parseCode(code); } catch (e) { return code; }
  const guard = uniqueName(ast, "__guard");
  const LOOPS = ["ForStatement", "WhileStatement", "DoWhileStatement", "ForOfStatement", "ForInStatement"];
  let count = 0;
  walk(ast, (node) => {
    if (LOOPS.indexOf(node.type) < 0) return;
    count++;
    const body = node.body.type === "BlockStatement" ? node.body : { type: "BlockStatement", body: [node.body] };
    body.body.unshift(stmts("if (++" + guard + " > " + limit + ") throw new RangeError('boucle bornee: budget d iterations depasse');")[0]);
    node.body = body;
  });
  if (count === 0) return code;
  walk(ast, (node) => {
    if (node.type === "FunctionDeclaration" && node.body && node.body.type === "BlockStatement") {
      node.body.body.unshift(stmts("let " + guard + " = 0;")[0]);
    }
  });
  try { const out = gen(ast); parseCode(out); return out; } catch (e) { return code; }
}

const AST_RULES = [
  { name: "sort_idiom", fn: ruleSortIdiom },
  { name: "shift_to_pointer", fn: ruleShiftToPointer },
  { name: "string_to_join", fn: ruleStringToJoin },
  { name: "indexof_to_set", fn: ruleIndexOfToSet },
  { name: "length_caching", fn: ruleLengthCaching },
  { name: "intent_filter_count", fn: ruleIntentFilterCount },
  { name: "intent_map_reduce_fusion", fn: ruleIntentMapReduce },
];

/* Applique une règle. Retourne null si elle ne s'applique pas, ou si le
   résultat ne re-parse pas (garde-fou : le générateur ne peut produire que du
   code valide, mais la garde reste explicite). */
function applyAstRule(code, ruleName) {
  const rule = AST_RULES.find((r) => r.name === ruleName);
  if (!rule) return null;
  let ast;
  try { ast = parseCode(code); } catch (e) { return null; }
  let changed;
  try { changed = rule.fn(ast); } catch (e) { return null; }
  if (!changed) return null;
  let out;
  try { out = gen(ast); } catch (e) { return null; }
  try { parseCode(out); } catch (e) { return null; }
  return out === code ? null : out;
}


/* ═══ ESPACE DE RECHERCHE ALGORITHMIQUE ══════════════════════════════════
   Le moteur ne remplace plus un motif par un autre : il infère l'INTENTION
   du code (ici : trier en ordre croissant), puis dérive de cette intention
   une famille d'implémentations interchangeables. Le choix final n'est écrit
   nulle part — il émerge du profil de données mesuré et du benchmark. */

const SORT_FAMILY = [
  { name: "native_timsort",
    why: "TimSort natif : référence robuste, aucune hypothèse sur les données",
    prior: () => 0.5,
    src: (h) => "function " + h + "(__a) { const __s = __a.slice().sort((__x, __y) => __x - __y); for (let __i = 0; __i < __a.length; __i++) __a[__i] = __s[__i]; return __a; }" },
  { name: "insertion_sort",
    why: "O(n·d) où d est le désordre : imbattable sur des données presque triées, catastrophique sinon",
    prior: (p) => (p.inversionDensity < 0.02 ? 1.0 : p.size < 50 ? 0.6 : 0.02),
    src: (h) => "function " + h + "(__a) { for (let __i = 1; __i < __a.length; __i++) { const __v = __a[__i]; let __j = __i - 1; while (__j >= 0 && __a[__j] > __v) { __a[__j + 1] = __a[__j]; __j--; } __a[__j + 1] = __v; } return __a; }" },
  { name: "counting_sort",
    why: "O(n + k) : domine quand l'étendue des valeurs est petite ou les doublons nombreux",
    prior: (p) => (!p.integersOnly ? 0 : p.valueRange <= 4 * p.size ? 1.0 : 0.1),
    src: (h) => "function " + h + "(__a) { if (__a.length === 0) return __a; let __mn = __a[0], __mx = __a[0]; for (let __i = 1; __i < __a.length; __i++) { if (__a[__i] < __mn) __mn = __a[__i]; if (__a[__i] > __mx) __mx = __a[__i]; } const __range = __mx - __mn + 1; if (!Number.isInteger(__range) || __range > 4 * __a.length + 4096) { const __s = __a.slice().sort((__x, __y) => __x - __y); for (let __i = 0; __i < __a.length; __i++) __a[__i] = __s[__i]; return __a; } const __c = new Int32Array(__range); for (let __i = 0; __i < __a.length; __i++) __c[__a[__i] - __mn]++; let __k = 0; for (let __v = 0; __v < __range; __v++) for (let __n = __c[__v]; __n > 0; __n--) __a[__k++] = __v + __mn; return __a; }" },
  { name: "radix_sort_lsd",
    why: "O(n·w) par chiffres base 256 : bat les tris comparatifs sur de grands volumes d'entiers",
    prior: (p) => (!p.integersOnly ? 0 : p.size >= 500 ? 0.8 : 0.2),
    src: (h) => "function " + h + "(__a) { if (__a.length === 0) return __a; if (!__a.every(Number.isInteger)) { const __s = __a.slice().sort((__x, __y) => __x - __y); for (let __i = 0; __i < __a.length; __i++) __a[__i] = __s[__i]; return __a; } let __mn = __a[0]; for (let __i = 1; __i < __a.length; __i++) if (__a[__i] < __mn) __mn = __a[__i]; let __arr = new Array(__a.length); for (let __i = 0; __i < __a.length; __i++) __arr[__i] = __a[__i] - __mn; let __mx = 0; for (let __i = 0; __i < __arr.length; __i++) if (__arr[__i] > __mx) __mx = __arr[__i]; for (let __e = 1; Math.floor(__mx / __e) > 0; __e *= 256) { const __b = new Int32Array(256), __o = new Array(__arr.length); for (let __i = 0; __i < __arr.length; __i++) __b[Math.floor(__arr[__i] / __e) % 256]++; for (let __i = 1; __i < 256; __i++) __b[__i] += __b[__i - 1]; for (let __i = __arr.length - 1; __i >= 0; __i--) { const __d = Math.floor(__arr[__i] / __e) % 256; __o[--__b[__d]] = __arr[__i]; } __arr = __o; } for (let __i = 0; __i < __a.length; __i++) __a[__i] = __arr[__i] + __mn; return __a; }" },
  { name: "merge_sort",
    why: "O(n log n) stable, sans pire cas quadratique : garantie de robustesse",
    prior: () => 0.3,
    src: (h) => "function " + h + "(__a) { const __mg = (__l, __r) => { const __o = new Array(__l.length + __r.length); let __i = 0, __j = 0, __k = 0; while (__i < __l.length && __j < __r.length) __o[__k++] = __l[__i] <= __r[__j] ? __l[__i++] : __r[__j++]; while (__i < __l.length) __o[__k++] = __l[__i++]; while (__j < __r.length) __o[__k++] = __r[__j++]; return __o; }; const __ms = (__x) => __x.length <= 1 ? __x : __mg(__ms(__x.slice(0, __x.length >> 1)), __ms(__x.slice(__x.length >> 1))); const __s = __ms(__a.slice()); for (let __i = 0; __i < __a.length; __i++) __a[__i] = __s[__i]; return __a; }" },
];

/* Profileur v2 : la densité d'inversions remplace l'ordre local comme
   prédicteur du coût d'un tri par insertion (mesuré : 0,95 d'ordre local
   pour 0,52 d'inversions sur des données localement ordonnées mais
   globalement désordonnées — l'ordre local est un faux prédicteur). */
function inversionDensity(a, k) {
  k = k || 512;
  const n = a.length;
  if (n < 2) return 0;
  let s = 1337, inv = 0, pairs = 0;
  for (let t = 0; t < k; t++) {
    s = (Math.imul(s, 1103515245) + 12345) & 0x7fffffff; const i = s % n;
    s = (Math.imul(s, 1103515245) + 12345) & 0x7fffffff; const j = s % n;
    if (i === j) continue;
    const lo = i < j ? i : j, hi = i < j ? j : i;
    if (a[lo] > a[hi]) inv++;
    pairs++;
  }
  return pairs ? inv / pairs : 0;
}

function shannonEntropy(a, k) {
  k = k || 512;
  const n = a.length;
  if (n === 0) return 0;
  let s = 991;
  const hist = new Map();
  const probes = Math.min(n, k);
  for (let t = 0; t < probes; t++) {
    s = (Math.imul(s, 1103515245) + 12345) & 0x7fffffff;
    const v = a[s % n];
    hist.set(v, (hist.get(v) || 0) + 1);
  }
  let h = 0;
  for (const c of hist.values()) { const p = c / probes; h -= p * Math.log2(p); }
  const maxH = Math.log2(Math.max(hist.size, 2));
  return maxH > 0 ? Math.min(1, h / maxH) : 0;
}

function profileClass(p) {
  const sizeB = p.size < 100 ? "S" : p.size < 5000 ? "M" : "L";
  const rangeB = !p.integersOnly ? "float" : p.valueRange <= 4 * p.size ? "dense" : "sparse";
  const orderB = p.inversionDensity < 0.05 ? "sorted" : p.inversionDensity < 0.25 ? "partial" : "random";
  const dupB = p.uniqueRatio < 0.3 ? "dups" : "unique";
  return sizeB + "/" + rangeB + "/" + orderB + "/" + dupB;
}

/* Jeux de données conçus pour METTRE EN DÉFAUT un champion : la validation
   adversariale existante attaque la correction, celle-ci attaque la
   performance. */
const ADVERSARIAL_DATASETS = [
  { name: "étendue explosive", targets: "tri par comptage (alloue O(étendue))",
    build: (n) => Array.from({ length: n }, (_, i) => i * 1000003) },
  { name: "localement ordonné, globalement désordonné", targets: "tri par insertion et tout profileur fondé sur l'ordre local",
    build: (n) => Array.from({ length: n }, (_, i) => (Math.imul(i, 48271) % 2147483647) % 1000000) },
  { name: "inversé strict", targets: "tri par insertion (pire cas O(n²))",
    build: (n) => Array.from({ length: n }, (_, i) => n - i) },
  { name: "valeurs non entières", targets: "tris par distribution (comptage, radix)",
    build: (n) => Array.from({ length: n }, (_, i) => ((Math.imul(i, 48271) % 2147483647) % 100000) / 7) },
  { name: "quasi trié", targets: "tris comparatifs génériques",
    build: (n) => { const a = Array.from({ length: n }, (_, i) => i); for (let k = 0; k + 1 < n; k += Math.max(1, n >> 5)) { const t = a[k]; a[k] = a[k + 1]; a[k + 1] = t; } return a; } },
  { name: "une seule valeur répétée", targets: "tris comparatifs (entropie nulle)",
    build: (n) => new Array(n).fill(42) },
];

const ALGO_META = {
  native_timsort: { time: "O(n log n)", memory: "O(n) copie" },
  insertion_sort: { time: "O(n + I) où I = inversions", memory: "O(1) en place" },
  counting_sort: { time: "O(n + k)", memory: "O(k) — k = étendue" },
  radix_sort_lsd: { time: "O(n · w)", memory: "O(n + 256)" },
  merge_sort: { time: "O(n log n) garanti", memory: "O(n log n) allocations" },
  adaptive_dispatch: { time: "profilage O(n) + branche choisie", memory: "celle de la branche choisie" },
};

function profileInputs(inputs) {
  const flat = (inputs || []).filter((a) => a && a.length > 0);
  if (!flat.length) return { size: 0, valueRange: 0, uniqueRatio: 1, sortedness: 1, integersOnly: true };
  const s = flat.reduce((a, b) => (b.length > a.length ? b : a));
  let mn = s[0], mx = s[0], ints = true, ordered = 0;
  const seen = new Set();
  for (let i = 0; i < s.length; i++) {
    const v = s[i];
    if (v < mn) mn = v;
    if (v > mx) mx = v;
    if (!Number.isInteger(v)) ints = false;
    seen.add(v);
    if (i > 0 && s[i - 1] <= v) ordered++;
  }
  return { size: s.length, valueRange: mx - mn, uniqueRatio: seen.size / s.length,
           sortedness: s.length > 1 ? ordered / (s.length - 1) : 1,
           inversionDensity: inversionDensity(s), entropy: shannonEntropy(s), integersOnly: ints };
}

/* Détection d'intention par AST : idiome compare-échange OU appel .sort((a,b)=>a-b) */
/* Génome adaptatif : le code évolué PORTE le dispatcher et choisit à
   l'exécution selon le profil de SON entrée. Supprime la limite du choix
   figé (« optimal pour le profil mesuré, faux ailleurs »). La branche
   non-entiers a été ajoutée après une défaite adversariale mesurée. */
const ADAPTIVE_DISPATCH_SRC = "function __ns_adaptive_dispatch(__a) {\n" +
"    const __n = __a.length;\n" +
"    if (__n < 2) return __a;\n" +
"    let __mn = __a[0], __mx = __a[0], __ints = true;\n" +
"    for (let __i = 0; __i < __n; __i++) { const __v = __a[__i]; if (__v < __mn) __mn = __v; if (__v > __mx) __mx = __v; if (__ints && !Number.isInteger(__v)) __ints = false; }\n" +
"    let __s = 1337, __inv = 0, __pairs = 0;\n" +
"    const __probes = __n < 64 ? __n : 128;\n" +
"    for (let __t = 0; __t < __probes; __t++) {\n" +
"        __s = (Math.imul(__s, 1103515245) + 12345) & 0x7fffffff; const __i = __s % __n;\n" +
"        __s = (Math.imul(__s, 1103515245) + 12345) & 0x7fffffff; const __j = __s % __n;\n" +
"        if (__i === __j) continue;\n" +
"        const __lo = __i < __j ? __i : __j, __hi = __i < __j ? __j : __i;\n" +
"        if (__a[__lo] > __a[__hi]) __inv++;\n" +
"        __pairs++;\n" +
"    }\n" +
"    const __d = __pairs ? __inv / __pairs : 0;\n" +
"    if (__d < 0.02) return __ns_insertion_sort(__a);\n" +
"    if (__ints && (__mx - __mn) <= 4 * __n + 4096) return __ns_counting_sort(__a);\n" +
"    if (__ints && __n >= 500) return __ns_radix_sort_lsd(__a);\n" +
"    if (!__ints) return __ns_merge_sort(__a);\n" +
"    return __ns_native_timsort(__a);\n" +
"}";

const ADAPTIVE_CANDIDATE = {
  name: "adaptive_dispatch",
  why: "profile l'entrée à l'exécution (densité d'inversions, étendue, type) et choisit — robuste au changement de distribution, au prix d'une passe O(n)",
  prior: () => 0.9,
  src: () => [ADAPTIVE_DISPATCH_SRC].concat(SORT_FAMILY.map((c) => c.src("__ns_" + c.name))).join("\n\n"),
};

function detectSortSite(code) {
  let ast;
  try { ast = parseCode(code); } catch (e) { return null; }
  let site = null;
  walk(ast, (node, parent, key, index) => {
    if (site) return;
    if (node.type === "CallExpression" && node.callee.type === "MemberExpression" &&
        node.callee.property.name === "sort" && node.callee.object.type === "Identifier") {
      const cmp = node.arguments[0];
      if (!cmp || cmp.type !== "ArrowFunctionExpression" || cmp.params.length !== 2) return;
      const b = cmp.body;
      if (b.type !== "BinaryExpression" || b.operator !== "-") return;
      if (b.left.name !== cmp.params[0].name || b.right.name !== cmp.params[1].name) return;
      site = { node, parent, key, index, arr: node.callee.object.name, kind: "expression" };
      return;
    }
    if (node.type !== "ForStatement") return;
    const inners = [];
    walk(node, (n) => { if (n !== node && n.type === "ForStatement") inners.push(n); });
    if (inners.length !== 1) return;
    const ifs = [];
    walk(inners[0], (n) => { if (n.type === "IfStatement") ifs.push(n); });
    if (ifs.length !== 1) return;
    const t = ifs[0].test;
    if (t.type !== "BinaryExpression" || t.operator !== ">") return;
    if (t.left.type !== "MemberExpression" || !t.left.computed || t.left.object.type !== "Identifier") return;
    if (t.right.type !== "MemberExpression" || !t.right.computed) return;
    if (t.right.object.name !== t.left.object.name) return;
    if (t.left.property.type !== "Identifier") return;
    const idx = t.left.property.name;
    if (t.right.property.type !== "BinaryExpression" || t.right.property.operator !== "+") return;
    if (t.right.property.left.name !== idx || t.right.property.right.value !== 1) return;
    const body = ifs[0].consequent.type === "BlockStatement" ? ifs[0].consequent.body : [ifs[0].consequent];
    if (body.length !== 3) return;
    site = { node, parent, key, index, arr: t.left.object.name, kind: "statement" };
  });
  return site;
}

function generateAlgorithmCandidates(code, profile) {
  const probe = detectSortSite(code);
  if (!probe) return [];
  const out = [];
  for (const cand of SORT_FAMILY.concat([ADAPTIVE_CANDIDATE])) {
    let ast;
    try { ast = parseCode(code); } catch (e) { return []; }
    const site = detectSortSite(code) && (function () {
      let found = null;
      const p2 = detectSortSite;
      return null;
    })();
    // re-détecte sur l'arbre courant pour disposer des nœuds de CET arbre
    let target = null;
    walk(ast, (node, parent, key, index) => {
      if (target) return;
      if (probe.kind === "expression") {
        if (node.type === "CallExpression" && node.callee.type === "MemberExpression" &&
            node.callee.property.name === "sort" && node.callee.object.name === probe.arr) target = { node, parent, key, index };
      } else if (node.type === "ForStatement") {
        const inners = [];
        walk(node, (n) => { if (n !== node && n.type === "ForStatement") inners.push(n); });
        if (inners.length === 1) {
          let ok = false;
          walk(inners[0], (n) => { if (n.type === "IfStatement" && gen(n.test).indexOf(probe.arr + "[") >= 0) ok = true; });
          if (ok) target = { node, parent, key, index };
        }
      }
    });
    if (!target) continue;
    const helper = "__ns_" + cand.name;
    const call = helper + "(" + probe.arr + ")";
    const repl = probe.kind === "statement"
      ? { type: "ExpressionStatement", expression: expr(call) }
      : expr(call);
    replaceNode(target.parent, target.key, target.index, repl);
    let mutated;
    try { mutated = gen(ast) + "\n\n" + cand.src(helper); parseCode(mutated); } catch (e) { continue; }
    out.push({ strategy: "algo:" + cand.name, code: mutated, why: cand.why, prior: cand.prior(profile) });
  }
  return out.sort((a, b) => b.prior - a.prior);
}
