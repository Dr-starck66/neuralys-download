# Neuralys — application navigateur

Trois fichiers assemblés en un artefact HTML autonome (`neuralys-live.html`) :

| Fichier | Rôle |
|---|---|
| `ast_engine.js` | Règles de mutation par réécriture d'AST (acorn → nœuds → astring) |
| `worker_engine.js` | Ops du Web Worker : `profile`, `mutate`, `evaluate`, `bench`, `probes`, `rules` |
| `app_ui.js` | Orchestration et interface (JS natif, aucun framework) |

Assemblage : `acorn.min` + `astring.min` + `ast_engine` + `worker_engine` sont
concaténés en un Blob qui devient le Worker ; `app_ui` orchestre depuis le
thread principal.

## Deux modes d'exécution, jamais silencieux

| Mode | Condition | Protection contre les boucles infinies |
|---|---|---|
| **Worker** | environnement autorisant `new Worker(blob:)` | budget temps + `terminate()` — le code muté ne touche jamais le thread principal |
| **Instrumenté** | Workers bloqués par la politique d'origine du bac à sable | `instrumentLoops()` borne chaque boucle par AST avant compilation : une boucle infinie lève une `RangeError` au lieu de figer l'onglet |

Le mode réellement actif est affiché dans l'en-tête de l'application et la
bascule est journalisée dans l'onglet Diagnostic — aucune dégradation muette.

### Le biais de mesure du mode instrumenté, et sa correction

Première formulation, fausse : « seed et mutation étant instrumentés à
l'identique, le surcoût est commun et les comparaisons restent valides ». Le
surcoût est proportionnel au NOMBRE D'ITÉRATIONS JavaScript, qui diffère
structurellement d'une implémentation à l'autre : un tri par comptage écrit en
JS paie la garde à chaque tour, un tri qui délègue au moteur natif ne la paie
presque pas.

Effet mesuré : sous instrumentation, le tri natif l'emportait (+81,8 %) sur le
tri par comptage (+77,1 %) ; sans le biais, le classement s'inverse
(+82,0 % contre +71,2 %). Le moteur aurait retenu le mauvais algorithme.

Correctif : **l'instrumentation sert à la preuve, pas à la mesure**. Le fuzzing
et les invariants s'exécutent sur la version bornée ; avant de mesurer sans
garde, une sonde de terminaison exécute la version bornée sur l'entrée exacte
du banc — si elle termine là, elle terminera pendant la mesure.

Aucun appel réseau pour le moteur (bibliothèques embarquées). Les seuls appels
sortants sont les mutations et narrations Claude, optionnelles.
