
const compile = (code) => {
  // self.NEURALYS_GUARD est posé uniquement en mode repli (pas de Worker) :
  // les boucles sont alors bornées par instrumentation AST.
  var prepared = (typeof self !== 'undefined' && self.NEURALYS_GUARD && typeof instrumentLoops === 'function')
    ? instrumentLoops(code) : code;
  return new Function('"use strict"; ' + prepared + '; return processPayload;')();
};

const mk = (n, seed) => {
  const d = Array.from({ length: n }, (_, i) => i - Math.floor(n / 2));
  let s = seed;
  for (let i = n - 1; i > 0; i--) { s = (s * 48271) % 2147483647; const j = s % (i + 1); const t = d[i]; d[i] = d[j]; d[j] = t; }
  return d;
};
const INV_PROBES = [[], [0], [-1], [5], [1, 1, 1], [3, 1, 2], mk(20, 7), mk(50, 11), mk(200, 13),
  Array.from({ length: 30 }, () => 4), Array.from({ length: 40 }, (_, i) => -i)];

const shuffleSeeded = (a, seed) => {
  const d = a.slice(); let s = seed;
  for (let i = d.length - 1; i > 0; i--) { s = (s * 48271) % 2147483647; const j = s % (i + 1); const t = d[i]; d[i] = d[j]; d[j] = t; }
  return d;
};
const safeB = (f) => { try { return f(); } catch (e) { return false; } };

const INVARIANTS = [
  { name: "deterministic", check: (fn) => INV_PROBES.every((p) => safeB(() => JSON.stringify(fn(p.slice())) === JSON.stringify(fn(p.slice())))) },
  { name: "input_not_mutated", check: (fn) => INV_PROBES.every((p) => safeB(() => { const c = p.slice(); fn(c); return JSON.stringify(c) === JSON.stringify(p); })) },
  { name: "numeric_output", check: (fn) => INV_PROBES.every((p) => safeB(() => Number.isFinite(fn(p.slice())))) },
  { name: "integer_output", check: (fn) => INV_PROBES.every((p) => safeB(() => Number.isInteger(fn(p.slice())))) },
  { name: "order_insensitive", check: (fn) => INV_PROBES.filter((p) => p.length > 1).every((p) => safeB(() =>
      JSON.stringify(fn(p.slice())) === JSON.stringify(fn(shuffleSeeded(p, 991))) &&
      JSON.stringify(fn(p.slice())) === JSON.stringify(fn(shuffleSeeded(p, 313))))) },
  { name: "empty_input_total", check: (fn) => safeB(() => { fn([]); return true; }) },
  { name: "length_scalable", check: (fn) => INV_PROBES.every((p) => safeB(() => { fn(p.slice()); return true; })) },
];

function seededInput(n, seed) {
  const d = Array.from({ length: n }, (_, i) => i);
  let s = seed;
  for (let i = n - 1; i > 0; i--) { s = (s * 1103515245 + 12345) & 0x7fffffff; const j = s % (i + 1); const t = d[i]; d[i] = d[j]; d[j] = t; }
  return d;
}

function genAdv(origCode, mutCode, cap) {
  cap = cap || 30;
  const lits = new Set([0, 1, -1]);
  const src = origCode + "\\n" + mutCode;
  const all = src.match(/(-?\\d+)/g) || [];
  for (const raw of all) {
    const v = parseInt(raw, 10);
    if (Number.isFinite(v) && Math.abs(v) <= 100000) { lits.add(v); lits.add(v - 1); lits.add(v + 1); }
  }
  const out = [];
  const push = (a) => { if (out.length < cap) out.push(a); };
  const ordered = Array.from(lits).sort((a, b) => Math.abs(a) - Math.abs(b)).slice(0, 10);
  for (const v of ordered) {
    push([v]); push([v - 1, v, v + 1]); push([v, v]);
    if (v > 0 && v <= 1500) { push(Array.from({ length: v }, (_, i) => i)); push(Array.from({ length: v + 1 }, (_, i) => i)); }
    push([v, 0, 1, 2, 3]); push([0, 1, 2, 3, v]);
  }
  return out;
}

function fuzzPair(origFn, mutFn, storedCEs, origCode, mutCode) {
  const n = 300;
  const cases = [[], [0], [-1], [1, 1, 1], seededInput(300, 42),
    Array.from({ length: n }, (_, i) => i),
    Array.from({ length: n }, () => 7),
    Array.from({ length: n }, (_, i) => i % 5),
    Array.from({ length: n }, (_, i) => (i % 2 ? 1 : -1) * i)]
    .concat(genAdv(origCode || "", mutCode || ""))
    .concat(storedCEs || []);
  let s = 7;
  for (let k = 0; k < 50; k++) {
    s = (s * 48271) % 2147483647;
    const len = s % 180, arr = [];
    let t = s;
    for (let i = 0; i < len; i++) { t = (t * 48271) % 2147483647; arr.push((t % 2001) - 1000); }
    cases.push(arr);
  }
  for (const input of cases) {
    let r1, r2, e1 = null, e2 = null;
    try { r1 = origFn(input.slice()); } catch (e) { e1 = e.constructor.name; }
    try { r2 = mutFn(input.slice()); } catch (e) { e2 = e.constructor.name; }
    if (e1 !== e2 || (e1 === null && JSON.stringify(r1) !== JSON.stringify(r2))) return { ok: false, ce: input, tested: cases.length };
  }
  return { ok: true, tested: cases.length };
}

/* Biais de mesure du mode instrumenté, corrigé.
   Le bornage de boucles coûte une incrémentation + une comparaison PAR
   ITÉRATION. Ce surcoût n'est pas neutre entre variantes : une implémentation
   écrite en JS (tri par comptage, insertion) le paie à chaque tour, une
   implémentation qui délègue au tri natif ne le paie presque pas. Comparer
   des algorithmes sous instrumentation fausse donc le classement en faveur du
   natif.
   Correctif : l'instrumentation sert à la PREUVE (fuzzing, invariants), pas à
   la MESURE. Avant de mesurer sans garde, on exécute une sonde de terminaison
   sur l'entrée de benchmark avec la version bornée — si elle termine là, elle
   terminera à l'identique pendant la mesure. */
function compileForBench(code) {
  if (!(typeof self !== 'undefined' && self.NEURALYS_GUARD)) return compile(code);
  var guarded = compile(code);
  guarded(seededInput(1000, 1337));            // sonde de terminaison, bornée
  return new Function('"use strict"; ' + code + '; return processPayload;')();
}

function benchFn(fn, samples) {
  samples = samples || 12;
  const inputs = Array.from({ length: 4 }, (_, i) => seededInput(1000, 1337 + i));
  for (let w = 0; w < 3; w++) fn(inputs[w % 4].slice());
  const t0 = performance.now(); fn(inputs[0].slice());
  const single = Math.max(performance.now() - t0, 0.0001);
  const reps = Math.max(1, Math.min(3000, Math.ceil(1.5 / single)));
  const lat = [];
  for (let i = 0; i < samples; i++) {
    const pre = Array.from({ length: reps }, (_, r) => inputs[(i + r) % 4].slice());
    const a = performance.now();
    for (let r = 0; r < reps; r++) fn(pre[r]);
    lat.push((performance.now() - a) / reps);
  }
  return lat;
}

self.onmessage = (ev) => {
  const { id, op, payload } = ev.data;
  const reply = (result) => self.postMessage({ id, result });
  const fail = (stage, e) => self.postMessage({ id, error: { stage, message: String((e && e.message) || e) } });
  try {
    if (op === "profile") {
      let fn; try { fn = compile(payload.code); } catch (e) { return fail("compilation", e); }
      const invariants = INVARIANTS.filter((i) => i.check(fn)).map((i) => i.name);
      let benchTarget; try { benchTarget = compileForBench(payload.code); } catch (e) { return fail("sonde de terminaison", e); }
      const lat = benchFn(benchTarget, payload.samples);
      return reply({ invariants, lat });
    }
    if (op === "evaluate") {
      let origFn, mutFn;
      try { origFn = compile(payload.seedCode); } catch (e) { return fail("compilation du seed", e); }
      try { mutFn = compile(payload.mutCode); } catch (e) { return fail("compilation de la mutation", e); }
      const violations = INVARIANTS.filter((i) => (payload.seedInvariants || []).indexOf(i.name) >= 0 && !i.check(mutFn)).map((i) => i.name);
      if (violations.length) return reply({ violations, fuzz: null, lat: null });
      const fz = fuzzPair(origFn, mutFn, payload.storedCEs, payload.seedCode, payload.mutCode);
      if (!fz.ok) return reply({ violations: [], fuzz: fz, lat: null });
      let benchTarget; try { benchTarget = compileForBench(payload.mutCode); } catch (e) { return fail("sonde de terminaison", e); }
      return reply({ violations: [], fuzz: fz, lat: benchFn(benchTarget, payload.samples) });
    }
    if (op === "bench") {
      let fn; try { fn = compileForBench(payload.code); } catch (e) { return fail("compilation", e); }
      return reply({ lat: benchFn(fn, payload.samples) });
    }
    if (op === "rules") return reply({ rules: AST_RULES.map((r) => r.name) });
    if (op === "adversarial") {
      // Confronte chaque implémentation aux jeux conçus pour la faire perdre.
      const variants = payload.variants || [];
      const rows = [];
      for (const ds of ADVERSARIAL_DATASETS) {
        const data = ds.build(payload.n || 1200);
        const times = {};
        for (const v of variants) {
          let fn;
          try { fn = compileForBench(v.code); } catch (e) { times[v.name] = null; continue; }
          try {
            for (let w = 0; w < 20; w++) fn(data.slice());
            const t0 = performance.now();
            for (let r = 0; r < 120; r++) fn(data.slice());
            times[v.name] = (performance.now() - t0) / 120;
          } catch (e) { times[v.name] = null; }
        }
        rows.push({ dataset: ds.name, targets: ds.targets, profileClass: profileClass(profileInputs([data])), times: times });
      }
      return reply({ rows: rows, meta: ALGO_META });
    }
    if (op === "algo_space") {
      const profile = profileInputs([seededInput(1000, 1337)]);
      const cands = generateAlgorithmCandidates(payload.code, profile);
      return reply({ profile: profile, candidates: cands.map((c) => ({ strategy: c.strategy, why: c.why, prior: c.prior, code: c.code })) });
    }
    if (op === "mutate") return reply({ code: applyAstRule(payload.code, payload.rule) });
    if (op === "probes") {
      let origFn, newFn;
      try { origFn = compile(payload.seedCode); newFn = compile(payload.mutCode); } catch (e) { return fail("compilation", e); }
      const rows = [];
      for (const input of payload.inputs) {
        let expected, threw = false;
        try { expected = origFn(input.slice()); } catch (e) { threw = true; }
        if (threw) continue;
        let actual, err = null;
        try { actual = newFn(input.slice()); } catch (e) { err = String(e.message); }
        const ok = err === null && ((typeof expected === "number" && Number.isNaN(expected))
          ? (typeof actual === "number" && Number.isNaN(actual))
          : JSON.stringify(actual) === JSON.stringify(expected));
        rows.push({ input, expected: (typeof expected === "number" && Number.isNaN(expected)) ? "NaN" : expected, ok, err });
      }
      return reply({ rows });
    }
    fail("op", new Error("opération inconnue: " + op));
  } catch (e) { fail(op, e); }
};