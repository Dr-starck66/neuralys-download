/* ═══ NEURALYS — couche d'orchestration et d'interface (JS natif) ═══════════
   Le moteur (parsing AST, règles, fuzzing, invariants, benchmark) tourne dans
   un Web Worker. Ce fichier ne fait qu'orchestrer et afficher. */

const BENCHMARKS = {
  BubbleSort: `function processPayload(arr) {
  const a = arr.slice();
  for (let i = 0; i < a.length; i++) {
    for (let j = 0; j < a.length - i - 1; j++) {
      if (a[j] > a[j + 1]) {
        const tmp = a[j];
        a[j] = a[j + 1];
        a[j + 1] = tmp;
      }
    }
  }
  return a[0] + a.length;
}`,
  "BubbleSort (style hostile)": `function processPayload(donnees)
{
  /* copie defensive - commentaires, var, noms differents :
     une regle par expression reguliere echoue ici, l'AST non */
  const liste = donnees.slice();
  for (var passe = 0; passe < liste.length; passe++)
  {
    // boucle interne
    for (var k = 0; k < liste.length - passe - 1; k++) {
      if (liste[k] > liste[k + 1]) { let echange = liste[k]; liste[k] = liste[k + 1]; liste[k + 1] = echange; }
    }
  }
  return liste[0] + liste.length;
}`,
  FilterCount: `function processPayload(arr) {
  return arr.filter(x => x > 10).length + arr.length;
}`,
  MapReduceSum: `function processPayload(arr) {
  return arr.map(x => x * x).reduce((a, b) => a + b, 0);
}`,
  BFS: `function processPayload(arr) {
  const n = arr.length;
  const visited = new Array(n).fill(false);
  const queue = [0];
  let count = 0;
  while (queue.length > 0) {
    const node = queue.shift();
    if (node >= n || visited[node]) continue;
    visited[node] = true;
    count += (arr[node] || 0);
    queue.push(node + 1);
    queue.push(node + 2);
  }
  return count;
}`,
  CountVowels: `function processPayload(arr) {
  const str = arr.map(x => String.fromCharCode(97 + (Math.abs(x) % 26))).join('');
  const vowels = 'aeiou';
  let count = 0;
  for (let j = 0; j < str.length; j++) {
    if (vowels.indexOf(str[j]) !== -1) count++;
  }
  return count;
}`,
  SumSquares: `function processPayload(arr) {
  let total = 0;
  for (let i = 0; i < arr.length; i++) {
    total += arr[i] * arr[i];
  }
  return total;
}`,
};

const RULE_NAMES = ["sort_idiom", "shift_to_pointer", "string_to_join", "indexof_to_set",
  "length_caching", "intent_filter_count", "intent_map_reduce_fusion"];

const MECHANISMS = {
  sort_idiom: "la double boucle compare-échange adjacente (O(n²)) calcule exactement un tri croissant ; remplacée par le TimSort natif (O(n log n)), mathématiquement équivalent pour des nombres",
  shift_to_pointer: "Array.shift() recopie les éléments restants à chaque appel ; un pointeur de tête lit le même élément en O(1) sans déplacer le tableau",
  string_to_join: "chaque += sur une chaîne peut recopier l'accumulé ; push des fragments puis un join unique produit la même chaîne en une concaténation finale",
  indexof_to_set: "indexOf parcourt la chaîne à chaque test (O(k)) ; un Set pré-construit répond en O(1) par hachage, même résultat booléen",
  length_caching: ".length est relu à chaque itération alors que la taille est invariante dans la boucle : hissé hors de la condition",
  intent_filter_count: "INTENTION reconnue : filter(pred).length calcule un COMPTAGE — le tableau intermédiaire n'existe que pour sa longueur ; réécrit en boucle sans allocation",
  intent_map_reduce_fusion: "INTENTION reconnue : map(f).reduce(+, 0) calcule une SOMME DE PROJECTION — fusion en une seule passe, ordre d'addition préservé",
  claude_refactor: "réécriture architecturale proposée par Claude, validée par fuzzing différentiel — l'équivalence est prouvée empiriquement, pas déclarée",
};
const ALGO_WHY = {};

const INVARIANT_META = [
  ["deterministic", "même entrée deux fois → même sortie (aucun hasard ni état caché)"],
  ["input_not_mutated", "l'argument n'est jamais modifié (pureté vis-à-vis de l'entrée)"],
  ["numeric_output", "la sortie est toujours un nombre fini"],
  ["integer_output", "entrées entières → sortie entière"],
  ["order_insensitive", "f(permutation(x)) = f(x) — le calcul ne dépend pas de l'ordre"],
  ["empty_input_total", "définie sur [] (ne lève pas d'exception sur le tableau vide)"],
  ["length_scalable", "accepte des tailles arbitraires sans exception (1 à 200 testées)"],
];

/* ── Exécution isolée, avec repli honnête ────────────────────────────────
   Chemin nominal : Web Worker (le code muté ne touche jamais le thread
   principal ; une boucle infinie est tuée par terminate()).
   Certains environnements interdisent les Workers construits depuis un Blob
   (origine sandbox). Dans ce cas on bascule sur une exécution instrumentée :
   le moteur AST borne toutes les boucles avant compilation, donc une boucle
   infinie lève une exception au lieu de figer l'onglet. Seed et mutation sont
   instrumentés à l'identique — les comparaisons de latence restent valides,
   le surcoût étant commun aux deux. Le mode actif est affiché, jamais masqué. */
class Runner {
  constructor(onError) {
    this.onError = onError; this.seq = 0; this.pending = new Map();
    this.mode = "worker"; this.spawn();
  }
  sources() {
    return [ACORN_SRC, ";\n", ASTRING_SRC, ";\n", AST_ENGINE_SRC, ";\n", WORKER_SRC];
  }
  makeInline() {
    const shim = { NEURALYS_GUARD: true };
    new Function("self", "performance", this.sources().join(""))(shim, performance);
    this.shim = shim;
    this.mode = "inline";
    if (typeof setMode === "function") setMode("inline");
  }
  spawn() {
    if (this.worker) { try { this.worker.terminate(); } catch (e) {} this.worker = null; }
    if (this.mode === "inline") { this.makeInline(); return; }
    try {
      const blob = new Blob(this.sources(), { type: "application/javascript" });
      this.worker = new Worker(URL.createObjectURL(blob));
      this.worker.onmessage = (ev) => {
        const d = ev.data, e = this.pending.get(d.id);
        if (!e) return;
        clearTimeout(e.timer); this.pending.delete(d.id);
        if (d.error) { this.onError(d.error.stage, d.error.message); e.reject(new Error(d.error.stage + ": " + d.error.message)); }
        else e.resolve(d.result);
      };
      this.worker.onerror = (err) => {
        this.onError("worker", (err.message || "erreur worker") + " — bascule en exécution instrumentée");
        for (const [, e] of this.pending) { clearTimeout(e.timer); e.reject(new Error("worker en erreur")); }
        this.pending.clear();
        this.mode = "inline"; this.makeInline();
      };
      if (typeof setMode === "function") setMode("worker");
    } catch (e) {
      this.onError("worker", "Workers indisponibles ici (" + (e.message || e) + ") — repli sur exécution instrumentée : boucles bornées par AST");
      this.makeInline();
    }
  }
  call(op, payload, timeoutMs) {
    timeoutMs = timeoutMs || 8000;
    if (this.mode === "inline") {
      return new Promise((resolve, reject) => {
        this.shim.postMessage = (m) => {
          if (m.error) { this.onError(m.error.stage, m.error.message); reject(new Error(m.error.stage + ": " + m.error.message)); }
          else resolve(m.result);
        };
        try { this.shim.onmessage({ data: { id: ++this.seq, op, payload } }); }
        catch (e) { this.onError(op, e.message || String(e)); reject(e); }
      });
    }
    const id = ++this.seq;
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        this.pending.delete(id);
        this.onError("timeout", op + " > " + timeoutMs + "ms — worker tué (boucle infinie probable)");
        this.spawn(); reject(new Error("timeout"));
      }, timeoutMs);
      this.pending.set(id, { resolve, reject, timer });
      this.worker.postMessage({ id, op, payload });
    });
  }
}

function setMode(mode) {
  const el = document.getElementById("modeBadge");
  if (!el) return;
  if (mode === "worker") {
    el.textContent = "exécution : Web Worker isolé";
    el.style.color = "#3ECF8E";
  } else {
    el.textContent = "exécution : instrumentée (Workers bloqués ici — boucles bornées par AST)";
    el.style.color = "#F5A524";
  }
}

/* ── stats (thread principal : pur calcul, aucun code utilisateur) ── */
const mean = (a) => a.reduce((x, y) => x + y, 0) / a.length;
const sd = (a) => Math.sqrt(a.reduce((s, x) => s + Math.pow(x - mean(a), 2), 0) / (a.length - 1));
function welchP(a, b) {
  const t = (mean(a) - mean(b)) / Math.sqrt(sd(a) ** 2 / a.length + sd(b) ** 2 / b.length || 1e-12);
  const z = Math.abs(t);
  return Math.max(1e-12, Math.min(1, 2 * (1 - 0.5 * (1 + Math.tanh(z * 0.7978845608 * (1 + 0.044715 * z * z) / 1.4142)))));
}
const cohensD = (a, b) => {
  const p = Math.sqrt((sd(a) ** 2 + sd(b) ** 2) / 2);
  return p > 0 ? (mean(a) - mean(b)) / p : 0;
};
const nesting = (c) => { let d = 0, m = 0; for (const ch of c) { if (ch === "{") { d++; if (d > m) m = d; } else if (ch === "}") d--; } return m; };
const cx = (c) => (c.match(/\b(if|for|while|case|&&|\|\|)\b/g) || []).length + 1 + nesting(c);
const hashish = (s) => { let h = 0; for (let i = 0; i < s.length; i++) h = (Math.imul(h, 31) + s.charCodeAt(i)) | 0; return (h >>> 0).toString(16).padStart(8, "0"); };

function generateAdversarial(a, b, cap) {
  cap = cap || 30;
  const lits = new Set([0, 1, -1]);
  const all = (a + "\n" + b).match(/-?\d+/g) || [];
  for (const raw of all) {
    const v = parseInt(raw, 10);
    if (Number.isFinite(v) && Math.abs(v) <= 100000) { lits.add(v); lits.add(v - 1); lits.add(v + 1); }
  }
  const out = [];
  const push = (x) => { if (out.length < cap) out.push(x); };
  for (const v of Array.from(lits).sort((x, y) => Math.abs(x) - Math.abs(y)).slice(0, 10)) {
    push([v]); push([v - 1, v, v + 1]); push([v, v]);
    if (v > 0 && v <= 1500) { push(Array.from({ length: v }, (_, i) => i)); push(Array.from({ length: v + 1 }, (_, i) => i)); }
    push([v, 0, 1, 2, 3]); push([0, 1, 2, 3, v]);
  }
  return out;
}

/* ── analyse d'éligibilité (mesure la limite dominante sur du vrai code) ── */
function analyzeEligibility(source) {
  const results = [];
  const fnRe = /(?:export\s+)?(?:async\s+)?function\s+(\w+)\s*\(([^)]*)\)/g;
  let m;
  while ((m = fnRe.exec(source)) !== null) {
    const full = m[0], name = m[1], params = m[2];
    const start = m.index + full.length;
    let depth = 0, end = start, started = false;
    for (let i = start; i < source.length; i++) {
      if (source[i] === "{") { depth++; started = true; }
      else if (source[i] === "}") { depth--; if (started && depth === 0) { end = i; break; } }
    }
    const body = source.slice(start, end);
    const arity = params.trim() === "" ? 0 : params.split(",").length;
    let reason = null;
    if (full.indexOf("async") >= 0) reason = "async (état temporel non modélisé)";
    else if (arity !== 1) reason = "arité " + arity + " (harnais : 1 paramètre)";
    else if (/\bthis\b/.test(body)) reason = "utilise this (état d'objet)";
    else if (/\bawait\b/.test(body)) reason = "await (asynchrone)";
    else if (/\bprocess\.|\bconsole\.|\bfs\.|\bfetch\(/.test(body)) reason = "I/O ou effet de bord observable";
    else if (!/\bfor\s*\(|\bwhile\s*\(/.test(body) && !/\.(map|filter|reduce)\s*\(/.test(body)) reason = "aucune boucle ni chaîne fonctionnelle";
    results.push({ name, eligible: !reason, reason: reason || "éligible" });
  }
  const methodRe = /^\s{2,}(?:public|private|protected|static|async)?\s*(\w+)\s*\([^)]*\)\s*[:{]/gm;
  while ((m = methodRe.exec(source)) !== null) {
    if (["if", "for", "while", "switch", "catch", "return", "function"].indexOf(m[1]) >= 0) continue;
    results.push({ name: m[1], eligible: false, reason: "méthode de classe (hors harnais fonction pure)" });
  }
  return results;
}

/* ── appels Claude (API hébergée par l'artefact, aucune clé requise) ── */
async function claudeMutate(code, onError) {
  try {
    const resp = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "claude-sonnet-4-6", max_tokens: 900,
        messages: [{ role: "user", content: "You are a high-performance compiler engineer. Refactor this JavaScript to run faster WITHOUT changing observable behavior for any integer-array input. Prefer algorithmic changes (closed forms, better complexity). Keep the exact name processPayload(arr). Return ONLY raw JavaScript, no markdown, no comments.\n\n" + code }],
      }),
    });
    const data = await resp.json();
    const text = (data.content || []).filter((b) => b.type === "text").map((b) => b.text).join("");
    const clean = text.replace(/```(javascript|js)?\n?|```/g, "").trim();
    if (clean.indexOf("function processPayload") < 0) { onError("claude", "réponse sans fonction processPayload exploitable"); return null; }
    return clean;
  } catch (e) { onError("claude", e.message || "appel API échoué"); return null; }
}

async function claudeNarrative(mech, before, after, onError) {
  try {
    const resp = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "claude-sonnet-4-6", max_tokens: 300,
        messages: [{ role: "user", content: "Tu es un ingénieur compilateur. Reformule cette explication en 3 phrases claires pour un développeur, en français, sans rien inventer:\n\n" + mech + "\n\nAvant:\n" + before + "\n\nAprès:\n" + after }],
      }),
    });
    const data = await resp.json();
    return (data.content || []).filter((b) => b.type === "text").map((b) => b.text).join("").trim() || null;
  } catch (e) { onError("claude-narration", e.message || "appel API échoué"); return null; }
}

/* ══ état applicatif ══ */
const S = {
  records: [], best: null, seedInv: [], errors: [], ces: [], priors: {},
  running: false, selfTest: null, replay: null, report: null, pr: null, selected: null,
  algoSpace: null, adversarial: null,
};
const $ = (id) => document.getElementById(id);
const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c]);

function pushError(stage, message) {
  S.errors.push({ stage, message, at: new Date().toLocaleTimeString() });
  renderDiagnostic();
  $("errBadge").textContent = S.errors.length ? String(S.errors.length) : "";
}
let runner = null;
const getRunner = () => (runner = runner || new Runner(pushError));

function log(kind, msg) {
  const colors = { info: "#8FA0B8", dim: "#3A4A62", ok: "#3ECF8E", rej: "#F5A524", warn: "#FF6B6B", gen: "#8A7CFF", claude: "#8A7CFF", done: "#3ECF8E" };
  const el = document.createElement("div");
  el.style.color = colors[kind] || "#8FA0B8";
  el.textContent = msg;
  $("logbox").appendChild(el);
  $("logbox").scrollTop = 1e9;
}

/* ══ boucle d'évolution ══ */
async function runEvolution() {
  if (S.running) return;
  S.running = true;
  $("runBtn").textContent = "ÉVOLUTION EN COURS…";
  $("runBtn").disabled = true;
  S.records = []; S.best = null; S.selected = null; S.replay = null; S.report = null; S.pr = null;
  $("logbox").innerHTML = "";
  renderAll();

  const code = $("codeInput").value;
  const gens = parseInt($("gensSel").value, 10);
  const useClaude = $("claudeChk").checked;

  try {
    const r = getRunner();
    // Espace de recherche dérivé de l'INTENTION du code et du profil des
    // données réellement mesurées — aucun couple motif→remplacement.
    let algoCands = [];
    try {
      const sp = await r.call("algo_space", { code: code }, 12000);
      algoCands = sp.candidates || [];
      S.algoSpace = { profile: sp.profile, raw: algoCands, candidates: algoCands.map((c) => ({ strategy: c.strategy, why: c.why, prior: c.prior })) };
      algoCands.forEach((c) => { ALGO_WHY[c.strategy] = c.why; });
      if (algoCands.length) {
        log("gen", "Intention détectée : tri croissant → " + algoCands.length + " implémentations candidates générées");
        log("info", "Profil de données observé : n=" + sp.profile.size + ", étendue=" + sp.profile.valueRange +
          ", unicité=" + sp.profile.uniqueRatio.toFixed(2) + ", tri=" + sp.profile.sortedness.toFixed(2) +
          " → ordre d'exploration : " + algoCands.map((c) => c.strategy.slice(5)).join(" > "));
      }
    } catch (e) { pushError("algo_space", e.message); }
    renderAlgoSpace();

    const arms = RULE_NAMES.concat(algoCands.map((c) => c.strategy)).concat(["claude_refactor"]);
    arms.forEach((a) => { if (!S.priors[a]) S.priors[a] = { n: 0, r: 0 }; });
    const ucb = (a, T) => (S.priors[a].n === 0 ? Infinity : S.priors[a].r / S.priors[a].n + Math.sqrt(2 * Math.log(Math.max(T, 1)) / S.priors[a].n));

    const prof = await r.call("profile", { code: code, samples: 12 }, 15000);
    S.seedInv = prof.invariants;
    const seedLat = prof.lat, seedHash = hashish(code);
    log("ok", "Seed " + seedHash + " : " + mean(seedLat).toFixed(4) + " ms/appel");
    log("info", "Invariants vérifiés du seed : " + (S.seedInv.join(", ") || "(aucun)") + " — deviennent des obligations de preuve");
    log("info", "Oracle : " + S.ces.length + " contre-exemple(s) hérités de la session");
    renderInvariants();

    let pop = [{ id: "seed", hash: seedHash, code: code, lat: seedLat, mean: mean(seedLat), lineage: [], cx: cx(code) }];
    const tried = new Set([code]);
    const sterile = {};

    for (let g = 1; g <= gens; g++) {
      log("gen", "─── GÉNÉRATION " + g + " ───");
      const T = Object.values(S.priors).reduce((a, x) => a + x.n, 0);
      const ordered = arms.slice().sort((a, b) => ucb(b, T) - ucb(a, T));
      const offspring = [];

      for (const parent of pop) {
        if ((sterile[parent.id] || 0) >= 4) { log("dim", parent.id + " : lignée stérile — écartée de la reproduction"); continue; }
        let produced = 0;
        for (const arm of ordered) {
          if (produced >= 2) break;
          let mut = null;
          if (arm === "claude_refactor") {
            if (!useClaude || g > 1) continue;
            log("claude", "Appel Claude (mutation architecturale)…");
            mut = await claudeMutate(parent.code, pushError);
          } else if (arm.indexOf("algo:") === 0) {
            // substitution algorithmique : sur le seed uniquement (le site de
            // tri disparaît après la première substitution)
            if (parent.lineage.some((g) => g.indexOf("algo:") === 0)) continue;
            const c = algoCands.filter((x) => x.strategy === arm)[0];
            mut = c ? c.code : null;
          } else {
            try { mut = (await r.call("mutate", { code: parent.code, rule: arm }, 6000)).code; }
            catch (e) { pushError("mutate", arm + ": " + e.message); mut = null; }
          }
          if (!mut || tried.has(mut)) continue;
          tried.add(mut); produced++;
          S.priors[arm].n++;
          const hash = hashish(mut);
          const priorRejects = S.records.filter((x) => x.arm === arm && x.verdict === "REJET").length;
          const adv = generateAdversarial(parent.code, mut).length;

          let ev;
          try {
            ev = await r.call("evaluate", { seedCode: code, mutCode: mut, seedInvariants: S.seedInv, storedCEs: S.ces, samples: 12 }, 8000);
          } catch (e) {
            sterile[parent.id] = (sterile[parent.id] || 0) + 1;
            S.records.push({ g, arm, parentHash: parent.hash, hash, code: mut, parentCode: parent.code, verdict: "REJET", reason: "exécution impossible : " + e.message, d: null, p: null, priorRejects, oracleSize: S.ces.length, lineage: parent.lineage.concat([arm]), adv });
            log("rej", arm + " : rejet — " + e.message); renderRecords(); continue;
          }

          if (ev.violations.length) {
            sterile[parent.id] = (sterile[parent.id] || 0) + 1;
            S.records.push({ g, arm, parentHash: parent.hash, hash, code: mut, parentCode: parent.code, verdict: "REJET", reason: "invariant violé : " + ev.violations.join(", "), d: null, p: null, priorRejects, oracleSize: S.ces.length, lineage: parent.lineage.concat([arm]), adv, violations: ev.violations });
            log("rej", arm + " : rejet — invariant du seed violé : " + ev.violations.join(", ") + " (le diff de sorties ne l'aurait pas vu)");
            renderRecords(); renderInvariants(); continue;
          }
          if (!ev.fuzz.ok) {
            S.ces.push(ev.fuzz.ce.slice(0, 50));
            sterile[parent.id] = (sterile[parent.id] || 0) + 1;
            S.records.push({ g, arm, parentHash: parent.hash, hash, code: mut, parentCode: parent.code, verdict: "REJET", reason: "divergence sémantique sur " + ev.fuzz.tested + " cas — contre-exemple PERSISTÉ dans l'oracle", d: null, p: null, priorRejects, oracleSize: S.ces.length, lineage: parent.lineage.concat([arm]), adv, ce: ev.fuzz.ce.slice(0, 12), ceId: S.ces.length });
            log("rej", arm + " : rejet — divergence trouvée, contre-exemple ajouté à l'oracle (" + S.ces.length + " au total)");
            renderRecords(); renderOracle(); continue;
          }

          const lat = ev.lat, m = mean(lat);
          const d = (parent.mean - m) / parent.mean * 100;
          const p = welchP(parent.lat, lat);
          const sig = p < 0.05 && m < parent.mean;
          if (sig) S.priors[arm].r += (1 + Math.min(Math.max(d, 0), 100) / 100) / 2;
          const keep = sig || d > -5;
          if (keep) { offspring.push({ id: parent.id + ">" + arm, hash, code: mut, lat, mean: m, lineage: parent.lineage.concat([arm]), cx: cx(mut) }); sterile[parent.id] = 0; }
          else sterile[parent.id] = (sterile[parent.id] || 0) + 1;
          S.records.push({ g, arm, parentHash: parent.hash, hash, code: mut, parentCode: parent.code, verdict: sig ? "ACCEPTÉ" : keep ? "GARDÉ" : "REJET", reason: keep ? null : "régression de performance", d, p, priorRejects, oracleSize: S.ces.length, lineage: parent.lineage.concat([arm]), adv });
          log(sig ? "ok" : keep ? "info" : "rej", arm + " : " + (sig ? "ACCEPTÉ" : keep ? "gardé (Pareto arbitre)" : "rejet") + " Δ " + (d >= 0 ? "+" : "") + d.toFixed(1) + "% p=" + p.toFixed(3));
          renderRecords(); renderPriors();
          await new Promise((res) => setTimeout(res, 0));
        }
      }

      const pool = pop.concat(offspring);
      const dominated = (x) => pool.some((y) => y !== x && y.mean <= x.mean && y.cx <= x.cx && (y.mean < x.mean || y.cx < x.cx));
      const front = pool.filter((x) => !dominated(x));
      pop = front.concat(pool.filter(dominated).sort((a, b) => a.mean - b.mean)).slice(0, 6);
      const b = pop.reduce((a, x) => (x.mean < a.mean ? x : a));
      log("gen", "Gen " + g + " : best " + b.mean.toFixed(4) + " ms (" + ((mean(seedLat) - b.mean) / mean(seedLat) * 100).toFixed(1) + "% vs seed), front Pareto " + front.length);
    }

    const champ = pop.reduce((a, x) => (x.mean < a.mean ? x : a));
    S.best = { code: champ.code, hash: champ.hash, mean: champ.mean, seed: mean(seedLat), seedCode: code, seedHash, lineage: champ.lineage };
    log("done", "TERMINÉ — gain " + ((mean(seedLat) - champ.mean) / mean(seedLat) * 100).toFixed(1) + "% | lignée : " + (champ.lineage.join(" → ") || "(seed intact)"));
    persist();
  } catch (e) {
    log("warn", "Erreur : " + e.message); pushError("run", e.message);
  }
  S.running = false;
  $("runBtn").textContent = "LANCER L'ÉVOLUTION";
  $("runBtn").disabled = false;
  renderAll();
}

/* ══ Time Machine ══ */
async function doReplay() {
  if (!S.best) return;
  $("replayOut").innerHTML = '<span class="dim">replay en cours…</span>';
  try {
    const r = getRunner();
    let current = S.best.seedCode;
    const steps = [];
    for (const gene of S.best.lineage) {
      let next = null;
      if (RULE_NAMES.indexOf(gene) >= 0) {
        try { next = (await r.call("mutate", { code: current, rule: gene }, 6000)).code; } catch (e) { next = null; }
      }
      if (!next) {
        const rec = S.records.filter((x) => x.arm === gene && x.verdict !== "REJET")[0];
        next = rec ? rec.code : null;
      }
      if (!next) continue;
      const ev = await r.call("evaluate", { seedCode: S.best.seedCode, mutCode: next, seedInvariants: S.seedInv, storedCEs: S.ces, samples: 10 }, 8000);
      const eq = ev.violations.length === 0 && ev.fuzz && ev.fuzz.ok;
      steps.push({ gene, eq, lat: eq ? mean(ev.lat) : 0, src: RULE_NAMES.indexOf(gene) >= 0 ? "règle AST ré-appliquée" : "artefact enregistré" });
      if (eq) current = next;
    }
    const a = (await r.call("bench", { code: S.best.seedCode, samples: 10 })).lat;
    const b = (await r.call("bench", { code: current, samples: 10 })).lat;
    const remeasured = (mean(a) - mean(b)) / mean(a) * 100;
    const recorded = (S.best.seed - S.best.mean) / S.best.seed * 100;
    S.replay = { steps, recorded, remeasured, delta: remeasured - recorded };
  } catch (e) { pushError("replay", e.message); S.replay = { error: e.message }; }
  renderReplay();
}

/* ══ rapport scientifique ══ */
async function buildReport() {
  if (!S.best) return;
  $("reportOut").innerHTML = '<span class="dim">ré-mesure indépendante en cours…</span>';
  try {
    const r = getRunner();
    const a = (await r.call("bench", { code: S.best.seedCode, samples: 20 }, 20000)).lat;
    const b = (await r.call("bench", { code: S.best.code, samples: 20 }, 20000)).lat;
    const se = Math.sqrt(sd(a) ** 2 / a.length + sd(b) ** 2 / b.length);
    const diff = mean(a) - mean(b);
    S.report = { a, b, p: welchP(a, b), d: cohensD(a, b), ci: [diff - 1.96 * se, diff + 1.96 * se], gain: diff / mean(a) * 100 };
  } catch (e) { pushError("report", e.message); }
  renderReport();
}

/* ══ PR engine ══ */
/* Validation adversariale de PERFORMANCE : confronte chaque implémentation
   aux distributions conçues pour la mettre en défaut. */
async function runAdversarial() {
  if (!S.algoSpace || !S.algoSpace.raw || !S.algoSpace.raw.length) {
    $("advOut").innerHTML = '<span class="dim">Lance d\'abord une évolution sur un seed contenant un tri : les implémentations à confronter viennent de l\'espace de recherche.</span>';
    return;
  }
  $("advOut").innerHTML = '<span class="dim">confrontation en cours — chaque implémentation face à six distributions conçues pour la faire perdre…</span>';
  try {
    const variants = S.algoSpace.raw.map((c) => ({ name: c.strategy.slice(5), code: c.code }));
    const res = await getRunner().call("adversarial", { variants: variants, n: 1200 }, 60000);
    S.adversarial = { rows: res.rows, meta: res.meta, names: variants.map((v) => v.name) };
  } catch (e) { pushError("adversarial", e.message); }
  renderAdversarial();
}

async function buildPR() {
  if (!S.best) return;
  $("prOut").innerHTML = '<span class="dim">génération et exécution des tests…</span>';
  try {
    const inputs = [[], [0], [-1], [1, 1, 1],
      Array.from({ length: 50 }, (_, i) => 50 - i),
      Array.from({ length: 80 }, (_, i) => (i * 37) % 100 - 50)]
      .concat(generateAdversarial(S.best.seedCode, S.best.code, 20));
    const rows = (await getRunner().call("probes", { seedCode: S.best.seedCode, mutCode: S.best.code, inputs }, 15000)).rows;
    const asserts = rows.map((x) => {
      const call = "processPayload(" + JSON.stringify(x.input) + ")";
      if (x.expected === "NaN") return "  assert.ok(Number.isNaN(" + call + "));";
      if (x.expected === undefined) return "  assert.strictEqual(" + call + ", undefined);";
      return "  assert.deepStrictEqual(" + call + ", " + JSON.stringify(x.expected) + ");";
    });
    const green = rows.filter((x) => x.ok).length, red = rows.length - green;
    const gain = (S.best.seed - S.best.mean) / S.best.seed * 100;
    S.pr = { asserts, green, red, gain, risk: red === 0 && gain >= 5 ? "faible" : "moyen" };
  } catch (e) { pushError("pr", e.message); }
  renderPR();
}

/* ══ auto-tests ══ */
async function runSelfTests() {
  $("selfTestOut").innerHTML = '<span class="dim">exécution…</span>';
  const r = getRunner();
  const out = [];
  const add = (name, ok, detail) => out.push({ name, ok, detail });
  const equiv = (seed, mut, inv) => r.call("evaluate", { seedCode: seed, mutCode: mut, seedInvariants: inv || [], storedCEs: [], samples: 4 }, 10000);

  try {
    const fc = "function processPayload(arr) { return arr.filter(x => x > 10).length + arr.length; }";
    const m = (await r.call("mutate", { code: fc, rule: "intent_filter_count" })).code;
    const e = m ? await equiv(fc, m) : null;
    add("intent_filter_count produit un code équivalent", !!m && e.fuzz.ok && m.indexOf(".filter(") < 0,
      m ? e.fuzz.tested + " cas testés, tableau intermédiaire éliminé" : "la règle n'a pas déclenché");
  } catch (e) { add("intent_filter_count produit un code équivalent", false, e.message); }

  try {
    const mr = "function processPayload(arr) { return arr.map(x => x * x).reduce((a, b) => a + b, 0); }";
    const m = (await r.call("mutate", { code: mr, rule: "intent_map_reduce_fusion" })).code;
    const e = m ? await equiv(mr, m) : null;
    add("intent_map_reduce_fusion fusionne en une passe", !!m && e.fuzz.ok && m.indexOf(".map(") < 0,
      m ? e.fuzz.tested + " cas testés" : "la règle n'a pas déclenché");
  } catch (e) { add("intent_map_reduce_fusion fusionne en une passe", false, e.message); }

  try {
    const m = (await r.call("mutate", { code: BENCHMARKS.BubbleSort, rule: "sort_idiom" })).code;
    const e = m ? await equiv(BENCHMARKS.BubbleSort, m) : null;
    add("sort_idiom : O(n²) → TimSort, équivalence prouvée", !!m && e.fuzz.ok, m ? e.fuzz.tested + " cas testés" : "la règle n'a pas déclenché");
  } catch (e) { add("sort_idiom : O(n²) → TimSort, équivalence prouvée", false, e.message); }

  try {
    const hostile = BENCHMARKS["BubbleSort (style hostile)"];
    const m = (await r.call("mutate", { code: hostile, rule: "sort_idiom" })).code;
    const e = m ? await equiv(hostile, m) : null;
    add("AST : immunité au style (commentaires, var, noms différents)", !!m && e.fuzz.ok,
      m ? "déclenche et reste équivalent sur " + e.fuzz.tested + " cas — une règle regex échouerait ici" : "la règle n'a pas déclenché");
  } catch (e) { add("AST : immunité au style (commentaires, var, noms différents)", false, e.message); }

  try {
    const trap = "function processPayload(arr) { const arr_len = 999; let t = arr_len; for (let i = 0; i < arr.length; i++) { t += arr[i]; } return t; }";
    const m = (await r.call("mutate", { code: trap, rule: "length_caching" })).code;
    const e = m ? await equiv(trap, m) : null;
    add("AST : portées sûres (aucun shadowing du temporaire)", !!m && e.fuzz.ok && m.indexOf("const arr_len = arr.length") < 0,
      m ? "temporaire renommé automatiquement, équivalence préservée" : "la règle n'a pas déclenché");
  } catch (e) { add("AST : portées sûres (aucun shadowing du temporaire)", false, e.message); }

  try {
    const seed = "function processPayload(arr) { const a = arr.slice(); a.sort((x, y) => x - y); return a[0] + a.length; }";
    const mut = "function processPayload(arr) { arr.sort((x, y) => x - y); return arr[0] + arr.length; }";
    const noInv = await equiv(seed, mut, []);
    const withInv = await equiv(seed, mut, ["input_not_mutated", "deterministic"]);
    add("invariant : la mutation EN PLACE passe le fuzzing mais est rejetée",
      noInv.fuzz.ok === true && withInv.violations.indexOf("input_not_mutated") >= 0,
      "fuzzing : " + (noInv.fuzz.ok ? "équivalent" : "divergent") + " | invariants violés : " + (withInv.violations.join(", ") || "aucun"));
  } catch (e) { add("invariant : la mutation EN PLACE passe le fuzzing mais est rejetée", false, e.message); }

  try {
    const orig = "function processPayload(arr) { let c = 0; for (let i = 0; i < arr.length; i++) { if (Math.abs(arr[i]) % 26 < 13) c++; } return c; }";
    const broken = orig.replace("% 26 < 13", "% 26 <= 13");
    const adv = generateAdversarial(orig, broken);
    const ev = await equiv(orig, broken);
    add("oracle génératif : bug de frontière (< → <=) attrapé", !ev.fuzz.ok && adv.some((x) => x.indexOf(13) >= 0),
      "frontière 13 générée : " + (adv.some((x) => x.indexOf(13) >= 0) ? "oui" : "non") + " | contre-exemple : [" + (ev.fuzz.ce || []).slice(0, 6).join(",") + "]");
  } catch (e) { add("oracle génératif : bug de frontière (< → <=) attrapé", false, e.message); }

  try {
    const t0 = performance.now();
    let stopped = false, how = "";
    try { await r.call("bench", { code: "function processPayload(arr) { while (true) {} }", samples: 2 }, 1500); }
    catch (e) {
      stopped = true;
      how = e.message === "timeout" ? "worker tué (terminate)" : "boucle bornée par instrumentation AST";
    }
    add("boucle infinie neutralisée, onglet vivant", stopped,
      how + " en " + (performance.now() - t0).toFixed(0) + "ms — l'UI n'a jamais été bloquée (mode : " + r.mode + ")");
  } catch (e) { add("boucle infinie neutralisée, onglet vivant", false, e.message); }

  S.selfTest = out;
  renderDiagnostic();
}

/* ══ persistance de session ══ */
async function persist() {
  try { await window.storage.set("neuralys:session", JSON.stringify({ priors: S.priors, ces: S.ces })); } catch (e) {}
}
async function restore() {
  try {
    const r = await window.storage.get("neuralys:session");
    if (r && r.value) {
      const d = JSON.parse(r.value);
      S.priors = d.priors || {}; S.ces = d.ces || [];
      renderPriors(); renderOracle();
    }
  } catch (e) {}
}

/* ══ rendu ══ */
function renderRecords() {
  const t = S.records.map((r, i) =>
    '<tr class="clickable" onclick="selectRecord(' + i + ')">' +
    "<td>" + r.g + '</td><td style="color:' + (r.arm.indexOf("intent") === 0 || r.arm === "claude_refactor" ? "#8A7CFF" : "#3ECF8E") + '">' + esc(r.arm) + "</td>" +
    '<td style="color:' + (r.verdict === "REJET" ? "#F5A524" : "#3ECF8E") + '">' + r.verdict + "</td>" +
    "<td>" + (r.d === null ? "—" : (r.d >= 0 ? "+" : "") + r.d.toFixed(1) + "%") + "</td>" +
    "<td>" + (r.p === null ? "—" : r.p.toFixed(3)) + "</td>" +
    '<td class="dim">' + esc(r.reason || "") + "</td></tr>").join("");
  $("recordsBody").innerHTML = t;
  $("recordsCount").textContent = S.records.length;
  renderEcology();
}

function selectRecord(i) {
  S.selected = S.records[i];
  showTab("provenance");
  renderProvenance();
}

function renderProvenance() {
  const r = S.selected;
  if (!r) { $("provOut").innerHTML = '<span class="dim">Sélectionne une mutation dans le tableau de l\'onglet Évolution.</span>'; return; }
  $("provOut").innerHTML =
    '<div class="mono" style="line-height:1.9">' +
    "<div>" + r.parentHash + " → <b style=\"color:" + (r.verdict === "REJET" ? "#F5A524" : "#3ECF8E") + '">' + r.hash + "</b></div>" +
    '<div><span class="dim">mutation :</span> ' + esc(r.arm) + "</div>" +
    '<div><span class="dim">mécanisme :</span> ' + esc(mechanismOf(r.arm)) + "</div>" +
    '<div><span class="dim">verdict :</span> ' + r.verdict + (r.d !== null ? " — gain mesuré " + r.d.toFixed(1) + "%, p=" + r.p.toFixed(4) : "") + (r.reason ? " — " + esc(r.reason) : "") + "</div>" +
    '<div><span class="dim">historique :</span> ' + r.priorRejects + " tentative(s) antérieure(s) de cette stratégie rejetée(s)</div>" +
    '<div><span class="dim">oracle :</span> ' + r.oracleSize + " contre-exemple(s) connus au moment du verdict</div>" +
    '<div><span class="dim">entrées adversariales injectées :</span> ' + (r.adv || 0) + "</div></div>" +
    '<div style="margin-top:14px"><span class="label">Explication mécanistique</span><pre>' + esc(explain(r)) + "</pre></div>" +
    '<div style="margin-top:12px"><button class="btn purple" onclick="narrate()">Explication narrative (Claude)</button><div id="narrOut"></div></div>' +
    '<div style="margin-top:14px"><span class="label">Diff</span><div class="grid2"><pre class="red">' + esc(r.parentCode) + "</pre><pre>" + esc(r.code) + "</pre></div></div>";
}

function mechanismOf(arm) {
  if (arm.indexOf("algo:") === 0) return "substitution algorithmique dérivée de l'intention « tri croissant » — " + (ALGO_WHY[arm] || arm.slice(5));
  return MECHANISMS[arm] || arm;
}

function explain(r) {
  const before = r.parentCode, after = r.code;
  const loops = (c) => (c.match(/\bfor\s*\(|\bwhile\s*\(/g) || []).length;
  const facts = [];
  if (loops(before) > loops(after)) facts.push((loops(before) - loops(after)) + " boucle(s) supprimée(s)");
  const dc = cx(after) - cx(before);
  if (dc !== 0) facts.push("complexité " + (dc > 0 ? "+" : "") + dc);
  const ds = after.replace(/\s+/g, "").length - before.replace(/\s+/g, "").length;
  if (ds !== 0) facts.push("taille " + (ds > 0 ? "+" : "") + ds + " car.");
  return [
    "Gain mesuré : " + (r.d === null ? "n/a" : (r.d >= 0 ? "+" : "") + r.d.toFixed(1) + "% de latence."),
    "— " + r.arm + " : " + mechanismOf(r.arm) + ".",
    facts.length ? "Effets structurels : " + facts.join(", ") + "." : "",
    "Équivalence vérifiée par fuzzing différentiel (familles structurées + oracle génératif + contre-exemples de session) avant acceptation.",
  ].filter(Boolean).join("\n");
}

async function narrate() {
  if (!S.selected) return;
  $("narrOut").innerHTML = '<span class="dim">Claude rédige…</span>';
  const n = await claudeNarrative(explain(S.selected), S.selected.parentCode, S.selected.code, pushError);
  $("narrOut").innerHTML = "<pre class=\"purple\">" + esc(n || "(backend LLM indisponible — l'explication mécanistique ci-dessus est la réponse)") + "</pre>";
}

function renderPriors() {
  const rows = Object.entries(S.priors).filter(([, s]) => s.n > 0)
    .sort((a, b) => b[1].r / Math.max(b[1].n, 1) - a[1].r / Math.max(a[1].n, 1));
  $("priorsBox").innerHTML = rows.length ? rows.map(([a, s]) =>
    '<div style="margin-bottom:6px"><div class="mono flexrow"><span style="color:' + (a === "claude_refactor" || a.indexOf("intent") === 0 ? "#8A7CFF" : "#3ECF8E") + '">' + esc(a) + '</span><span class="dim">' + s.n + " essais · r " + s.r.toFixed(2) + "</span></div>" +
    '<div class="bar"><div class="barfill" style="width:' + Math.min(s.r / Math.max(s.n, 1) * 100, 100) + '%"></div></div></div>').join("")
    : '<span class="dim">Les priors apparaîtront après une évolution. Ils persistent entre les runs et les rechargements.</span>';
}

function renderOracle() {
  $("ceBox").innerHTML = S.ces.length
    ? S.ces.slice(-4).map((c, i) => '<div class="mono orange" style="font-size:10.5px">[' + c.slice(0, 8).join(",") + (c.length > 8 ? "…" : "") + "] (n=" + c.length + ")</div>").join("") +
      '<div class="dim" style="font-size:10.5px;margin-top:4px">Rejoués comme cas obligatoires contre toute mutation future.</div>'
    : '<span class="dim">Aucun contre-exemple encore découvert.</span>';
  const advPreview = generateAdversarial($("codeInput").value, $("codeInput").value).slice(0, 10);
  $("advPreview").innerHTML = advPreview.map((a) =>
    '<span class="chip purple">[' + a.slice(0, 6).join(",") + (a.length > 6 ? "…n=" + a.length : "") + "]</span>").join("");
  $("oracleTable").innerHTML = S.records.map((r) =>
    '<tr><td style="color:' + (r.arm.indexOf("intent") === 0 ? "#8A7CFF" : "#3ECF8E") + '">' + esc(r.arm) + "</td><td>" + (r.adv || 0) + "</td>" +
    '<td style="color:' + (r.verdict === "REJET" ? "#F5A524" : "#3ECF8E") + '">' + r.verdict + "</td>" +
    '<td class="orange">' + (r.ce ? "#" + r.ceId + " [" + r.ce.slice(0, 8).join(",") + "]" : "—") + "</td></tr>").join("");
}

function renderInvariants() {
  $("invList").innerHTML = INVARIANT_META.map(([n, d]) => {
    const held = S.seedInv.indexOf(n) >= 0;
    return '<div style="margin-bottom:8px;opacity:' + (held ? 1 : 0.4) + '"><span class="mono" style="color:' + (held ? "#3ECF8E" : "#5A6B82") + '">' +
      (held ? "✓" : "○") + " " + n + '</span><div class="dim" style="margin-left:16px;font-size:11px">' + esc(d) + "</div></div>";
  }).join("");
  const viol = S.records.filter((r) => r.violations);
  $("invViolations").innerHTML = viol.length
    ? '<span class="label">Mutations rejetées par la couche invariants</span>' +
      viol.map((r) => '<div class="mono orange" style="font-size:11.5px">' + esc(r.arm) + " → viole " + r.violations.join(", ") + "</div>").join("")
    : "";
}

function renderEcology() {
  if (!S.records.length) { $("ecoOut").innerHTML = '<span class="dim">Lance une évolution d\'abord.</span>'; return; }
  const byParent = {};
  S.records.forEach((r) => { (byParent[r.parentHash] = byParent[r.parentHash] || []).push(r); });
  const root = S.best ? S.best.seedHash : S.records[0].parentHash;
  const strategies = new Set(S.records.map((r) => r.arm));
  const accepted = S.records.filter((r) => r.verdict !== "REJET").length;
  const maxDepth = Math.max.apply(null, S.records.map((r) => r.lineage.length));
  const lines = [];
  const walkTree = (h, prefix) => {
    const kids = byParent[h] || [];
    kids.forEach((k, i) => {
      const last = i === kids.length - 1;
      lines.push('<div class="mono" style="color:' + (k.verdict === "REJET" ? "#F5A524" : "#3ECF8E") + '">' +
        esc(prefix + (last ? "└─" : "├─")) + "[" + esc(k.arm) + "] " + (k.verdict === "REJET" ? "✗" : "✓") + " " + k.hash +
        (k.d !== null ? ' <span class="dim">' + (k.d >= 0 ? "+" : "") + k.d.toFixed(1) + "%</span>" : "") + "</div>");
      if (k.ce) lines.push('<div class="mono orange" style="font-size:10.5px">' + esc(prefix + (last ? "   " : "│  ")) + "   └─ contre-exemple #" + k.ceId + " [" + k.ce.join(",") + "]</div>");
      walkTree(k.hash, prefix + (last ? "   " : "│  "));
    });
  };
  walkTree(root, "");
  $("ecoOut").innerHTML =
    '<div class="statrow">' +
    [["ÂGE", maxDepth + " gén."], ["POPULATION", S.records.length], ["ACCEPTÉS", accepted],
     ["DIVERSITÉ", (strategies.size / Math.max(S.records.length, 1)).toFixed(2)], ["ORACLE", S.ces.length + " CE"]]
      .map(([k, v]) => '<div class="stat"><div class="statk">' + k + '</div><div class="statv">' + v + "</div></div>").join("") +
    "</div>" + '<div class="mono dim">' + root + " (seed)</div>" + lines.join("");
}

function renderReplay() {
  const r = S.replay;
  if (!r) { $("replayOut").innerHTML = ""; return; }
  if (r.error) { $("replayOut").innerHTML = '<span class="red">' + esc(r.error) + "</span>"; return; }
  $("replayOut").innerHTML = r.steps.map((s) =>
    '<div class="mono" style="color:' + (s.eq ? "#3ECF8E" : "#F5A524") + '">[' + esc(s.gene) + "] " + (s.eq ? "✓ équivalent" : "✗ divergent") + " · " + s.lat.toFixed(4) + " ms · " + s.src + "</div>").join("") +
    '<div class="mono" style="margin-top:10px;font-size:14px">enregistré <span class="dim">' + r.recorded.toFixed(1) + "%</span> → re-mesuré <b style=\"color:#3ECF8E\">" + r.remeasured.toFixed(1) + "%</b> | écart " +
    '<span style="color:' + (Math.abs(r.delta) < 10 ? "#3ECF8E" : "#F5A524") + '">' + (r.delta >= 0 ? "+" : "") + r.delta.toFixed(1) + ' pts</span> <span class="dim" style="font-size:11px">(résiduel attendu = bruit matériel)</span></div>';
}

function renderReport() {
  const r = S.report;
  if (!r) { $("reportOut").innerHTML = ""; return; }
  const all = r.a.concat(r.b), min = Math.min.apply(null, all), span = Math.max(Math.max.apply(null, all) - min, 1e-9);
  const strip = (vals, label, color) =>
    '<div class="flexrow" style="justify-content:flex-start;gap:8px;margin-bottom:6px"><span class="mono dim" style="width:70px;font-size:10px">' + label + "</span>" +
    '<svg width="360" height="14">' + vals.map((v) => '<circle cx="' + (5 + (v - min) / span * 350) + '" cy="7" r="2.5" fill="' + color + '" opacity="0.8"/>').join("") + "</svg></div>";
  $("reportOut").innerHTML =
    '<table class="tbl" style="max-width:420px;margin-bottom:14px"><thead><tr><th></th><th>Seed</th><th>Champion</th></tr></thead><tbody class="mono">' +
    "<tr><td>Moyenne (ms)</td><td>" + mean(r.a).toFixed(4) + "</td><td>" + mean(r.b).toFixed(4) + "</td></tr>" +
    "<tr><td>Écart-type</td><td>" + sd(r.a).toFixed(4) + "</td><td>" + sd(r.b).toFixed(4) + "</td></tr>" +
    "<tr><td>n</td><td>20</td><td>20</td></tr></tbody></table>" +
    '<div class="mono" style="line-height:2">' +
    '<div>Gain : <b style="color:#3ECF8E">' + r.gain.toFixed(1) + "%</b></div>" +
    "<div>Welch t-test : p = " + r.p.toExponential(2) + " " + (r.p < 0.05 ? "✓ significatif" : "— non significatif") + "</div>" +
    "<div>Cohen's d = " + r.d.toFixed(2) + " (" + (Math.abs(r.d) > 0.8 ? "effet large" : Math.abs(r.d) > 0.5 ? "effet moyen" : "effet faible") + ")</div>" +
    "<div>IC 95% de la différence : [" + r.ci[0].toFixed(4) + " ; " + r.ci[1].toFixed(4) + "] ms</div></div>" +
    '<div style="margin-top:14px"><span class="label">Distributions de latence</span>' + strip(r.a, "Seed", "#c0392b") + strip(r.b, "Champion", "#27ae60") + "</div>" +
    '<div style="margin-top:14px"><span class="label">Explication mécanistique</span><pre>' + esc(S.best.lineage.map((g) => "— " + g + " : " + mechanismOf(g) + ".").join("\n") || "(seed intact)") + "</pre></div>";
}

function renderPR() {
  const r = S.pr;
  if (!r) { $("prOut").innerHTML = ""; return; }
  $("prOut").innerHTML =
    '<div class="statrow">' +
    [["TESTS GÉNÉRÉS", r.asserts.length, "#3ECF8E"], ["VERTS", r.green, "#3ECF8E"], ["ROUGES", r.red, r.red ? "#FF6B6B" : "#5A6B82"],
     ["GAIN", r.gain.toFixed(1) + "%", "#3ECF8E"], ["RISQUE", r.risk, r.risk === "faible" ? "#3ECF8E" : "#F5A524"]]
      .map(([k, v, c]) => '<div class="stat"><div class="statk">' + k + '</div><div class="statv" style="color:' + c + '">' + v + "</div></div>").join("") + "</div>" +
    '<span class="label">Corps de PR</span><pre>' + esc([
      "# Neuralys — Optimisations automatiques", "",
      "- **Tests de régression générés** : " + r.asserts.length + " assertions (comportement original figé, frontières incluses)",
      "- **Résultat sur le code patché** : " + r.green + " vertes / " + r.red + " rouges",
      "- **Gain CPU mesuré** : " + r.gain.toFixed(1) + "% (Welch p<0.05 à l'acceptation)",
      "- **Invariants du seed préservés** : " + (S.seedInv.join(", ") || "(aucun)"),
      "- **Risque** : " + r.risk, "",
      "## Lignée", S.best.lineage.join(" → ") || "(seed)",
    ].join("\n")) + "</pre>" +
    '<span class="label" style="margin-top:12px">Tests générés (extrait)</span><pre style="max-height:200px;overflow:auto">' +
    esc(r.asserts.slice(0, 12).join("\n") + (r.asserts.length > 12 ? "\n… +" + (r.asserts.length - 12) + " assertions" : "")) + "</pre>";
}

function renderDiagnostic() {
  $("errList").innerHTML = S.errors.length
    ? S.errors.slice(-12).map((e) => '<div class="mono red" style="font-size:11.5px"><span class="dim">' + e.at + "</span> [" + esc(e.stage) + "] " + esc(e.message) + "</div>").join("")
    : '<span class="dim">Aucune erreur enregistrée. Compilations ratées, timeouts, échecs API et erreurs worker apparaîtront ici.</span>';
  $("errCount").textContent = S.errors.length;
  if (S.selfTest) {
    const ok = S.selfTest.filter((t) => t.ok).length;
    $("selfTestOut").innerHTML =
      '<div class="mono" style="font-size:13px;margin-bottom:8px;color:' + (ok === S.selfTest.length ? "#3ECF8E" : "#F5A524") + '">' + ok + "/" + S.selfTest.length + " tests verts</div>" +
      S.selfTest.map((t) => '<div style="margin-bottom:8px"><div class="mono" style="color:' + (t.ok ? "#3ECF8E" : "#FF6B6B") + '">' +
        (t.ok ? "✓" : "✗") + " " + esc(t.name) + '</div><div class="dim" style="margin-left:16px;font-size:11px">' + esc(t.detail) + "</div></div>").join("");
  }
  $("sessionInfo").textContent = Object.keys(S.priors).length + " stratégie(s) avec historique, " + S.ces.length + " contre-exemple(s).";
}

function renderChampion() {
  if (!S.best) { $("champBox").innerHTML = ""; return; }
  const gain = (S.best.seed - S.best.mean) / S.best.seed * 100;
  $("champBox").innerHTML =
    '<span class="label">Champion ' + S.best.hash + " — " + S.best.seed.toFixed(4) + " → " + S.best.mean.toFixed(4) + " ms (" + gain.toFixed(1) + "%)</span>" +
    '<div style="margin-bottom:8px">' + (S.best.lineage.length
      ? S.best.lineage.map((g) => '<span class="chip green">' + esc(g) + "</span>").join("")
      : '<span class="dim">Seed intact — aucune mutation n\'a battu l\'original (verdict honnête)</span>') + "</div>" +
    "<pre>" + esc(S.best.code) + "</pre>";
}

function renderAlgoSpace() {
  const a = S.algoSpace;
  if (!a) { $("algoOut").innerHTML = '<span class="dim">Lance une évolution sur un seed contenant un tri (BubbleSort) pour voir l\'espace de recherche se générer.</span>'; return; }
  if (!a.candidates.length) { $("algoOut").innerHTML = '<span class="dim">Aucune intention algorithmique reconnue dans ce seed — le moteur retombe sur les règles de réécriture locales.</span>'; return; }
  const p = a.profile;
  const traits = [];
  if (p.sortedness > 0.9) traits.push("presque trié");
  if (p.uniqueRatio < 0.3) traits.push("nombreux doublons");
  if (p.valueRange <= 4 * p.size) traits.push("petite étendue");
  if (!p.integersOnly) traits.push("valeurs non entières");
  const measured = {};
  S.records.filter((r) => r.arm.indexOf("algo:") === 0).forEach((r) => { measured[r.arm] = r; });
  $("algoOut").innerHTML =
    '<div class="statrow">' +
    [["INTENTION", "tri croissant"], ["TAILLE", p.size], ["ÉTENDUE", p.valueRange],
     ["UNICITÉ", p.uniqueRatio.toFixed(2)], ["TRI INITIAL", (p.sortedness * 100).toFixed(0) + "%"]]
      .map(([k, v]) => '<div class="stat"><div class="statk">' + k + '</div><div class="statv">' + v + "</div></div>").join("") + "</div>" +
    (traits.length ? '<div class="note">Traits détectés : <b>' + traits.join(", ") + "</b> — ils déterminent l'ordre d'exploration, pas le résultat : c'est la mesure qui tranche.</div>" : "") +
    '<table class="tbl"><thead><tr><th>Implémentation</th><th>Priorité a priori</th><th>Justification</th><th>Mesuré</th></tr></thead><tbody>' +
    a.candidates.map((c) => {
      const m = measured[c.strategy];
      return "<tr><td " + (m && m.verdict === "ACCEPTÉ" ? 'style="color:#3ECF8E"' : "") + ">" + esc(c.strategy.slice(5)) + "</td>" +
        "<td>" + c.prior.toFixed(2) + "</td>" +
        '<td class="dim">' + esc(c.why) + "</td>" +
        "<td>" + (m ? (m.d !== null ? (m.d >= 0 ? "+" : "") + m.d.toFixed(1) + "% · " + m.verdict : m.verdict) : "—") + "</td></tr>";
    }).join("") + "</tbody></table>" +
    '<div class="note" style="margin-top:12px">Limite à connaître : l\'implémentation retenue est optimale <b>pour ce profil de données</b>. Si la distribution de production diffère du corpus de mesure, le choix peut être mauvais — le profil est donc reporté, jamais tu.</div>';
}

function renderAdversarial() {
  const a = S.adversarial;
  if (!a) { $("advOut").innerHTML = ""; return; }
  const worst = {};
  a.names.forEach((n) => { worst[n] = 0; });
  a.rows.forEach((r) => a.names.forEach((n) => { if (r.times[n] !== null && r.times[n] > worst[n]) worst[n] = r.times[n]; }));
  const ranked = Object.entries(worst).sort((x, y) => x[1] - y[1]);
  const bestName = ranked[0][0];
  $("advOut").innerHTML =
    '<table class="tbl" style="margin-bottom:14px"><thead><tr><th>Jeu adversarial</th><th>Classe</th>' +
    a.names.map((n) => "<th>" + esc(n.slice(0, 10)) + "</th>").join("") + "</tr></thead><tbody>" +
    a.rows.map((r) => {
      const vals = a.names.map((n) => r.times[n]).filter((v) => v !== null);
      const best = Math.min.apply(null, vals), bad = Math.max.apply(null, vals);
      return "<tr><td>" + esc(r.dataset) + '</td><td class="dim">' + esc(r.profileClass) + "</td>" +
        a.names.map((n) => {
          const v = r.times[n];
          if (v === null) return '<td class="red">ERR</td>';
          const color = v === best ? "#3ECF8E" : v === bad ? "#FF6B6B" : "#8FA0B8";
          return '<td style="color:' + color + '">' + v.toFixed(3) + "</td>";
        }).join("") + "</tr>";
    }).join("") + "</tbody></table>" +
    '<span class="label">Pire cas par implémentation — la grandeur qui compte</span>' +
    '<table class="tbl"><thead><tr><th>Implémentation</th><th>Pire cas</th><th>Complexité</th><th>Mémoire</th></tr></thead><tbody>' +
    ranked.map(([n, v]) => "<tr><td " + (n === bestName ? 'style="color:#3ECF8E"' : "") + ">" + esc(n) + "</td>" +
      "<td>" + v.toFixed(3) + " ms</td>" +
      '<td class="dim">' + esc((a.meta[n] || {}).time || "?") + "</td>" +
      '<td class="dim">' + esc((a.meta[n] || {}).memory || "?") + "</td></tr>").join("") + "</tbody></table>" +
    '<div class="note" style="margin-top:12px">Lecture : chaque implémentation figée s\'effondre sur au moins une distribution — c\'est précisément ce que ces jeux cherchent. Le génome adaptatif ne gagne pas partout, il <b>borne son pire cas</b>. C\'est un compromis de Pareto, pas une domination : le moteur l\'expose au lieu de le trancher à ta place.</div>';
}

function renderAll() { renderAlgoSpace(); renderAdversarial(); renderRecords(); renderPriors(); renderOracle(); renderInvariants(); renderChampion(); renderDiagnostic(); renderProvenance(); renderReplay(); renderReport(); renderPR(); }

function showTab(name) {
  document.querySelectorAll(".tabpane").forEach((el) => (el.style.display = el.id === "tab-" + name ? "block" : "none"));
  document.querySelectorAll(".tabbtn").forEach((el) => el.classList.toggle("active", el.dataset.tab === name));
}

/* ══ init ══ */
window.addEventListener("DOMContentLoaded", () => {
  const sel = $("benchChips");
  Object.keys(BENCHMARKS).forEach((k, i) => {
    const b = document.createElement("span");
    b.className = "chip" + (i === 0 ? " active" : "");
    b.textContent = k;
    b.onclick = () => {
      if (S.running) return;
      document.querySelectorAll("#benchChips .chip").forEach((c) => c.classList.remove("active"));
      b.classList.add("active");
      $("codeInput").value = BENCHMARKS[k];
      renderOracle();
    };
    sel.appendChild(b);
  });
  $("codeInput").value = BENCHMARKS.BubbleSort;
  $("runBtn").onclick = runEvolution;
  $("replayBtn").onclick = doReplay;
  $("reportBtn").onclick = buildReport;
  $("prBtn").onclick = buildPR;
  $("selfTestBtn").onclick = runSelfTests;
  $("advBtn").onclick = runAdversarial;
  $("resetBtn").onclick = () => { S.priors = {}; S.ces = []; S.errors = []; persist(); renderAll(); };
  $("exportBtn").onclick = () => {
    const blob = new Blob([JSON.stringify({ priors: S.priors, ces: S.ces, records: S.records, best: S.best }, null, 2)], { type: "application/json" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob); a.download = "neuralys-session.json"; a.click();
  };
  $("limitInput").addEventListener("input", (e) => {
    const v = e.target.value.trim();
    if (!v) { $("limitOut").innerHTML = ""; return; }
    const rs = analyzeEligibility(v);
    const el = rs.filter((r) => r.eligible).length;
    $("limitOut").innerHTML =
      '<div class="mono" style="font-size:14px;margin-bottom:8px"><b style="color:' + (el ? "#3ECF8E" : "#F5A524") + '">' + el + "/" + rs.length + "</b> " +
      '<span class="dim">fonctions éligibles = ' + (rs.length ? (el / rs.length * 100).toFixed(1) : "0.0") + "%</span></div>" +
      '<table class="tbl"><thead><tr><th>Fonction</th><th>Verdict</th><th>Motif</th></tr></thead><tbody>' +
      rs.slice(0, 25).map((r) => "<tr><td>" + esc(r.name) + '</td><td style="color:' + (r.eligible ? "#3ECF8E" : "#F5A524") + '">' +
        (r.eligible ? "ÉLIGIBLE" : "exclue") + '</td><td class="dim">' + esc(r.reason) + "</td></tr>").join("") + "</tbody></table>";
  });
  document.querySelectorAll(".tabbtn").forEach((el) => (el.onclick = () => showTab(el.dataset.tab)));
  showTab("evolution");
  restore();
  renderAll();
  getRunner(); // détecte immédiatement le mode d'exécution disponible
});
