# Neuralys

Moteur d'évolution darwinienne pour le logiciel : mutations vérifiées, sélection
multi-objectifs, mémoire génétique persistante.

Ce n'est pas un système cognitif, pas une AGI, pas une architecture cybernétique.
C'est un optimiseur évolutif avec preuves statistiques et garanties d'équivalence
comportementale — le seul vocabulaire qui décrit ce que le code fait réellement.

## Ce que le moteur fait

- **Mutations** : 9 règles AST (reconnaissance d'idiomes + compréhension d'intention),
  optionnellement complétées par des réécritures LLM (Claude, ensemble multi-modèles).
- **Vérification** : fuzzing différentiel + oracle génératif (boundary value analysis)
  + invariants vérifiés du seed. Une mutation ne survit que si elle est prouvée
  équivalente ET mesurée plus rapide.
- **Sélection** : NSGA-II sur [latence, mémoire, maintenabilité, taille], bandits
  UCB1/Thompson avec priors persistants, méta-évolution de la politique.
- **Mémoire** : graphe génétique SQLite (lignées, contre-exemples, provenance),
  transférable entre machines (fédération) et entre projets (signatures de code).

## Périmètre honnête

Le harnais actuel évalue des **fonctions pures sur des tableaux de nombres**
(`f(number[]) -> valeur`). Le code avec I/O, état partagé, effets de bord, async
ou types complexes est **exclu par le filtre d'éligibilité**, pas optimisé
incorrectement. Voir `AUDIT.md` pour la mesure du taux d'éligibilité sur du code réel
et `LIMITS.md` pour le modèle de menace du bac à sable.

## Utilisation

```bash
npm install
npm test                              # 26 tests (unitaires + intégration)
npx tsx cli.ts evolve <fichier.ts>    # faire évoluer une fonction
npx tsx cli.ts pr <chemin/repo>       # dépôt Git -> branche + patch + tests générés
npx tsx cli.ts invariants <fichier>   # extraire les invariants vérifiés
npx tsx cli.ts blame <hash>           # provenance d'une mutation
npx tsx src/api/server.ts             # API REST
```
