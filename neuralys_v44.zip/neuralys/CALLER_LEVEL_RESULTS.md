# Optimisation au niveau appelant — résultat positif, mesuré

Suite au résultat négatif de v39 (les règles visant des motifs naïfs ne
s'appliquent qu'à 2 fonctions de bibliothèque sur 499), la classe de mutations
manquante a été identifiée puis construite : **le gain applicatif n'est pas
dans `orderBy`, il est dans le fait de l'appeler douze fois sur des données
inchangées.**

## 1. Étude de prévalence, menée AVANT d'écrire la règle

Deux motifs recherchés : appels strictement identiques répétés dans une même
fonction, et appels dont tous les arguments sont invariants dans une boucle.

| Projet | Fonctions | Appels dupliqués | Appels invariants en boucle |
|---|---|---|---|
| lodash | 321 | 16 | 10 |
| express | 12 | 4 | 0 |
| astring | 11 | 1 | 4 |
| acorn | 8 | 0 | 0 |
| **Neuralys `src/` (code applicatif)** | **421** | **131** | **86** |

Le motif est environ **dix fois plus dense dans du code applicatif que dans du
code de bibliothèque** — y compris dans mon propre source, écrit sans aucune
intention de démontrer cette règle. C'est ce qui justifie la classe, et c'est
la différence avec les motifs naïfs de v39 dont la prévalence réelle était nulle.

## 2. Condition de sûreté : la pureté est OBSERVÉE, jamais supposée

Hisser ou factoriser un appel n'est correct que si la fonction appelée est
pure. Aucune liste écrite à la main : l'enregistreur de charge compare l'état
des arguments **avant et après** chaque appel (non-mutation) et vérifie que
les mêmes arguments produisent toujours le même résultat (déterminisme).

Vérifié sur une charge lodash réelle : **16 fonctions observées pures,
`_.merge` correctement détectée comme impure** (elle modifie son premier
argument). Contrôle négatif verrouillé par test : un appel à `merge` est
**refusé** au hissage, et en l'absence totale de preuve la règle refuse aussi.

## 3. Mesure

Cible : fonction de reporting appelant lodash (groupBy, mapValues, sumBy,
orderBy) dans une boucle de passes — la forme qu'a réellement ce type de code.

| | Latence | Sorties |
|---|---|---|
| Référence | 33,42 ms | — |
| `hoist_invariant_call` (une application) | 29,39 ms (**−12,1 %**) | identiques |
| Applications composées | **3,45 ms (−89,7 %)** | identiques |

Le facteur ~10 vient d'un fait simple : les appels coûteux étaient réévalués à
chaque passe alors que leurs arguments ne changeaient pas.

## 4. Détection sur du code réel non préparé

`neuralys caller-scan src` : **112 appels hissables + 100 factorisables**
détectés dans le source de Neuralys. Sur lodash : 10 + 15. Sur express : 0 + 3.

Nuance à ne pas escamoter : détecter n'est pas transformer. Avec la preuve de
pureté disponible dans ce conteneur, seuls 15 de ces sites franchissent la
condition de sûreté. Élargir la transformation exige d'enregistrer une charge
qui exerce les fonctions appelées — c'est le prix de la sûreté, et il est
explicite.

## 5. Reproduire

```bash
npx tsx cli.ts workload lodash workloads/lodash_driver.cjs   # pureté observée
npx tsx cli.ts caller-scan src                               # sites détectés
npm test                                                     # 41 tests
```
