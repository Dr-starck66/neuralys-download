# Validation externe : la CI des projets comme oracle

Question posée : *Neuralys peut-il produire, sans intervention humaine, des
pull requests d'optimisation qui passent la CI d'origine du projet ?*

Protocole : dépôts clonés depuis GitHub avec leur suite de tests, dépendances
installées, lanceur découvert automatiquement, tests exécutés sous
instrumentation pour construire la base de rejeu, mutations générées, puis
**suite complète ré-exécutée** avec chaque mutation en place.

## Réponse

**Oui pour la correction — mais « passer la CI » ne suffit pas.**

9 mutations sur 9 prouvées équivalentes ont fait passer l'intégralité de la
suite de tests du projet, sur 3 dépôts. Et **2 d'entre elles sont des
régressions de performance** (−11,6 % et −4,0 % sur `sum`). La CI est un oracle
de **correction**, pas de performance. L'acceptation exige désormais les deux
preuves : suite verte **et** gain mesuré.

## Résultats

| Dépôt | Tests | CI référence | CI sous instrumentation | Fonctions instrumentées | Rejouables | Couverture |
|---|---|---|---|---|---|---|
| simple-statistics | 278 | verte | **verte** | 135 | **80** | **59,3 %** |
| statuses | 23 | verte | **verte** | 63 | 7 | 11,1 % |
| escape-html | 30 | verte | **verte** | 69 | 1 | 1,4 % |
| **Total** | 331 | 3/3 | **3/3** | 267 | 88 | **33,0 %** |

La suite reste verte sous instrumentation sur les trois dépôts : l'enveloppement
préserve la sémantique observable, y compris sur 278 tests d'un module ES.

### Progression du KPI de couverture

| Harnais | Couverture de rejeu |
|---|---|
| Synthétique (v42) | 0,9 % |
| Scénarios écrits à la main (v43) | 8,1 % |
| **Tests du projet (v44)** | **33,0 %** — et **59,3 %** sur le dépôt le mieux testé |

Le levier annoncé comme dominant l'était : brancher la suite de tests multiplie
la couverture par 4 sans changer une ligne du moteur.

### Mutations ayant survécu à la CI

| Dépôt | Fonction | Stratégie | CI | Gain mesuré |
|---|---|---|---|---|
| simple-statistics | `quantile` | hissage de `.length` invariant | verte | **+32,3 %** |
| simple-statistics | `sum` | hissage de `.length` invariant | verte | **−11,6 %** (régression) |
| simple-statistics | `sum` | élimination de sous-expression commune | verte | **−4,0 %** (régression) |
| simple-statistics | `permutationTest` | hissage d'appel invariant | verte | non mesurable |
| simple-statistics | `kernelDensityEstimation`, `fillMatrices`, `fillMatrixColumn` | hissage / CSE | verte | non mesurable |
| escape-html | `escapeHtml` (×2) | accumulation → join, hissage | verte | non mesurable |

« Non mesurable » = fonction non exportée au niveau du point d'entrée : le banc
par rejeu ne peut pas l'appeler dans son module. Ce n'est pas un gain nul,
c'est une absence de mesure — et elle interdit l'acceptation.

**Une seule mutation qualifie pour une pull request** : `quantile`, +32,3 %,
suite de 278 tests verte.

## Correction méthodologique en cours de route

Première version : la performance était mesurée par la **durée de la suite de
tests**. Résultats obtenus : de −6,3 % à +4,7 % sans rapport avec la mutation.
Cause : la durée d'une suite est dominée par le démarrage du processus et le
chargement des fichiers ; la fonction mutée y pèse quelques microsecondes.
Remplacé par une mesure **par fonction, dans son module réel**, en rejouant les
arguments réellement observés pendant les tests.

## Ce qui bloque encore

1. **Fonctions non exportées** — 6 des 9 mutations survivantes ne sont pas
   mesurables parce que le banc appelle le point d'entrée du paquet. Remède :
   mesurer par instrumentation temporelle in situ plutôt que par appel externe.
2. **Couverture 33 %, pas 80 %** — `statuses` (11,1 %) et `escape-html` (1,4 %)
   sont des paquets minuscules dont la majorité des fonctions instrumentées
   proviennent de leurs dépendances de test, jamais appelées. La couverture
   utile suit la couverture de tests du projet ; `simple-statistics` atteint
   59,3 %.
3. **Génération de mutations** — 9 candidats sur 88 fonctions rejouables. Le
   verrou se déplace à nouveau vers la bibliothèque de règles, qui reste
   pauvre sur du code de production.

## Reproduire

```bash
git clone --depth 1 https://github.com/simple-statistics/simple-statistics /tmp/extval/simple-statistics
cd /tmp/extval/simple-statistics && npm install
cd <neuralys> && npx tsx run_ci_validation.ts
```
