# Contrôle méthodologique du gain de −89 %

Cinq menaces à la validité de la mesure, testées une par une. Toutes les
valeurs ci-dessous proviennent d'exécutions, pas d'estimations.

## 1. Le mécanisme, vérifié SANS horloge

La vérification la plus solide n'utilise aucun chronomètre : on compte les
appels réellement effectués, en instrumentant lodash.

| Appel | Référence | Optimisé |
|---|---|---|
| `groupBy` | 12 | **1** |
| `orderBy` | 12 | **1** |
| `sumBy` | 48 | 37 |
| `mapValues` | 12 | 12 |
| **Total** | **84** | **51** (facteur 1,6×) |

**Apparente contradiction** : 1,6× moins d'appels ne peut pas produire 8,9×
moins de temps. Résolution par attribution du coût unitaire, mesurée
séparément sur n=4000 :

| Appel | Coût unitaire | Part d'une passe |
|---|---|---|
| `orderBy` | 2,181 ms | **87,7 %** |
| `groupBy` | 0,145 ms | 5,8 % |
| `mapValues` | 0,082 ms | 3,3 % |
| `sumBy` | 0,080 ms | 3,2 % |

Modèle : référence = 12 × 2,489 ms = **29,9 ms** ; optimisé = 12 × mapValues +
1 × (groupBy + orderBy + sumBy) = **3,4 ms** ; facteur attendu **8,8×**.
Facteur mesuré : **8,9×**. Théorie et mesure concordent à 1 % près.

Le gain ne vient donc pas du nombre d'appels supprimés mais de leur COÛT :
les deux appels hissés sont les plus chers. Formulation corrigée.

`mapValues` n'est volontairement pas hissée : son second argument est une
fonction fléchée dont je ne peux pas prouver la pureté. Refus conservateur.

## 2. Résolution de l'horloge

`process.hrtime.bigint()` : granularité médiane mesurée **97 ns**. La durée la
plus courte mesurée (~3 ms) vaut **3,1 × 10⁴ fois** la granularité. Menace écartée.

## 3. Élimination de code mort

Contrôle : chaque exécution consommée dans un accumulateur (`SINK`) versus
résultat ignoré. Écart entre les deux régimes : **< 1 point** (88,8 % contre
89,0 %). Le puits final est non nul (266 987 818), donc les résultats sont bien
consommés. Aucun artefact d'élimination.

Durcissement appliqué au moteur : `SandboxRunner` accumule désormais le
résultat de **chaque** répétition, pas seulement la dernière.

## 4-5. JIT et stabilité — balayage complet

| Échauffement | Répétitions | Consommé | Référence (min) | Optimisé (min) | Gain |
|---|---|---|---|---|---|
| 0 | 5 | non | 54,80 | 5,798 | 89,4 % |
| 0 | 5 | oui | 54,01 | 6,050 | 88,8 % |
| 5 | 8 | non | 53,94 | 6,159 | 88,6 % |
| 5 | 8 | oui | 55,05 | 6,312 | 88,5 % |
| 50 | 20 | non | 54,77 | 6,035 | 89,0 % |
| 50 | 20 | oui | 54,65 | 6,128 | 88,8 % |
| 200 | 50 | non | 55,17 | 6,184 | 88,8 % |
| 200 | 50 | oui | 54,18 | 5,706 | **89,5 %** |

Le gain reste dans **[88,5 % ; 89,5 %]** sur toute la plage : de 0 à 200
échauffements, de 5 à 50 répétitions, résultat consommé ou non. Écarts-types
inter-campagnes : ±0,56 à ±3,49 ms sur la référence, ±0,12 à ±1,86 ms sur
l'optimisé.

Absence d'effet JIT différentiel ici, contrairement au biais découvert en v38
(échauffement 3 → 30) : ce biais frappe quand les deux variantes ont des
tailles de code très différentes ; ici elles sont comparables.

## Conclusion

Le gain de **−89 %** résiste aux cinq contrôles. La correction apportée porte
sur l'EXPLICATION, pas sur le chiffre : le gain provient du coût des appels
éliminés, non de leur nombre.
