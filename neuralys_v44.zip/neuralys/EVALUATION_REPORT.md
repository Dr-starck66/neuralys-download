# Neuralys généralise-t-il ? — évaluation sur 15 dépôts open source

Protocole reproductible : `npx tsx run_evaluation.ts` (résultats bruts dans
`evaluation_results.json`). Aucun dépôt n'a été choisi après coup ; aucun
n'est écarté parce qu'il donne un mauvais résultat.

## Réponse

**NON.** Sur 15 dépôts sans lien entre eux, **un seul** a reçu au moins une
mutation acceptée. Intervalle de confiance de Wilson à 95 % sur le taux de
dépôts améliorables : **1,2 % – 29,8 %**. Rien dans ces données ne permet
d'affirmer que le système améliore du logiciel de production de façon répétée.

## Résultats par dépôt

| Dépôt | Fichiers | Fonctions | Points chauds | Évaluables | Mutations tentées | Prouvées | Acceptées |
|---|---|---|---|---|---|---|---|
| lodash | 400 | 320 | 90 | 0 | 1 | 0 | 0 |
| express | 6 | 11 | 3 | 0 | 1 | 0 | 0 |
| acorn | 3 | 44 | 11 | 0 | 1 | 0 | 0 |
| astring | 2 | 19 | 11 | 0 | 1 | 0 | 0 |
| commander | 6 | 7 | 1 | 0 | 1 | 0 | 0 |
| **simple-statistics** | 98 | 114 | 66 | **4** | **61** | **6** | **3** |
| qs | 5 | 0 | 0 | 0 | 0 | 0 | 0 |
| semver | 49 | 0 | 0 | 0 | 0 | 0 | 0 |
| ms | 1 | 4 | 0 | 0 | 0 | 0 | 0 |
| bytes | 1 | 3 | 0 | 0 | 0 | 0 | 0 |
| statuses | 1 | 5 | 0 | 0 | 0 | 0 | 0 |
| cookie | 1 | 9 | 4 | 0 | 2 | 0 | 0 |
| escape-html | 1 | 1 | 1 | 1 | 2 | 0 | 0 |
| content-type | 1 | 7 | 5 | 0 | 2 | 0 | 0 |
| picomatch | 5 | 0 | 0 | 0 | 0 | 0 | 0 |

*(`qs`, `semver`, `picomatch` : 0 fonction comptée — ces paquets n'exposent que
des fonctions fléchées ou des méthodes de classe, formes que l'inventaire ne
couvre pas. C'est une limite de l'analyseur, elle est comptée comme telle.)*

## Agrégat

| Indicateur | Valeur | IC 95 % |
|---|---|---|
| Fonctions analysées | 544 | — |
| Points chauds détectés | 192 | — |
| **Évaluables par le harnais** | **5 / 544 = 0,9 %** | **[0,4 ; 2,1]** |
| Mutations tentées | 72 | — |
| Mutations réellement testées | 6 | — |
| Taux de preuve sémantique | 100 % (6/6) | [61,0 ; 100] |
| Taux d'acceptation | 50 % (3/6) | [18,8 ; 81,2] |
| Dépôts améliorés | 1 / 15 = 6,7 % | [1,2 ; 29,8] |
| Gain moyen des acceptées | 5,4 % | bootstrap [4,7 ; 6,0], n=3 |
| Pull requests générées | 3 | — |

## Les trois mutations retenues — preuve concrète

```
simple-statistics/sum                — common_subexpression_elimination : +6,0 %
simple-statistics/uniqueCountSorted  — loop_invariant_length_caching    : +5,4 %
simple-statistics/sum                — loop_invariant_length_caching    : +4,7 %
```

Gains réels, prouvés équivalents, mais d'un ordre de grandeur (5 %) sans
rapport avec les 89 % du cas appelant ou les 97 % du corpus synthétique.

## Où est exactement la limite

Le goulot n'est ni la génération de mutations, ni la preuve (100 % de succès
sur les mutations réellement testées), ni la mesure. Il est en amont :

> **0,9 % des fonctions de production sont exécutables par le harnais.**
> [IC 95 % : 0,4 – 2,1]

Sur 72 mutations engendrées, **6 seulement** ont pu être soumises à l'oracle.
Les 66 autres portaient sur des fonctions que le harnais ne sait pas appeler :
arité multiple, dépendances internes, méthodes de classe, fonctions fléchées,
état ou effets de bord.

Le seul dépôt qui a fonctionné, `simple-statistics`, est une bibliothèque de
fonctions numériques pures prenant un tableau — c'est-à-dire **exactement la
forme que le harnais présuppose**. Le système réussit là où le code ressemble à
ses hypothèses, et cette forme est rare.

## Recherche nécessaire pour lever la limite

Par ordre de valeur attendue :

1. **Généraliser l'exécution : synthèse d'appelants depuis une charge réelle.**
   L'enregistreur de charge (v39) sait déjà capturer arguments et résultats
   réels, tous types et toutes arités confondus. Il faut le brancher sur
   l'évaluation : au lieu de synthétiser des entrées, rejouer les appels
   observés. Cela ferait passer le taux d'évaluabilité de 0,9 % à « toute
   fonction couverte par une charge », soit typiquement la couverture de la
   suite de tests du projet. **C'est le seul verrou qui déplace l'ordre de
   grandeur.** Coût : un scénario d'exécution par dépôt.
2. **Inventaire complet des formes de fonctions** — fonctions fléchées,
   méthodes de classe, exports d'objets. Trois dépôts sur quinze comptent
   zéro fonction pour cette seule raison.
3. **Mutations proposées par LLM sur les points chauds réels.** 192 points
   chauds détectés, 72 mutations engendrées : la bibliothèque de règles n'a
   presque rien à proposer sur du code déjà optimisé. Un générateur non
   pré-encodé est nécessaire ; la vérification, elle, existe déjà.

## Ce que cette évaluation ne dit pas

Elle ne réfute pas les gains mesurés ailleurs : les 89 % au niveau appelant
(v40, contrôlés en v41) portent sur une classe de mutation que ce protocole
n'exerce presque pas, faute de code appelant dans des bibliothèques. Elle
établit une chose précise et suffisante : **sur du code de bibliothèque de
production, dans l'état actuel, le système n'améliore pas de façon répétée.**
