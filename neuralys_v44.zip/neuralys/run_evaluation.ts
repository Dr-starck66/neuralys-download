import { EvaluationSuite } from './src/tools/evaluation_suite.ts';
import { CallRecorder } from './src/tools/workload_analyzer.ts';
import { createRequire } from 'module';
import * as fs from 'fs';
import * as path from 'path';
const req = createRequire(import.meta.url);

/* Dépôts open source sans lien entre eux, tels qu'installés. */
const TARGETS: [string, string][] = [
  ['lodash', 'node_modules/lodash'],
  ['express', 'node_modules/express/lib'],
  ['acorn', 'node_modules/acorn/dist'],
  ['astring', 'node_modules/astring/dist'],
  ['commander', 'node_modules/commander/lib'],
  ['simple-statistics', 'node_modules/simple-statistics/src'],
  ['qs', 'node_modules/qs/lib'],
  ['semver', 'node_modules/semver'],
  ['ms', 'node_modules/ms'],
  ['bytes', 'node_modules/bytes'],
  ['statuses', 'node_modules/statuses'],
  ['cookie', 'node_modules/cookie'],
  ['escape-html', 'node_modules/escape-html'],
  ['content-type', 'node_modules/content-type'],
  ['picomatch', 'node_modules/picomatch/lib'],
];

async function main() {
  // Pureté observée sur une charge réelle : condition de sûreté des règles appelant
  let purity = { pure: new Set<string>(), impure: new Set<string>() };
  try {
    const rec = new CallRecorder().record(req.resolve('lodash'), path.resolve('workloads/lodash_driver.cjs'));
    purity = {
      pure: new Set(rec.functions.filter(f => f.observedPure).map(f => f.name)),
      impure: new Set(rec.functions.filter(f => !f.observedPure).map(f => f.name))
    };
    console.log(`Pureté observée : ${purity.pure.size} fonctions pures, ${purity.impure.size} impures\n`);
  } catch (e: any) { console.log('Pureté non disponible :', e.message.slice(0, 60), '\n'); }

  const suite = new EvaluationSuite(purity);
  const results = [];
  console.log('dépôt'.padEnd(20), 'fich.'.padStart(6), 'fonctions'.padStart(10), 'pts chauds'.padStart(11), 'évaluables'.padStart(11), 'mutations'.padStart(10), 'prouvées'.padStart(9), 'acceptées'.padStart(10));
  for (const [name, dir] of TARGETS) {
    if (!fs.existsSync(dir)) { console.log(name.padEnd(20), '(absent)'); continue; }
    const r = await suite.evaluateRepo(name, dir);
    results.push(r);
    console.log(name.padEnd(20), String(r.filesScanned).padStart(6), String(r.functionsAnalyzed).padStart(10),
      String(r.hotspotsDetected).padStart(11), String(r.functionsEvaluable).padStart(11),
      String(r.mutationsAttempted).padStart(10), String(r.mutationsProven).padStart(9), String(r.mutationsAccepted).padStart(10));
  }

  console.log('\nMutations retenues (preuve concrète) :');
  const anyAccepted = results.flatMap(r => r.accepted.map(a => ({ repo: r.repo, ...a })));
  if (anyAccepted.length === 0) console.log('  aucune');
  for (const a of anyAccepted) console.log(`  ${a.repo}/${a.fn} — ${a.strategy} : +${a.gainPct.toFixed(1)} %`);

  const agg = suite.aggregate(results);
  const pct = (p: any) => `${(p.rate * 100).toFixed(1)} % [${(p.ci95[0] * 100).toFixed(1)} ; ${(p.ci95[1] * 100).toFixed(1)}]`;
  console.log('\n═══ AGRÉGAT ═══');
  console.log(`dépôts : ${agg.totals.repos} | fonctions analysées : ${agg.totals.functionsAnalyzed} | points chauds : ${agg.totals.hotspotsDetected}`);
  console.log(`évaluables par le harnais   : ${pct(agg.rates.evaluableRate)}  (${agg.totals.functionsEvaluable}/${agg.totals.functionsAnalyzed})`);
  console.log(`fonctions ayant ≥1 candidat : ${agg.totals.mutationsAttempted} mutations tentées`);
  console.log(`mutations réellement testées : ${agg.totals.mutationsTested} (sur ${agg.totals.mutationsAttempted} tentées — les autres portent sur des fonctions inexécutables par le harnais)`);
  console.log(`taux de preuve sémantique   : ${pct(agg.rates.proofSuccessRate)}`);
  console.log(`taux d'acceptation          : ${pct(agg.rates.acceptanceRate)}`);
  console.log(`dépôts améliorés            : ${pct(agg.rates.reposWithAtLeastOneAcceptance)}`);
  console.log(`échecs d'oracle découverts  : ${agg.totals.oracleFailures}`);
  console.log(`pull requests générées      : ${agg.totals.pullRequests}`);
  if (agg.meanImprovementPct) console.log(`gain moyen des acceptées    : ${agg.meanImprovementPct.mean.toFixed(1)} % [IC 95 % bootstrap : ${agg.meanImprovementPct.ci95[0].toFixed(1)} ; ${agg.meanImprovementPct.ci95[1].toFixed(1)}] sur n=${agg.meanImprovementPct.n}`);
  console.log(`\nVERDICT : ${agg.verdict}`);
  fs.writeFileSync('evaluation_results.json', JSON.stringify(agg, null, 2));
}
main();
