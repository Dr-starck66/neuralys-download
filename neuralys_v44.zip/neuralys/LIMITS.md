# Neuralys — Limites mesurées et modèle de menace

Ce document existe pour que les chiffres défavorables soient aussi visibles que
les chiffres favorables. Rien ici n'est une projection : tout est mesuré.

## 1. Couverture réelle — la limite dominante

Mesure : `npx tsx cli.ts coverage <repo>` (instrumenté dans `RepoOptimizer.coverage`).

| Corpus | Fonctions | Éligibles | Taux |
|---|---|---|---|
| `src/` de Neuralys (TypeScript de production réel) | 141 | 0 | **0.0 %** |
| Benchmarks synthétiques du corpus interne | 100 | 100 | 100 % |

Motifs d'exclusion sur le code réel : 134 méthodes de classe, 3 appels externes non
modélisés, 2 fonctions d'arité 0, 1 `await`, 1 arité 3.

**Conséquence à énoncer avant toute démonstration commerciale** : le harnais actuel
évalue des fonctions pures `f(number[]) -> valeur`. Sur une base de code
orientée objet, asynchrone ou avec I/O, la surface adressable est proche de zéro.
Les gains de ~30 % mesurés sur le corpus interne portent donc sur une classe de
code où le résultat est attendu (tri à bulles, accumulations, boucles naïves) —
ils ne se transfèrent PAS tels quels à du code de production.

Ce qu'il faudrait pour élargir la couverture, par ordre de coût croissant :
1. Méthodes de classe pures (receveur figé) — le plus gros gisement (134/141 ici)
2. Signatures non-`number[]` : inférence de type + générateurs de valeurs par type
3. Fonctions à effets — nécessite un modèle d'effets et un oracle sur les traces,
   pas seulement sur les valeurs de retour

Aucun de ces trois points n'est implémenté. Les annoncer comme faits serait faux.

## 1 bis. Applicabilité des règles au code de production (mesure v39)

| Projet | Fonctions | Avec boucle | Mutables par la bibliothèque de règles |
|---|---|---|---|
| lodash | 474 | 91 | **0** |
| acorn | 3 | 1 | 0 |
| astring | 11 | 6 | 1 |
| express | 11 | 2 | 1 |

2 sur 499, et les deux hors chemin critique. Les règles visent des motifs
naïfs que le code de production ne contient plus. Les gains jusqu'à +97 %
mesurés ailleurs proviennent d'un corpus volontairement naïf : ils ne
prédisent rien sur du logiciel réel. Détail et feuille de route dans
`REAL_SOFTWARE_VALIDATION.md`.

## 1 ter. Généralisation inter-dépôts (évaluation v42)

15 dépôts open source sans lien entre eux, protocole reproductible
(`npx tsx cli.ts evaluate`) :

| Indicateur | Valeur | IC 95 % |
|---|---|---|
| Fonctions analysées | 544 | — |
| **Évaluables par le harnais** | **0,9 %** | **[0,4 ; 2,1]** |
| Mutations tentées / réellement testées | 72 / 6 | — |
| Taux de preuve sémantique | 100 % (6/6) | [61,0 ; 100] |
| **Dépôts améliorés** | **1 / 15** | **[1,2 ; 29,8]** |
| Gain moyen des acceptées | 5,4 % | bootstrap [4,7 ; 6,0] |

**Verdict : le système ne généralise pas** dans son état actuel. Le goulot
n'est ni la génération, ni la preuve, ni la mesure — c'est l'évaluabilité.
Détail et recherche nécessaire dans `EVALUATION_REPORT.md`.

## 1 quater. Couverture d'exécution — harnais universel (v43)

KPI primaire : pourcentage de fonctions de production réellement exécutables
et validables. Cible fixée : > 80 %.

| Harnais | Couverture | IC 95 % |
|---|---|---|
| Synthétique (v42) | **0,9 %** | [0,4 ; 2,1] |
| Capture d'exécution (v43), 9 paquets | **8,1 %** | [6,9 ; 9,4] |
| Idem, rapporté aux fichiers réellement chargés | **15,4 %** | — |

Facteur 9 à 17. **Objectif non atteint.** Trois causes chiffrées, détail dans
`EXECUTION_COVERAGE.md` : couverture des scénarios (229 fonctions exécutées sur
2 614 instrumentées — remède : brancher la suite de tests du projet),
sérialisabilité (229 exécutées mais 142 rejouables : callbacks, instances de
classe, Map/Set), coût d'instrumentation sur gros bundles (lodash, 1 562
fonctions, n'a pas terminé).

## 2. Modèle de menace du bac à sable

`SandboxRunner` et le guardian exécutent le code dans `node:vm`.
**`node:vm` n'est pas une frontière de sécurité** — la documentation Node l'indique
explicitement, et une évasion de contexte est possible depuis du code hostile.

- Modèle de menace couvert : code écrit par l'utilisateur, ou proposé par un LLM
  sur demande de l'utilisateur. La protection recherchée est contre les **boucles
  infinies, les exceptions et les fuites mémoire** (timeouts, mesures bornées),
  pas contre un attaquant.
- Modèle de menace NON couvert : dépôt tiers non fiable, code hostile délibéré.
  Dans ce cas, l'exécution doit être déplacée hors du processus (conteneur avec
  `--network=none`, limites `--cpus`/`--memory`, utilisateur non privilégié).

Un `Dockerfile.sandbox` existait dans l'arborescence sans qu'aucun code ne
l'invoque : supprimé, car un chemin d'isolation décoratif est pire qu'aucun — il
laisse croire à une protection inexistante.

## 3. Coût en appels LLM

Compté depuis le code (`engine.generateOffspring`, `CooperativeCouncil.convene`) :

| Configuration | Appels par run |
|---|---|
| Symbolique seul (aucune auth) | **0** |
| Moteur + 1 fournisseur, 4 générations, population 8 | jusqu'à **32** |
| Moteur + 3 fournisseurs, 4 générations, population 8 | jusqu'à **96** |
| Conseil coopératif (par invocation) | **6** (3 propositions + 3 critiques) par fournisseur |

Sans authentification LLM, le moteur retombe sur 9 règles symboliques dont la
portée est étroite et bornée par construction. C'est un plancher fonctionnel
honnête, pas une parité.

## 4. Ce qui est structurellement complet mais non prouvé utile

- **Conseil multi-LLM** : rôles, critique et vote pondéré sont implémentés et
  compilent, mais aucune mesure ne montre qu'ils produisent de meilleures
  mutations qu'un appel simple. Tant que cette mesure n'existe pas, la
  fonctionnalité doit être présentée comme non validée.
- **Fédération** : le protocole de synchronisation est testé entre deux bases
  locales ; aucun déploiement multi-machines n'a été effectué, et il n'y a pas
  d'authentification entre pairs.

## 5. Gains mesurés par règle (corrige les estimations à vue de nez)

Extraits de `scientific_validation_raw.json` (suite de 100 benchmarks, moteur v31),
lignées acceptées uniquement :

| Règle (lignée dominante) | n | Gain moyen | Étendue |
|---|---|---|---|
| sort_idiom_recognition | 10 | **+84.0 %** | +80.8 → +85.1 |
| string_accumulation_to_join | 1 | +40.0 % | — |
| common_subexpression_elimination | 9 | +21.5 % | +6.0 → +65.0 |
| loop_invariant_length_caching | 26 | +18.3 % | +0.6 → +66.4 |
| shift_to_index_pointer | 3 | +15.4 % | +7.0 → +21.3 |

Deux corrections par rapport aux estimations courantes :
- `length_caching` n'est pas un gain marginal de 5-10 % : mesuré à +18.3 % en
  moyenne — mais avec une étendue énorme et, hors des lignées acceptées, il est
  souvent **négatif** (V8 hoiste déjà seul). C'est la variance qui compte, pas la
  moyenne.
- `sort_idiom` n'est pas « risque moyen parce qu'il ordonne » : le risque est
  faible **par construction**, puisque la mutation n'existe que si le fuzzing
  différentiel et les invariants du seed l'ont validée. Le risque d'une règle ne
  se juge pas sur son intention mais sur ce que l'oracle laisse passer.

## 6. Exécution dans l'artefact navigateur

L'artefact exécute tout code utilisateur ou muté dans un **Web Worker**, jamais
sur le thread principal. Ce que cela apporte réellement :
- une mutation à boucle infinie est **tuée** (`worker.terminate()` au dépassement
  du budget temps) au lieu de figer l'onglet définitivement — c'est le risque réel ;
- l'interface reste réactive pendant le fuzzing et les mesures ;
- chaque évaluation a un budget borné et vérifiable (testable dans l'onglet
  Diagnostic).

Ce n'est **pas** une protection contre du code hostile, et `new Function` n'est pas
une faille XSS ici : le code s'exécute avec les privilèges de l'onglet de la
personne qui l'a collé, ce qui est la fonction même d'un banc d'essai
d'optimisation. Le jour où l'on exécute du code tiers non fiable, c'est le
modèle de la section 2 qui s'applique — conteneur, pas navigateur.

## 7. Moteur de mutation de l'artefact navigateur : regex → AST

L'artefact portait ses règles en expressions régulières (le dépôt, lui, utilise
ts-morph depuis l'origine). Cette asymétrie est corrigée : l'artefact embarque
désormais **acorn** (parseur ESTree) et **astring** (générateur), et applique ses
règles par réécriture de nœuds AST — dans le worker, sans aucun appel réseau
(bibliothèques incorporées au fichier).

Mesure de la fragilité qui justifiait la bascule — même algorithme, écritures
différentes :

| Cas | Regex | AST |
|---|---|---|
| Tri à bulles canonique | ✓ | ✓ |
| Tri à bulles + commentaire dans la boucle | **échec silencieux** | ✓ |
| Tri à bulles avec accolade à la ligne | ✓ | ✓ |
| Tri à bulles avec `var` au lieu de `let` | **échec silencieux** | ✓ |
| `filter().length` canonique | ✓ | ✓ |
| `filter()` avec callback à corps bloc | **échec silencieux** | ✓ |
| `filter()` avec prédicat parenthésé | **échec silencieux** | ✓ |

4 échecs silencieux sur 7 pour les expressions régulières, 0 sur 7 pour l'AST.

Ce que la bascule apporte, vérifié par auto-test dans l'artefact :
- **immunité au style** : le déclenchement dépend de la structure, pas de la mise
  en forme, des noms de variables, ni des commentaires ;
- **portées sûres** : les temporaires (`arr_len`, accumulateurs, paramètres du
  comparateur généré) sont dérivés de l'ensemble des identifiants réellement
  présents — aucun masquage possible d'un nom existant ;
- **validité syntaxique par construction** : la sortie est régénérée depuis
  l'arbre, jamais recollée textuellement, donc aucun cycle d'évolution gaspillé
  par du code cassé ;
- **intention structurelle** : `.filter(cb).length` est reconnu comme un
  `MemberExpression` sur `CallExpression`, et le corps du callback est extrait
  de façon déterministe (flèche à corps expression comme fonction à corps bloc).

Le moteur AST du navigateur est versionné dans `browser/ast_engine.js`.
