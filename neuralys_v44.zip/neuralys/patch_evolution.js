const fs = require('fs');
const path = './system/research/core/evolution_driver.ts';
let code = fs.readFileSync(path, 'utf8');

if (!code.includes('MAPElitesArchive')) {
    code = code.replace(
        'import { tournamentSelection } from "./tournament_selection.js";',
        'import { tournamentSelection } from "./tournament_selection.js";\nimport { MAPElitesArchive } from "./map_elites.js";'
    );
    
    code = code.replace(
        'let currentPopulation = [{',
        'const mapElites = new MAPElitesArchive();\n    let currentPopulation = [{'
    );
    
    code = code.replace(
        'addLog(`[BENCHMARK] ${strategyUsed} -> Lat: ${mStats.mean.toFixed(2)}ms`);',
        'addLog(`[BENCHMARK] ${strategyUsed} -> Lat: ${mStats.mean.toFixed(2)}ms`);\n                        \n                        const mapInserted = mapElites.attemptInsertion(mutatedCode, 1000 - mStats.mean, {\n                            complexity: astMetrics.cyclomaticComplexity,\n                            latency: mStats.mean,\n                            astDistance: novelty.astDistance\n                        });\n                        if (mapInserted) addLog(`[MAP-ELITES] New novelty niche discovered! Archive size: ${mapElites.getArchiveSize()}`);'
    );
    
    fs.writeFileSync(path, code);
    console.log("Patched evolution_driver.ts with MAP-Elites");
}
