import { CIValidator } from './src/tools/ci_validation.ts';
import * as fs from 'fs';

const TARGETS: [string, string, string[]][] = [
  ['simple-statistics', '/tmp/extval/simple-statistics', ['src']],
  ['statuses', '/tmp/extval/statuses', ['.']],
  ['escape-html', '/tmp/extval/escape-html', ['.']],
];

async function main() {
  const val = new CIValidator();
  const all = [];
  for (const [name, dir, subdirs] of TARGETS) {
    if (!fs.existsSync(dir)) { console.log(`${name}: absent`); continue; }
    console.log(`\n═══ ${name} ═══`);
    const v = await val.validate(name, dir, subdirs);
    all.push(v);
    console.log(`  lanceur         : ${v.runner ? v.runner.framework + ' (' + v.runner.raw.slice(0, 45) + ')' : 'non reconnu'}`);
    console.log(`  référence CI    : ${v.baseline ? (v.baseline.ok ? 'VERTE' : 'ROUGE') + ' — ' + v.baseline.passed + ' tests, ' + v.baseline.durationMs + ' ms' : '-'}`);
    console.log(`  sous instrum.   : ${v.instrumentedSuite ? (v.instrumentedSuite.ok ? 'VERTE' : 'ROUGE') + ' — ' + v.instrumentedSuite.passed + ' tests' : '-'}`);
    console.log(`  fonctions       : ${v.functionsInstrumented} instrumentées, ${v.functionsCaptured} exécutées par les tests, ${v.functionsReplayable} rejouables`);
    const covPct = v.functionsInstrumented ? (v.functionsReplayable / v.functionsInstrumented * 100).toFixed(1) : '0';
    console.log(`  couverture rejeu: ${covPct} %`);
    console.log(`  points chauds   : ${v.hotspots.slice(0, 4).map(h => h.id.split('#')[1] + ' (' + h.calls + ' appels, ' + h.ms.toFixed(1) + ' ms)').join(', ') || 'aucun'}`);
    console.log(`  mutations       : ${v.mutations.length} tentées, ${v.mutations.filter(m => m.replayProven).length} prouvées par rejeu, ${v.survivingMutations} SURVIVANT À LA CI`);
    for (const m of v.mutations) {
      console.log(`     ${m.fn}/${m.strategy}: rejeu ${m.replayVerdict}${m.replayChecked ? ' (' + m.replayChecked + ' appels)' : ''}${m.suiteDetail ? ' | CI ' + (m.suitePassed ? 'VERTE' : 'ROUGE') + ' ' + m.suiteDetail : ''}${m.improvementPct !== null ? ' | Δ fonction ' + m.improvementPct.toFixed(1) + ' %' : ''}`);
    }
    for (const n of v.notes) console.log(`  note            : ${n}`);
  }
  fs.writeFileSync('ci_validation_results.json', JSON.stringify(all, null, 2));
  const tot = (f: (v: any) => number) => all.reduce((a, v) => a + f(v), 0);
  console.log(`\n═══ KPI PRIMAIRE ═══`);
  console.log(`dépôts validés            : ${all.filter(v => v.baseline?.ok).length}/${all.length}`);
  console.log(`fonctions instrumentées   : ${tot(v => v.functionsInstrumented)}`);
  console.log(`couverture de rejeu       : ${tot(v => v.functionsReplayable)}/${tot(v => v.functionsInstrumented)} = ${(tot(v => v.functionsReplayable) / Math.max(tot(v => v.functionsInstrumented), 1) * 100).toFixed(1)} %`);
  console.log(`mutations tentées         : ${tot(v => v.mutations.length)}`);
  console.log(`prouvées par rejeu        : ${tot(v => v.mutations.filter((m: any) => m.replayProven).length)} (réfutées : ${tot(v => v.mutations.filter((m: any) => m.replayVerdict === 'réfuté').length)}, non concluantes : ${tot(v => v.mutations.filter((m: any) => m.replayVerdict === 'non concluant').length)})`);
  console.log(`SURVIVANT À LA CI DU PROJET : ${tot(v => v.survivingMutations)}`);
}
main();
