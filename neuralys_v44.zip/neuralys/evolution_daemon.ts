import { DarwinDriver } from './src/core/engine';
import { KnowledgeBase } from './src/memory/knowledge_base';
import { generateBenchmarks } from './src/validation/benchmark_generator';
import { HyperparamEvolver } from './src/core/hyperparam_evolver';

/**
 * Evolution Daemon (spec point 5): unattended continuous evolution.
 * Each cycle picks the corpus target with the FEWEST accepted mutations
 * (exploration of neglected lineages), runs a bounded evolution, persists
 * everything to the shared KB, then idles. Budgeted: --cycles and
 * --idle-seconds bound total work; Ctrl+C safe (SQLite WAL).
 * Usage: npx tsx evolution_daemon.ts [--cycles N] [--idle-seconds S]
 */
async function main() {
    const args = process.argv.slice(2);
    const cycles = parseInt(args[args.indexOf('--cycles') + 1] || '0', 10) || Infinity;
    const idleSec = parseInt(args[args.indexOf('--idle-seconds') + 1] || '0', 10) || 60;

    const kb = new KnowledgeBase();
    const driver = new DarwinDriver(kb);
    const hyper = new HyperparamEvolver(kb);
    const corpus = generateBenchmarks().filter(b => b.id.endsWith('_var0'));

    let cycle = 0;
    const stop = () => { console.log(`\n[daemon] stopped after ${cycle} cycles, KB: ${kb.getTotalMutations()} mutations`); kb.close(); process.exit(0); };
    process.on('SIGINT', stop);
    process.on('SIGTERM', stop);

    while (cycle < cycles) {
        cycle++;
        // Rotate by experiment count: least-run target first. Dead-end
        // targets (no applicable strategy) still accumulate experiments,
        // so they rotate out instead of starving the queue.
        const counts = corpus.map(b => ({
            b,
            runs: kb.getExperimentCount(b.id),
            accepted: kb.getSuccessfulLineage(b.id).length
        })).sort((a, x) => a.runs - x.runs || a.accepted - x.accepted);
        const target = counts[0].b;

        const { name: configName, config } = hyper.next();
        console.log(`[daemon] cycle ${cycle}: evolving ${target.id} (${counts[0].runs} runs) with meta-config '${configName}'`);
        try {
            const t0 = Date.now();
            const res = await driver.evolve(target.id, target.category, target.code, config);
            hyper.report(res.totalImprovementPct, (Date.now() - t0) / 1000);
            console.log(`[daemon]   -> ${res.totalImprovementPct.toFixed(1)}% | ${res.bestLineage.join('->') || '(seed)'} | config ${configName} | KB: ${kb.getTotalMutations()}`);
        } catch (e: any) {
            console.warn(`[daemon]   evolution failed: ${e.message}`);
        }
        if (cycle < cycles) {
            console.log(`[daemon] idle ${idleSec}s`);
            await new Promise(r => setTimeout(r, idleSec * 1000));
        }
    }
    stop();
}
main();
