# Harnais universel : capture d'exécution et rejeu déterministe

KPI primaire : **pourcentage de fonctions de production réellement exécutables
et validables**. Cible fixée : > 80 %. Point de départ mesuré (v42, harnais
synthétique) : **0,9 % [0,4 ; 2,1]**.

## Architecture

Le harnais ne synthétise plus d'entrées. Il **instrumente l'AST** de chaque
fichier du paquet — pas seulement la surface exportée — puis exécute un
scénario réel et capture les appels.

```
function f(a, b) { CORPS }
→ function f(a, b) { return __NR.rec(id, this, arguments, () => { CORPS }); }
```

Une flèche hérite lexicalement de `this`, `arguments` et `super` : le corps
conserve exactement sa sémantique, et `return` reste `return`.

Formes couvertes, vérifiées par test : fonction libre, fonction imbriquée,
expression de fonction, **méthode de classe** (avec receveur), **flèche** (corps
d'expression et de bloc), **fonction asynchrone**, paramètres rest. Les
générateurs sont refusés explicitement (`yield` n'est pas enveloppable dans une
flèche) et comptés.

Sont capturés par appel : arguments avant, arguments après, `this` avant,
`this` après, valeur de retour, exception, durée. La comparaison avant/après
donne les **effets de bord observables** ; la répétition des mêmes entrées
donne le **déterminisme**. Ces deux propriétés sont mesurées, jamais supposées.

## Mesure sur 9 paquets réels

| Paquet | Fonctions | Exécutées | Rejouables | Couverture globale | Couverture des fichiers chargés |
|---|---|---|---|---|---|
| content-type | 9 | 9 | 6 | **66,7 %** | 66,7 % |
| semver | 125 | 48 | 44 | **35,2 %** | **57,1 %** |
| bytes | 4 | 3 | 2 | 50,0 % | 50,0 % |
| qs | 664 | 26 | 9 | 1,4 % | 20,5 % |
| commander | 290 | 112 | 42 | 14,5 % | 14,9 % |
| simple-statistics | 272 | 32 | 18 | 6,6 % | 13,1 % |
| acorn | 370 | 25 | 21 | 5,7 % | 5,8 % |
| cookie | 11 | 1 | 0 | 0 % | 0 % |
| lodash | 1562 | 0 | 0 | 0 % (dépassement de délai) | — |

**Agrégat, hors lodash** : 142 fonctions rejouables sur 1 745 = **8,1 %**
(15,4 % rapporté aux seuls fichiers effectivement chargés).
**Instrumentation** : 99,9 % des fonctions enveloppées avec succès ; un seul
refus sur 2 614 (flèche à paramètres complexes).

## Verdict

**Facteur 9 à 17 par rapport au harnais synthétique** (0,9 % → 8,1 % / 15,4 %).
La direction architecturale est confirmée par la mesure. **L'objectif de 80 %
n'est pas atteint**, et les trois causes sont maintenant chiffrées.

### 1. Couverture du scénario — cause dominante
229 fonctions exécutées sur 2 614 instrumentées. Mes scénarios exercent une
fraction de chaque API ; ils ont été écrits à la main. Le remède n'est pas
architectural : c'est d'utiliser **la suite de tests du projet lui-même** comme
scénario. Un paquet dont les tests couvrent 85 % des lignes rendrait
mécaniquement ~85 % de ses fonctions exécutées. C'est le levier principal, et
il ne demande aucune recherche nouvelle — seulement de brancher les tests.

### 2. Sérialisabilité — 229 exécutées mais 142 rejouables
38 % des fonctions exécutées ne sont pas rejouables : leurs arguments ou leurs
résultats contiennent des fonctions (callbacks), des instances de classe, des
`Map`/`Set`. Le cloneur les marque et les écarte plutôt que de produire un
rejeu faux. Recherche nécessaire : reconstruction structurée des instances
(prototype + état) et **remplacement des callbacks par des doublures rejouant
la séquence d'appels enregistrée**.

### 3. Coût de l'instrumentation sur les gros paquets
`lodash` (1 562 fonctions dans un bundle de 544 Ko) n'a pas terminé dans le
délai imparti. Enveloppement systématique = surcoût multiplicatif. Remède :
instrumentation **sélective** (seulement les fichiers ciblés par l'évolution),
qui divise le surcoût par le nombre de fichiers non ciblés.

## Ce que cela change pour le reste du système

Le rejeu devient l'oracle principal : équivalence = mêmes sorties **et mêmes
effets de bord** sur les appels réellement observés, quelle que soit l'arité,
le type, la présence de `this` ou d'`await`. Le fuzzing synthétique redevient
un filet de sécurité pour les fonctions sans capture.

## Reproduire

```bash
npx tsx cli.ts capture node_modules/semver workloads/drivers/semver.cjs semver
npx tsx run_capture_coverage.ts     # sweep complet
```
