import { PromptDarwin } from './src/promptlab/prompt_darwin';
import { KnowledgeBase } from './src/memory/knowledge_base';
import { EvalDataset } from './src/promptlab/types';
import * as fs from 'fs';

// Usage: npx tsx run_promptlab.ts <dataset.json> <seed_prompt.txt>
async function main() {
    const [datasetPath, promptPath] = process.argv.slice(2);
    if (!datasetPath || !promptPath) {
        console.log('Usage: npx tsx run_promptlab.ts <dataset.json> <seed_prompt.txt>');
        console.log('dataset.json: { name, scorer, train: [{input, expected}], holdout: [...] }');
        process.exit(1);
    }
    const dataset: EvalDataset = JSON.parse(fs.readFileSync(datasetPath, 'utf-8'));
    const seedPrompt = fs.readFileSync(promptPath, 'utf-8');
    const kb = new KnowledgeBase();
    const lab = new PromptDarwin(kb);
    const res = await lab.evolve(seedPrompt, dataset, { generations: 3 });

    console.log(`\nSeed:     qualité ${(res.seed.metrics.quality * 100).toFixed(0)}% | $${res.seed.metrics.costUsdPer1k.toFixed(2)}/1k appels`);
    console.log(`Champion: qualité ${(res.champion.metrics.quality * 100).toFixed(0)}% (holdout ${(res.champion.metrics.holdoutQuality * 100).toFixed(0)}%) | $${res.champion.metrics.costUsdPer1k.toFixed(2)}/1k`);
    console.log(`Économie: ${res.savingsPct.toFixed(1)}% | Δ qualité: ${(res.qualityDelta * 100).toFixed(0)} pts`);
    console.log(`Lignée: ${res.champion.strategyLineage.join(' -> ') || '(seed)'}`);
    console.log(`Front de Pareto: ${res.paretoFront.length} solutions`);
    fs.writeFileSync('prompt_experiment_report.json', JSON.stringify(res, null, 2));
    kb.close();
}
main().catch(e => { console.error(e.message); process.exit(1); });
