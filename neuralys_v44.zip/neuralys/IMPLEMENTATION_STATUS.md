# Neuralys — Implementation Status (honest scope)

Rule applied: no stubs, no fake implementations. Anything not buildable
to production standard is listed as NOT IMPLEMENTED with the reason.

## Implemented and validated by real execution

| Phase | Component | Evidence |
|---|---|---|
| 1 (partial) | AST-level semantic mutations: 6 idiom-recognition rules (`ast_mutator.ts`) | 100-benchmark suite: 10 significant improvements, 40 regressions correctly rejected |
| 2 (partial) | Generational GA + NSGA-II selection + crowded tournament (`darwin_driver.ts`, `algorithms/nsga2.ts`) | 4-generation runs, Pareto fronts on [latency, memory, complexity] |
| 3 | Persistent knowledge base: every mutation, outcome, lineage, p-value (SQLite, `db/knowledge_base.ts`) | KB grows across independent runs (7 -> 15 records), artifacts content-addressed by hash |
| 4 (partial) | Property-based differential fuzzing as autonomous correctness oracle (`semantic_guardian.ts`) | 200 generated inputs + edge cases per mutation; divergences reject |
| 6 | Multi-objective Pareto optimization (latency, memory, cyclomatic complexity) | NSGA-II fronts reported per generation |
| 7 | UCB1 bandit over strategies, warm-started from KB history (`strategy_bandit.ts`) | Second run reorders strategies from learned priors |
| 10 | Explainability: reasoning, measured benefit, p-value, lineage, rollback via parent hash | `darwin_experiment_report.json` + KB `mutations` table |
| 1/9 (v22) | Multi-agent LLM ensemble: Claude (subscription) + OpenAI/Gemini/DeepSeek/Qwen behind env keys, per-provider bandit attribution (`llm_providers.ts`) | Graceful degradation verified (claude-only in test env) |
| — (v22) | Semantic canonicalizer: alpha-renaming dedup skips benchmarks on trivially-equivalent variants; CSE rule (7th) (`canonicalizer.ts`) | Sound merge/distinct verified; CSE fuzz-equivalent, +51.8% on unseen function |
| 3/7 (v22) | Genetic memory: structural code signatures transfer strategy priors to never-seen functions (`codeSignature`, signature-scoped bandit) | Unseen dot-product inherited SumSquares-family priors, optimized gen 1 |
| 6 (v22) | 4th objective: code size added to the Pareto front [latency, memory, complexity, size] | NSGA-II fronts on 4 objectives |

## Product pivot (v23): PromptLab — darwinian prompt optimization

`system/promptlab/`: prompt genome on the SAME selection machinery
(UCB1 + NSGA-II + KB genetic memory). Objectives minimized:
[1 - quality, USD cost per 1k calls, latency]. Anti-Goodhart: fitness on
train split only; holdout measured once on the final Pareto front.
6 strategies (4 LLM meta-rewrites + few-shot injection + filler stripping).
CLI: `npx tsx run_promptlab.ts dataset.json seed_prompt.txt`.
Honest boundary: EvalRunner throws without an LLM backend — no mock fitness.
Symbolic strategies verified offline; full loop requires `claude login`.

## v24 — industrial evolution core

| Spec | Component | Evidence |
|---|---|---|
| 1 | Genetic graph: recursive descendant/ancestry CTEs, survival rates, provenance (language, LLM provider, machine), similarity lookup | Tree traversal + survival query verified on live KB |
| 2/10 | Thompson Sampling + UCB1 + META-EVOLUTION: a meta-Thompson bandit selects the selection policy per generation (the engine learns how to learn) | 4/4 unit tests; wired in darwin_driver, policy + posterior reported per generation |
| 5 | Evolution Daemon: unattended cycles, least-explored-target rotation (anti-starvation), budget flags, SIGINT-safe | 3-cycle run: +72.7% found autonomously, crossover lineage discovered |
| 6 | Cooperative LLM council: 3 expert roles x ensemble propose -> critic scores -> weighted vote shortlists -> benchmark remains sole judge | Structural; degrades to 0 proposals without auth (never fakes) |
| 9 | Python language provider: subprocess compile-check + differential fuzzing (205 cases) + calibrated benchmark. Mutations for Python are LLM-only; the harness is what makes them acceptable | O(n^2)->O(n) validated EQUIVALENT (+99.8%); wrong mutation rejected with counterexample |
| 13 | Plugin seam: LanguageProvider interface (compile/fuzz/benchmark contract) | TS full + Python real |
| 14 | Unit test suite (node:test): NSGA-II domination, canonicalizer soundness, Thompson convergence, UCB1 exploration | 4 pass / 0 fail |

Still refused (unchanged reasons): CFG comparison & symbolic execution (research program), energy/security/readability objectives (no honest in-process measurement - refusing fake proxies), NSGA-III (justified only at >=5 objectives; current: 4), remaining 7 languages (each needs what Python just got - real harness first, never stubs), public REST API & interactive observability UI (product phase; KB export + artifacts are the data source ready for it).

## Wired but requires external resources (not validated here)

- LLM architectural mutations (`claude_mutator.ts`, `hybrid_mutator.ts`): Claude
  Agent SDK path billed against the subscription's monthly Agent SDK credit
  (Pro/Max/Team/Enterprise, since 2026-06-15) when the `claude` CLI is
  authenticated on the host; `ANTHROPIC_API_KEY` (pay-as-you-go) as explicit
  opt-in only. Verified in-container: auth cascade reaches the CLI and degrades
  gracefully to the symbolic engine when not logged in.
- Kubernetes parallel dispatch (`kubernetes_dispatcher.ts`): compiles against
  client-node v1, bounded concurrency; requires a cluster.

## NOT IMPLEMENTED — and why

- **Phase 5, SMT/symbolic execution**: sound translation of JS/TS semantics
  (prototypes, floats, GC, exceptions) to SMT-LIB is a research program, not a
  feature. Faking it with a Z3 stub was removed. Differential fuzzing is the
  correctness oracle; its limits (probabilistic, input-distribution-dependent)
  are accepted and documented.
- **Phase 8, whole-architecture evolution**: requires validated LLM mutation
  quality plus repository-scale test harnesses; premature before Phase 1 LLM
  path is measured.
- **Phase 11, multi-language (Go/Rust/C++/Java/C#/Kotlin/Python)**: each
  language needs a real toolchain, AST mutator and benchmark harness. Shipping
  9 language adapters now would violate the no-stub rule. The driver is
  language-agnostic at the interface level; only the TS/JS adapter exists.
- **Phase 12, continuous arbitrary-repo evolution**: depends on Phase 11 and on
  LLM-generated project-specific benchmarks (Phase 4 full). The loop exists for
  the internal corpus only.

## Known limitations (measured, not hidden)

- Micro-benchmark scale (n=1000): V8's JIT already beats several classic
  micro-optimizations (indexOf SIMD on short strings, rope-based string +=,
  amortized O(1) shift on small arrays). The system detects and rejects these —
  this is correct behavior, not failure.
- Statistical power at sub-microsecond runtimes requires the calibrated
  repetition sampling in `sandbox_runner.ts`; disable it and false regressions return.
